// This file configures the initialization of Sentry on the server.
// The config you add here will be used whenever the server handles a request.
// https://docs.sentry.io/platforms/javascript/guides/nextjs/
// Integration BrowserTracing is included by default, for options see
// https://docs.sentry.io/platforms/javascript/guides/nextjs/performance/instrumentation/automatic-instrumentation/

import * as Sentry from '@sentry/nextjs';

Sentry.init({
    dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
    enabled: !['development', 'test'].includes(process.env.NODE_ENV),
    environment: process.env.SENTRY_ENV || process.env.NODE_ENV,
    ignoreErrors: [
        'Maximum call stack size exceeded',
        'Non-Error promise rejection captured',
    ],
    maxBreadcrumbs: 50,
    tracesSampleRate: 0,
});