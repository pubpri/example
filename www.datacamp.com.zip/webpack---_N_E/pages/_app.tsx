import '@datacamp/growth-shared/lib/constants/global.css';

// if you want to add styles for the react-multi-carousel/growth-shared-carousel
// do it in the page/component you will be using it, not here
import theme from '@datacamp/growth-shared/lib/constants/theme';
import useAccountInformation from '@datacamp/growth-shared/lib/helpers/auth/useAccountInformation';
import { getCookie } from '@datacamp/growth-shared/lib/helpers/cookies';
import { GlobalFontFaces } from '@datacamp/waffles-text';
import { Global } from '@emotion/react';
import type { AppProps } from 'next/app';
import dynamic from 'next/dynamic';
import Head from 'next/head';
import type { NextRouter } from 'next/router';
import Script from 'next/script';
import { useEffect } from 'react';
import { ThemeProvider } from 'theme-ui';

import { createSha1Hash, createSha256Hash } from 'helpers/createHash';
import {
  b2bBannerInclusionPaths,
  // demoWebinarBannerInclusionPaths,
  marketoInclusionPaths,
  navbarExclusionPaths,
  noMenuNavbar,
  // pathsWithBusinessBanner,
  pathsWithCustomSeo,
  promoExclusionPaths,
  signInRedirectPaths,
} from 'sources/paths';
import { DataLayerContentProps, DataLayerEventProps } from 'types/dataLayer';

const ToastContainer = dynamic(
  // @ts-expect-error they do not export types from here
  () => import('@datacamp/waffles-toast/lib/ToastContainer'),
);

const BotMegaMenu = dynamic(
  () =>
    import(
      '@datacamp/growth-shared/lib/components/sitewide/MegaMenu/BotMegaMenu'
    ),
);

// const DemoWebinarBanner = dynamic(
//   () => import('components/banners/DemoWebinarBanner'),
// );

const PromoExpiredBanner = dynamic(
  () => import('components/banners/PromoExpiredBanner'),
);

const ZoomBanner = dynamic(() => import('components/banners/ZoomBanner'));

const FakeModalMobile = dynamic(() => import('components/FakeModalMobile'));

// const BusinessBanner = dynamic(
//   () => import('components/banners/BusinessBanner'),
// );

const DynamicMegaMenu = dynamic(
  () =>
    import('@datacamp/growth-shared/lib/components/sitewide/MegaMenu/index'),
  {
    ssr: true,
  },
);

const DynamicSearch = dynamic(
  () =>
    import('@datacamp/growth-shared/lib/components/sitewide/MegaMenu/Search'),
  {
    ssr: false,
  },
);

const metaDescription =
  "Learn Data Science from the comfort of your browser, at your own pace with DataCamp's video tutorials &amp; coding challenges on R, Python, Statistics &amp; more.";

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  address: {
    '@type': 'PostalAddress',
    addressCountry: 'United States',
    addressLocality: 'New York',
    postalCode: '10118',
    streetAddress: '350 5th Ave',
  },
  description:
    'What is DataCamp? Learn the data skills you need online at your own pace—from non-coding essentials to data science and machine learning.',
  logo: 'https://res.cloudinary.com/dyd911kmh/image/upload/f_auto,q_auto:best/v1603223608/DC_New_mugdv8.png',
  name: 'DataCamp',
  sameAs: [
    'https://twitter.com/DataCamp',
    'https://www.linkedin.com/school/datacampinc/mycompany/',
    'https://www.facebook.com/datacampinc/',
    'https://www.youtube.com/c/Datacamp',
  ],
  url: 'https://www.datacamp.com/',
};

const isPathIncluded = (path: string | RegExp, router: NextRouter): boolean => {
  if (typeof path === 'string') {
    return router.pathname === path;
  }

  return path.test(router.pathname);
};

async function snowplow(): Promise<void> {
  const snowplowOptions = {
    appId: 'marketing-app',
    contexts: {
      performanceTiming: true,
      webPage: true,
    },
    discoverRootDomain: true,
    forceSecureTracker: true,
    platform: 'web',
    post: true,
    postPath: '/spevent',
  };

  window.snowplow(
    'newTracker',
    'co',
    process.env.NEXT_PUBLIC_SNOWPLOW_ENDPOINT,
    snowplowOptions,
  );
  window.snowplow('enableActivityTracking', 10, 10); // Ping every 10 seconds after 10 seconds
  const unsafeUserId = getCookie('unsafe_user_id');
  let userData = {};

  if (unsafeUserId) {
    window.snowplow('setUserId', unsafeUserId);
    userData = {
      userId: unsafeUserId,
    };
  }

  const userContext = {
    data: userData,
    schema: 'iglu:com.datacamp/user/jsonschema/1-0-0',
  };

  window.snowplow('trackPageView', null, [userContext]);
  window.snowplow('enableLinkClickTracking', null, null, false, [userContext]);

  window.snowplow('enableFormTracking');
}

async function oneSignal(): Promise<void> {
  try {
    const COOKIE_NAME = 'exp-web_notification';
    const promptedUser = document.cookie.match(
      `(^|;)\\s*${COOKIE_NAME}\\s*=\\s*([^;]+)`,
    );

    if (typeof promptedUser === 'undefined') {
      // Make sure the user won't be prompted again in the next 7 days.
      const date = new Date();
      date.setDate(date.getDate() + 7);
      document.cookie = `${COOKIE_NAME}=true; expires=${date.toUTCString()};`;

      const OneSignal = window.OneSignal || [];
      OneSignal.push([
        'init',
        {
          appId: '677c1389-ac32-4b80-a65f-703aeaf80b37',
          autoRegister: false,
          notifyButton: {
            enable: false,
          },
          welcomeNotification: {
            disable: true,
          },
        },
      ]);
    }
  } catch (e) {
    // eslint-disable-next-line no-console
    console.log('OneSignal error JS occured - dismiss');
  }
}

const pushToDataLayer = (
  dataLayerValues: DataLayerContentProps | DataLayerEventProps,
): void => {
  if (typeof window !== 'undefined') {
    if (typeof window.dataLayer === 'undefined') {
      window.dataLayer = [dataLayerValues];
    } else {
      window.dataLayer.push(dataLayerValues);
    }
  }
};

const impactRadiusScript =
  'https://d.impactradius-event.com/A2717580-78fa-4df3-ac44-faf7e7c3a6e91.js';

function MyApp(props: AppProps): React.ReactElement {
  const { Component, pageProps, router } = props;

  const bannerExcluded = promoExclusionPaths.some((path) =>
    isPathIncluded(path, router),
  );
  const b2bBannerIncluded = b2bBannerInclusionPaths.some((path) =>
    isPathIncluded(path, router),
  );
  const generalSeoExcluded = pathsWithCustomSeo.some((path) =>
    isPathIncluded(path, router),
  );

  const includingMenu = !noMenuNavbar.some((p) => router.pathname.includes(p));
  const navbarExcluded = navbarExclusionPaths.includes(router.pathname);
  const navbarExcludedBot = !includingMenu || navbarExcluded;

  const marketoIncluded = marketoInclusionPaths.includes(router.pathname);
  const zoomBannerIncluded = router.asPath.includes('/resources');
  const promoExpiredBannerIncluded = router.asPath.includes(
    '/pricing?promo=expired',
  );

  let signInRedirectPath: string | undefined;

  const signInRedirectPathsKey = Object.keys(signInRedirectPaths).find((path) =>
    router.pathname.startsWith(path),
  );

  if (signInRedirectPathsKey) {
    signInRedirectPath = signInRedirectPaths[signInRedirectPathsKey];
  }

  // const demoWebinarBannerExcluded = !demoWebinarBannerInclusionPaths.some(
  //   (path) => isPathIncluded(path, router),
  // );

  const { accountInformation, isSignedIn, loading } = useAccountInformation();

  const showFakeModalMobile = router.asPath.includes('mobile_app_redirect');

  useEffect(() => {
    const utmParams = Object.keys(router.query).filter((key) =>
      key.startsWith('utm'),
    );
    try {
      if (sessionStorage && utmParams.length > 0) {
        Object.keys(sessionStorage)
          .filter((key) => key.startsWith('utm'))
          .forEach((key) => {
            sessionStorage.removeItem(key);
          });
        sessionStorage.setItem('landingpageUrl', window.location.href);
        utmParams.forEach((key) => {
          sessionStorage.setItem(key, router.query[key] as string);
        });
      } else if (sessionStorage.getItem('landingpageUrl') === null) {
        sessionStorage.setItem('landingpageUrl', window.location.href);
      }
    } catch (e) {
      // eslint-disable-next-line no-console
      console.log('sessionStorage not available');
    }
  }, [router.query]);

  useEffect(() => {
    window.ire =
      window.ire ||
      function (args: string[]) {
        (window.ire[impactRadiusScript] =
          window.ire[impactRadiusScript] || []).push(...args);
      };

    if (window?.ire && !loading) {
      const customerIdentification = {
        customerEmail: accountInformation?.email
          ? createSha1Hash(accountInformation?.email)
          : '',
        customerId: accountInformation?.id,
      };

      window.ire('identify', customerIdentification);
    }
  }, [accountInformation, loading]);

  useEffect(() => {
    if (!loading) {
      if (isSignedIn) {
        const isPhoneExist =
          accountInformation?.phone && accountInformation?.phone !== '';

        const activeProducts = accountInformation?.activeProducts?.join() || '';
        const userEmail = accountInformation?.email;
        const lowerCasedAndTrimedEmail = userEmail?.trim().toLocaleLowerCase();

        const dataLayerContent: DataLayerContentProps = {
          active_products: activeProducts,
          type: 'registered',
          user_email_hashed:
            lowerCasedAndTrimedEmail &&
            createSha256Hash(lowerCasedAndTrimedEmail),
          user_email_non_hashed: lowerCasedAndTrimedEmail,
          user_id: accountInformation?.id,
        };

        const identifyScriptId = 'profitwell-identify-script';
        if (
          lowerCasedAndTrimedEmail &&
          !document.getElementById(identifyScriptId)
        ) {
          const profitwellIdentifyScript = document.createElement('script');
          profitwellIdentifyScript.id = identifyScriptId;
          profitwellIdentifyScript.innerHTML = `profitwell('user_email', '${lowerCasedAndTrimedEmail}');`;
          document.body.appendChild(profitwellIdentifyScript);
        }

        if (isPhoneExist) {
          const userPhone = accountInformation?.phone;
          const lowerCasedAndTrimedPhone = userPhone
            ?.trim()
            .toLocaleLowerCase();

          dataLayerContent.user_phone_number_hashed =
            lowerCasedAndTrimedPhone &&
            createSha256Hash(lowerCasedAndTrimedPhone);
        }

        pushToDataLayer(dataLayerContent);
        pushToDataLayer({ event: 'user_properties_updated' });
      } else {
        // we need to pass in active_products as '' to GTM so integrations know
        // that we've checked if the user is signed in and they are not
        const dataLayerContent: DataLayerContentProps = {
          active_products: '',
        };

        pushToDataLayer(dataLayerContent);
        pushToDataLayer({ event: 'user_properties_updated' });
      }
    }
  }, [accountInformation, isSignedIn, loading]);

  useEffect(() => {
    window.addEventListener('load', snowplow);
    window.addEventListener('load', oneSignal);

    return () => {
      window.removeEventListener('load', snowplow);
      window.removeEventListener('load', oneSignal);
    };
  }, []);

  // @ts-expect-error allowing dynamic layouts
  const getLayout = Component.getLayout || ((page: any) => page);

  return (
    <>
      <Head>
        <title>Learn R, Python &amp; Data Science Online | DataCamp</title>
        <meta content={metaDescription} name="description" />
        {!generalSeoExcluded && (
          <>
            <link
              href={`https://www.datacamp.com${router.asPath.split('?')[0]}`}
              rel="canonical"
            />
            <meta
              content="Learn R, Python &amp; Data Science Online"
              key="twitter:title"
              name="twitter:title"
            />
            <meta
              content={metaDescription}
              key="twitter:description"
              name="twitter:description"
            />
            <meta content="summary" name="twitter:card" />
            <meta content="@DataCamp" name="twitter:site" />
            <meta
              content="https://www.datacamp.com/datacamp-twitter-share.png"
              key="twitter:image"
              name="twitter:image"
            />
            <meta content="300" name="twitter:image:width" />
            <meta content="300" name="twitter:image:height" />
            <meta content="@DataCamp" name="twitter:creator" />
            <meta content="www.datacamp.com" name="twitter:domain" />
            <meta
              content="https://www.datacamp.com/datacamp-socials-share.png"
              key="og:image"
              property="og:image"
            />
            <meta content="1200" property="og:image:width" />
            <meta content="630" property="og:image:height" />
            <meta
              content="Learn R, Python &amp; Data Science Online"
              key="og:title"
              property="og:title"
            />
            <meta
              content={`https://www.datacamp.com${router.asPath.split('?')[0]}`}
              property="og:url"
            />
            <meta
              content={metaDescription}
              key="og:description"
              property="og:description"
            />
          </>
        )}

        <meta content="website" property="og:type" />

        <meta
          content="ao3s4PdjisD2QsfTbldo7YJx7VX2QLkPEtlDpyFTjo8"
          name="google-site-verification"
        />

        <meta content="app-id=1263413087" name="apple-itunes-app" />

        <meta
          content="M-70jYcq5Hj35EY_NQzm9MAPI6pfVrq-hqaiK13ZQeo"
          name="google-site-verification"
        />

        <link href="/manifest.json" rel="manifest" />
        <link href="/users/sign_up" rel="preconnect" />
        <link
          href={`${process.env.NEXT_PUBLIC_COOKIE_BANNER_URL}`}
          rel="preconnect"
        />

        <link
          href="/marketing-backgrounds/favicons/apple-touch-icon-57x57.png"
          rel="apple-touch-icon-precomposed"
          sizes="57x57"
        />
        <link
          href="/marketing-backgrounds/favicons/apple-touch-icon-114x114.png"
          rel="apple-touch-icon-precomposed"
          sizes="114x114"
        />
        <link
          href="/marketing-backgrounds/favicons/apple-touch-icon-72x72.png"
          rel="apple-touch-icon-precomposed"
          sizes="72x72"
        />
        <link
          href="/marketing-backgrounds/favicons/apple-touch-icon-144x144.png"
          rel="apple-touch-icon-precomposed"
          sizes="144x144"
        />
        <link
          href="/marketing-backgrounds/favicons/apple-touch-icon-60x60.png"
          rel="apple-touch-icon-precomposed"
          sizes="60x60"
        />
        <link
          href="/marketing-backgrounds/favicons/apple-touch-icon-120x120.png"
          rel="apple-touch-icon-precomposed"
          sizes="120x120"
        />
        <link
          href="/marketing-backgrounds/favicons/apple-touch-icon-76x76.png"
          rel="apple-touch-icon-precomposed"
          sizes="76x76"
        />
        <link
          href="/marketing-backgrounds/favicons/apple-touch-icon-152x152.png"
          rel="apple-touch-icon-precomposed"
          sizes="152x152"
        />
        <link
          href="/marketing-backgrounds/favicons/favicon-196x196.png"
          rel="icon"
          sizes="196x196"
          type="image/png"
        />
        <link
          href="/marketing-backgrounds/favicons/favicon-96x96.png"
          rel="icon"
          sizes="96x96"
          type="image/png"
        />
        <link
          href="/marketing-backgrounds/favicons/favicon-32x32.png"
          rel="icon"
          sizes="32x32"
          type="image/png"
        />
        <link
          href="/marketing-backgrounds/favicons/favicon-16x16.png"
          rel="icon"
          sizes="16x16"
          type="image/png"
        />
        <link
          href="/marketing-backgrounds/favicons/favicon-128.png"
          rel="icon"
          sizes="128x128"
          type="image/png"
        />
        <meta content="&nbsp;" name="application-name" />
        <meta content="#FFFFFF" name="msapplication-TileColor" />
        <meta
          content="/marketing-backgrounds/favicons/mstile-144x144.png"
          name="msapplication-TileImage"
        />
        <meta
          content="/marketing-backgrounds/favicons/mstile-70x70.png"
          name="msapplication-square70x70logo"
        />
        <meta
          content="mstile-150x150.png"
          name="/marketing-backgrounds/favicons/msapplication-square150x150logo"
        />
        <meta
          content="mstile-310x150.png"
          name="/marketing-backgrounds/favicons/msapplication-wide310x150logo"
        />
        <meta
          content="mstile-310x310.png"
          name="/marketing-backgrounds/favicons/msapplication-square310x310logo"
        />
      </Head>

      <script
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(organizationSchema),
        }}
        id="organization_schema"
        key="organization_schema"
        type="application/ld+json"
      />

      {!bannerExcluded && <Script src="https://promo.datacamp.com/banner.js" />}
      {b2bBannerIncluded && (
        <Script src="https://promo.datacamp.com/banner_b2b.js" />
      )}

      {marketoIncluded && (
        <Script src="//app-ab40.marketo.com/js/forms2/js/forms2.min.js" />
      )}

      {/* DataCamp cookie banner & tracking setup, by G unit */}
      <Script
        dangerouslySetInnerHTML={{
          __html: `;(function () {
        var dataLayerContent = {
          gtm_version: 2,
          type: 'non-registered',
          user_id: 'anonymous',
        };

        if (typeof window['dataLayer'] === 'undefined') {
          window['dataLayer'] = [dataLayerContent];
        } else {
          window['dataLayer'].push(dataLayerContent);
        }
      })();`,
        }}
        id="data-layer-content"
      />
      <Script src={`${process.env.NEXT_PUBLIC_COOKIE_BANNER_URL}/base.js`} />

      <Script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" />

      <Script
        dangerouslySetInnerHTML={{
          __html: `;(function(p,l,o,w,i,n,g){if(!p[i]){p.GlobalSnowplowNamespace=p.GlobalSnowplowNamespace||[];
      p.GlobalSnowplowNamespace.push(i);p[i]=function(){(p[i].q=p[i].q||[]).push(arguments)
      };p[i].q=p[i].q||[];n=l.createElement(o);g=l.getElementsByTagName(o)[0];n.defer=1;
      n.src=w;g.parentNode.insertBefore(n,g)}}(window,document,"script","//cdn.datacamp.com/sp/2.10.2.js","snowplow"));
      `,
        }}
        id="snowplow-script"
      />

      <Script
        dangerouslySetInnerHTML={{
          __html: `;(function(i,s,o,g,r,a,m){i[o]=i[o]||function(){(i[o].q=i[o].q||[]).push(arguments)};
      a=s.createElement(g);m=s.getElementsByTagName(g)[0];a.async=1;a.src=r+'?auth='+
      s.getElementById(o+'-js').getAttribute('data-pw-auth');m.parentNode.insertBefore(a,m);
      })(window,document,'profitwell','script','https://public.profitwell.com/js/profitwell.js');`,
        }}
        data-pw-auth="7041278c644eba1df6181e0425efa583"
        id="profitwell-js"
      />

      {!isSignedIn && (
        <Script
          dangerouslySetInnerHTML={{
            __html: `profitwell('start', {});`,
          }}
          id="profitwell-start"
          strategy="lazyOnload"
        />
      )}

      <Script src={impactRadiusScript} type="text/javascript" />

      <Global
        styles={{
          '.modal-overlay': {
            zIndex: '1100 !important', // Over the promo banner
          },
        }}
      />

      {/*
      // @ts-expect-error: Ignore until the release of theme-ui 0.4.0 */}
      <ThemeProvider theme={theme}>
        <ToastContainer />
        <GlobalFontFaces />
        {/* {!demoWebinarBannerExcluded && <DemoWebinarBanner />} */}
        {zoomBannerIncluded && <ZoomBanner />}
        {promoExpiredBannerIncluded && <PromoExpiredBanner />}

        {!navbarExcludedBot && <BotMegaMenu />}
        {!navbarExcluded && (
          <DynamicMegaMenu
            includingMenu={includingMenu}
            searchComponent={<DynamicSearch />}
            signInRedirectPath={signInRedirectPath}
          />
        )}

        <div id="main">{getLayout(<Component {...pageProps} />)}</div>

        {showFakeModalMobile && <FakeModalMobile />}
      </ThemeProvider>
    </>
  );
}

export default MyApp;
