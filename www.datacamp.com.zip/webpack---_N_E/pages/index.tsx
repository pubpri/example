import 'react-multi-carousel/lib/styles.css';

import Educators from '@datacamp/growth-shared/lib/components/content/Educators';
import Quotes from '@datacamp/growth-shared/lib/components/content/Quotes';
import SignUp from '@datacamp/growth-shared/lib/components/content/SignUp';
import CompaniesMd from '@datacamp/growth-shared/lib/components/primitives/CompaniesMd';
import Footer from '@datacamp/growth-shared/lib/components/sitewide/Footer';
import {
  BUSINESS_DEMO_PATH,
  BUSINESS_PATH,
  COURSES_PATH,
  SIGN_UP_PATH,
  SIGNAL_PATH,
  tracks,
} from '@datacamp/growth-shared/lib/constants/routes';
import staticStats from '@datacamp/growth-shared/lib/constants/stats';
import { roundNumber } from '@datacamp/growth-shared/lib/helpers/roundNumbers';
import Button from '@datacamp/waffles-button';
import { GetStaticProps, NextPage } from 'next';
import Image from 'next/image';
/** @jsxRuntime automatic */
/** @jsxImportSource theme-ui */
import { Box, Container, Flex, Link, Text } from 'theme-ui';

import IconArrowRight from 'assets/svg/icons/arrow-right.svg';
import IconAssess from 'assets/svg/icons/filled-assess.svg';
import SvgOracle from 'assets/svg/technologies/oracle.svg';
import Alpa from 'components/Alpa';
import CertificationSection from 'components/CertificationSection';
import IntroSignup from 'components/IntroSignup';
import TechnologyLogos from 'components/primitives/TechnologyLogos';
import ScrollSectionsPrimary from 'components/ScrollSectionsPrimary';
import WorkspaceSection from 'components/WorkspaceSection';
import { getStats } from 'sources/datacamp';
import { careerLinks, skillLinks, technologyLinks } from 'sources/paths';
import { DataCampStats } from 'types/datacamp';

const ORACLE_PATH = '/courses/introduction-to-oracle-sql';

type Props = {
  stats: DataCampStats;
};

const Home: NextPage<Props> = ({ stats }) => (
  <>
    <style global jsx>{`
      body {
        background-color: #f7f3eb; /* 'beige.200' */
      }
    `}</style>
    <IntroSignup formIdPrefix="intro" formTitleElement="h2">
      <Box
        sx={{
          pb: [32, null, null, null, 0],
          pr: [null, null, null, null, 32, null],
          textAlign: ['left', 'center', null, null, 'left'],
        }}
      >
        <Text
          as="h1"
          sx={{
            color: 'white',
            maxWidth: [null, null, 525],
            mx: ['auto', null, null, null, 0],
          }}
          variant="h50"
        >
          Build data skills online
        </Text>
        <Text
          as="p"
          sx={{
            color: 'white',
            maxWidth: [null, null, 420],
            mb: 24,
            mt: 16,
            mx: ['auto', null, null, null, 0],
          }}
          variant="t24"
        >
          Data drives everything. Get the skills you need for the future of
          work.
        </Text>
        <Button
          appearance="primary"
          href={SIGN_UP_PATH}
          intent="success"
          size="large"
          sx={{
            display: 'flex',
            mx: ['auto', null, null, null, 0],
            width: [null, 365],
          }}
          type="link"
        >
          Start Learning For Free
        </Button>
        <Button
          appearance="inverted"
          href={BUSINESS_PATH}
          intent="neutral"
          size="large"
          sx={{
            display: 'flex',
            mt: 16,
            mx: ['auto', null, null, null, 0],
            width: [null, 365],
          }}
          type="link"
        >
          DataCamp For Business
        </Button>
      </Box>
    </IntroSignup>
    <main>
      {/* BusinessCta */}
      <Box sx={{ py: [86, null, null, null, 128] }}>
        <Container
          sx={{
            alignItems: 'center',
            display: 'flex',
            flexDirection: ['column', null, null, null, 'row'],
            justifyContent: 'space-between',
          }}
        >
          <Box
            sx={{
              pt: [48, null, null, null, 0],
              textAlign: ['center', null, null, null, 'left'],
              width: ['100%', null, null, null, '50%'],
            }}
          >
            <Text as="p" sx={{ color: 'red.200', mb: 12 }} variant="c14">
              Loved by learners at thousands of companies
            </Text>
            <Text as="h2" sx={{ mb: 8 }} variant="h40">
              Skill up at scale. Data training designed for your business.
            </Text>
            <Text as="p" sx={{ mb: 16 }} variant="t18">
              {`Join ${roundNumber(
                staticStats.noOfCompanies,
                100,
              )}+ companies and ${
                staticStats.percentOfFortune1000
              }% of the Fortune 1000 who use DataCamp to
          upskill their teams.`}
            </Text>
            <Button
              appearance="primary"
              href={BUSINESS_PATH}
              intent="neutral"
              type="link"
            >
              Learn More
            </Button>
          </Box>
          <CompaniesMd
            primaryOnly
            sx={{
              '> div': { maxWidth: 500 },
              color: 'text',
              maxWidth: 500,
              mt: [null, null, null, null, -48],
              svg: {
                mt: [null, null, null, null, 48],
              },
            }}
          />
        </Container>
      </Box>
      <Box
        sx={{
          backgroundImage: 'url(/marketing-backgrounds/bg-home.svg)',
          backgroundPosition: [
            'center 600px',
            null,
            'center 1000px',
            'center 300px',
            null,
            'center 100px',
            'center 250px',
          ],
          backgroundRepeat: 'no-repeat',
        }}
      >
        <Alpa />
        <Box
          as="section"
          className="invert"
          sx={{
            bg: ['navy.200', null, null, 'transparent'],
            pt: [48, null, null, null, null, 96],
          }}
        >
          <ScrollSectionsPrimary />
        </Box>
        <Box as="section">
          {/* Technology links */}
          <Box aria-labelledby="learning-paths" as="nav">
            <Container
              sx={{
                pb: 64,
                pt: [64, null, null, null, null, null, 250],
                textAlign: ['center', null, null, null, null, 'left'],
              }}
            >
              <Text
                as="h2"
                id="learning-paths"
                sx={{
                  color: ['white'],
                }}
                variant="h40"
              >
                Learning paths{' '}
                <span sx={{ color: 'green.200' }}>designed by experts</span>
              </Text>
              <Text
                as="h3"
                sx={{ color: 'white', mb: 8, mt: 32 }}
                variant="h32"
              >
                Learn a new technology
              </Text>
              <Flex
                sx={{
                  flexWrap: 'wrap',
                  justifyContent: 'center',
                  mx: -16,
                }}
              >
                {technologyLinks.map((technologyLink) => (
                  <Link
                    className="ie-accentBottom"
                    href={technologyLink.path}
                    key={technologyLink.path}
                    sx={{
                      alignItems: 'center',
                      boxShadow:
                        '0 1px 4px -1px rgba(5, 25, 45, 0.3), 0 0 1px 0 rgba(5, 25, 45, 0.3);',
                      display: 'flex',
                      height: 103,
                      justifyContent: 'center',
                      m: 16,
                      width: 260,
                    }}
                    variant="accentBottom"
                  >
                    <TechnologyLogos
                      single={technologyLink.prop}
                      singleWidth={technologyLink.width}
                    />
                  </Link>
                ))}
                <Link
                  className="ie-accentBottom"
                  href={ORACLE_PATH}
                  sx={{
                    alignItems: 'center',
                    boxShadow:
                      '0 1px 4px -1px rgba(5, 25, 45, 0.3), 0 0 1px 0 rgba(5, 25, 45, 0.3);',
                    display: 'flex',
                    height: 103,
                    justifyContent: 'center',
                    m: 16,
                    width: 260,
                  }}
                  variant="accentBottom"
                >
                  <i aria-hidden="true">
                    <SvgOracle width="148" />
                  </i>
                  <span className="visually-hidden">Oracle</span>
                </Link>
              </Flex>
              <Flex
                sx={{
                  justifyContent: [
                    'center',
                    null,
                    null,
                    null,
                    null,
                    'flex-end',
                  ],
                }}
              >
                <Link
                  href={COURSES_PATH}
                  sx={{
                    '&:active, &:focus, &:hover': {
                      color: 'blue.200',
                      textDecoration: 'none',
                    },
                    alignItems: 'center',
                    color: 'text',
                    display: 'flex',
                    fontSize: 400,
                    mt: 8,
                    svg: { color: 'blue.200' },
                    transition: 'color 0.3s cubic-bezier(0.85, 0, 0.15, 1)',
                  }}
                >
                  Explore All Technologies{' '}
                  <IconArrowRight sx={{ ml: 8 }} width="18" />
                </Link>
              </Flex>
            </Container>
          </Box>
          {/* Career links */}
          <Box aria-labelledby="career" as="nav">
            <Container
              sx={{
                pb: 64,
                textAlign: ['center', null, null, null, null, 'left'],
              }}
            >
              <Text as="h3" id="career" sx={{ mb: 8, mt: 32 }} variant="h32">
                Launch your career
              </Text>
              <Flex
                sx={{
                  flexWrap: 'wrap',
                  justifyContent: 'center',
                  mx: -16,
                }}
              >
                {careerLinks.map((careerLink) => (
                  <Link
                    className="ie-accentBottom"
                    href={careerLink.path}
                    key={careerLink.path}
                    sx={{
                      '&::after': {
                        bg: 'pink.200',
                      },
                      alignItems: 'center',
                      boxShadow:
                        '0 1px 4px -1px rgba(5, 25, 45, 0.3), 0 0 1px 0 rgba(5, 25, 45, 0.3);',
                      color: 'text',
                      display: 'flex',
                      fontSize: 600,
                      fontWeight: 'bold',
                      justifyContent: 'center',
                      m: 16,
                      maxWidth: 358,
                      pb: 38,
                      pt: 35,
                      textAlign: 'center',
                      width: '100%',
                    }}
                    variant="accentBottom"
                  >
                    <span sx={{ position: 'relative' }}>{careerLink.name}</span>
                  </Link>
                ))}
              </Flex>
              <Flex
                sx={{
                  justifyContent: [
                    'center',
                    null,
                    null,
                    null,
                    null,
                    'flex-end',
                  ],
                }}
              >
                <Link
                  href={tracks.CAREER_PATH}
                  sx={{
                    '&:active, &:focus, &:hover': {
                      color: 'pink.200',
                      textDecoration: 'none',
                    },
                    alignItems: 'center',
                    color: 'text',
                    display: 'flex',
                    fontSize: 400,
                    mt: 8,
                    svg: { color: 'pink.200' },
                    transition: 'color 0.3s cubic-bezier(0.85, 0, 0.15, 1)',
                  }}
                >
                  Explore All Career Tracks{' '}
                  <IconArrowRight sx={{ ml: 8 }} width="18" />
                </Link>
              </Flex>
            </Container>
          </Box>
          {/* Skill links */}
          <Box aria-labelledby="skills" as="nav">
            <Container
              sx={{
                pb: 150,
                textAlign: ['center', null, null, null, null, 'left'],
              }}
            >
              <Text as="h3" id="skills" sx={{ mb: 8, mt: 32 }} variant="h32">
                Master a specific skill
              </Text>
              <Flex
                sx={{
                  flexWrap: 'wrap',
                  justifyContent: 'center',
                  mx: -16,
                }}
              >
                {skillLinks.map((skillLink) => (
                  <Link
                    className="ie-accentBottom"
                    href={skillLink.path}
                    key={skillLink.path}
                    sx={{
                      '&::after': {
                        bg: 'purple.200',
                      },
                      alignItems: 'center',
                      boxShadow:
                        '0 1px 4px -1px rgba(5, 25, 45, 0.3), 0 0 1px 0 rgba(5, 25, 45, 0.3);',
                      color: 'text',
                      display: 'flex',
                      fontSize: 600,
                      fontWeight: 'bold',
                      justifyContent: 'center',
                      m: 16,
                      maxWidth: 260,
                      pb: 38,
                      pt: 35,
                      px: 12,
                      textAlign: 'center',
                      width: '100%',
                    }}
                    variant="accentBottom"
                  >
                    <span sx={{ position: 'relative' }}>{skillLink.name}</span>
                  </Link>
                ))}
              </Flex>
              <Flex
                sx={{
                  justifyContent: [
                    'center',
                    null,
                    null,
                    null,
                    null,
                    'flex-end',
                  ],
                }}
              >
                <Link
                  href={tracks.SKILL_PATH}
                  sx={{
                    '&:active, &:focus, &:hover': {
                      color: 'purple.200',
                      textDecoration: 'none',
                    },
                    alignItems: 'center',
                    color: 'text',
                    display: 'flex',
                    fontSize: 400,
                    mt: 8,
                    svg: { color: 'purple.200' },
                    transition: 'color 0.3s cubic-bezier(0.85, 0, 0.15, 1)',
                  }}
                >
                  Explore All Skill Tracks{' '}
                  <IconArrowRight sx={{ ml: 8 }} width="18" />
                </Link>
              </Flex>
            </Container>
          </Box>
        </Box>
      </Box>
      <Box
        sx={{
          bg: 'navy.200',
          pb: 56,
          position: 'relative',
        }}
      >
        <Container
          sx={{
            alignItems: [null, null, null, null, null, 'center'],
            display: [null, null, null, null, null, 'flex'],
            justifyContent: [null, null, null, null, null, 'space-between'],
            maxWidth: [550, null, null, null, null, 1172],
            position: 'relative',
            py: [64, null, null, null, null, 120],
            zIndex: 10,
          }}
        >
          <Box>
            <Text
              as="h1"
              sx={{
                alignItems: 'center',
                color: 'blue.200',
                display: 'flex',
                maxWidth: [null, null, 525],
                mb: 16,
              }}
              variant="h24"
            >
              <IconAssess sx={{ mr: 10, width: 39 }} />
              DataCamp Signal
              <sup
                sx={{
                  fontSize: 100,
                  ml: 4,
                  mt: -8,
                }}
              >
                TM
              </sup>
            </Text>
            <Text
              as="p"
              sx={{ color: 'white', maxWidth: [null, null, 525] }}
              variant="h50"
            >
              Discover your data skill level{' '}
              <span sx={{ color: 'blue.200' }}>for free</span>
            </Text>
            <Text
              as="p"
              sx={{
                color: 'white',
                maxWidth: [null, null, 420],
                mb: 24,
                mt: 16,
              }}
              variant="t18"
            >
              Effective learning starts with assessment. Learning a new skill is
              hard work—Signal makes it easier.
            </Text>
            <Button
              appearance="primary"
              href={SIGNAL_PATH}
              intent="success"
              type="link"
            >
              Take An Assessment
            </Button>
            <Button
              appearance="inverted"
              href={BUSINESS_DEMO_PATH}
              intent="neutral"
              sx={{
                mb: [16, null, null, null, null, null, 0],
                ml: [0, null, null, null, null, 16],
                mt: [16, null, null, null, null, 0],
              }}
              type="link"
            >
              Request a DataCamp For Business Demo
            </Button>
          </Box>
          <Image
            alt="Screenshot of a an assessment with a score of 100"
            height={271}
            src="/Marketing/Screenshots/screenshot-signal-100.png"
            sx={{
              aspectRatio: `${1100 / 543}`,
            }}
            width={550}
          />
        </Container>
      </Box>
      <CertificationSection />
      <WorkspaceSection />
      <Quotes title="Don’t just take our word for it." />
      <Educators
        sx={{
          '> div > div:last-of-type': { display: 'none' },
          bg: 'background',
        }}
      />
      <SignUp registeredUsers={stats.numberOfUsers} />
    </main>
    <Footer />
  </>
);

export const getStaticProps: GetStaticProps = async () => {
  const stats = await getStats();
  return {
    props: { stats },
    revalidate: 60 * 60 * 4,
  };
};

export default Home;
