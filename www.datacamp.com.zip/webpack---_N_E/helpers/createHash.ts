import { sha1, sha256 } from 'hash.js';

export const createSha1Hash = (data: string): string =>
  sha1().update(data).digest('hex');

export const createSha256Hash = (data: string): string =>
  sha256().update(data).digest('hex');
