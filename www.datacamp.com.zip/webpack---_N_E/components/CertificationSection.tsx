/** @jsxRuntime automatic */
/** @jsxImportSource theme-ui */
import { certification } from '@datacamp/growth-shared/lib/constants/routes';
import Button from '@datacamp/waffles-button';
import Image from 'next/image';
import React from 'react';
import { Box, Container, Flex, Text } from 'theme-ui';

const CertificationSection: React.FC = () => (
  <Box
    sx={{
      bg: 'beige.100',
      position: 'relative',
    }}
  >
    <Container
      sx={{
        alignItems: [null, null, null, null, null, 'center'],
        display: [null, null, null, null, null, 'flex'],
        justifyContent: [null, null, null, null, null, 'space-between'],
        maxWidth: [550, null, null, null, null, 1172],
        pb: [64, null, null, null, null, 90],
        position: 'relative',
        pt: [64, null, null, null, null, 72],
        zIndex: 10,
      }}
    >
      <Box
        sx={{
          pt: [48, null, null, null, 0],
          textAlign: [null, null, null, null, 'left'],
          width: ['100%', null, null, null, null, '45%'],
        }}
      >
        <Text as="p" sx={{ color: 'pink.200', mb: 12 }} variant="c14">
          Certification
        </Text>
        <Text as="h2" sx={{ mb: 8 }} variant="h40">
          Land your dream job in data science
        </Text>
        <Text as="p" sx={{ mb: 16 }} variant="t18">
          From a certification in data science to personalized resume reviews
          and interview prep—we've got you covered.
        </Text>
        <Button href={certification.CERTIFICATION_LANDING_PATH} type="link">
          Learn More
        </Button>
      </Box>
      <Flex
        sx={{
          alignItems: 'flex-start',
          flexShrink: 0,
          img: {
            height: 'auto',
            maxWidth: '100%',
          },
          justifyContent: ['center', null, null, null, 'flex-end'],
          mt: [16, null, null, null, 0],
          mx: ['auto', null, null, null, 0],
        }}
      >
        <Image
          alt="Screenshot of data scientist and hiring manager"
          height={464}
          src="/Marketing/Certification/certification_light.png"
          width={616}
        />
      </Flex>
    </Container>
  </Box>
);

export default CertificationSection;
