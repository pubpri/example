/** @jsxRuntime automatic */
/** @jsxImportSource theme-ui */
import React from 'react';
import { Container, Text } from 'theme-ui';

import CampusDragAndDropFigure from './figures/CampusDragAndDropFigure';
import CampusExerciseFigure from './figures/CampusExerciseFigure';
import InstructorsFigure from './figures/InstructorsFigure';
import LearningExperienceFigure from './figures/LearningExperienceFigure';

type Props = {
  className?: string;
  highlightColor?: string;
};

const ScrollSectionsPrimary: React.FC<Props> = ({
  className,
  highlightColor,
}) => (
  <Container className={className}>
    <Text
      as="h2"
      sx={{
        fontSize: ['800', null, null, null, '800'],
        textAlign: 'center',
      }}
      variant="h40"
    >
      <span sx={{ color: highlightColor ? 'white' : 'green.200' }}>
        Hands-on
      </span>{' '}
      learning experience
    </Text>

    <CampusExerciseFigure />
    <InstructorsFigure />
    <LearningExperienceFigure />
    <CampusDragAndDropFigure />
  </Container>
);

export default ScrollSectionsPrimary;
