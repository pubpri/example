/** @jsxRuntime automatic */
/** @jsxImportSource theme-ui */
import VsWrapper from '@datacamp/growth-shared/lib/components/primitives/VsWrapper';
import {
  COURSES_PATH,
  PRACTICE_URL,
  PROJECTS_PATH,
  SIGN_UP_PATH,
  SIGNAL_PATH,
} from '@datacamp/growth-shared/lib/constants/routes';
import Button from '@datacamp/waffles-button';
import React from 'react';
import { Box, Container, Link, Text } from 'theme-ui';

import AlpaLoop from 'assets/svg/alpa-loop.svg';
import IconChevronRight from 'assets/svg/icon-chevron-right.svg';
import IconApply from 'assets/svg/icons/filled-apply.svg';
import IconAssess from 'assets/svg/icons/filled-assess.svg';
import IconLearn from 'assets/svg/icons/filled-learn.svg';
import IconPractice from 'assets/svg/icons/filled-practice.svg';
import VsLenox from 'assets/svg/vs/lenox.svg';
import VsLeonard from 'assets/svg/vs/leonard.svg';
import VsLeroy from 'assets/svg/vs/leroy.svg';

const Alpa: React.FC = () => (
  <>
    <Box
      as="section"
      className="invert"
      sx={{
        bg: 'purple.200',
        pb: [60, null, null, null, null, 102],
        position: 'relative',
        pt: [84, null, null, null, null, 112],
        px: 16,
        textAlign: 'center',
      }}
    >
      <Text as="h2" variant="h50">
        What is DataCamp?
      </Text>
      <Text
        as="p"
        sx={{
          maxWidth: 548,
          mx: 'auto',
          pb: 24,
          pt: 16,
        }}
        variant="t24"
      >
        Learn the data skills you need online at your own pace—from non-coding
        essentials to data science and machine learning.
      </Text>
      <Button
        appearance="primary"
        href={SIGN_UP_PATH}
        intent="success"
        type="link"
      >
        Start Learning For Free
      </Button>
      <VsWrapper
        sx={{
          justifyContent: 'flex-end',
          pr: ['20%', '25%', '50%'],
          top: -31,
        }}
      >
        <VsLenox
          sx={{
            mr: [null, null, null, 100, 150, 323],
          }}
        />
      </VsWrapper>
    </Box>
    <Box
      as="section"
      sx={{
        bg: 'navy.200',
        pb: 80,
        position: 'relative',
        pt: [76, null, null, null, null, 116],
      }}
    >
      <Container
        sx={{
          alignItems: [null, null, null, null, null, 'center'],
          display: [null, null, null, null, null, 'flex'],
        }}
      >
        <Box
          sx={{
            maxWidth: [null, null, null, null, null, 260],
            position: 'relative',
            zIndex: 5,
          }}
        >
          <Text
            as="h2"
            sx={{
              color: 'white',
              mt: [null, null, null, null, 32],
              textAlign: [null, null, 'center', null, null, 'left'],
            }}
            variant="h40"
          >
            We learn best by doing
          </Text>
          <Text
            as="p"
            sx={{
              color: 'white',
              mb: 32,
              mt: 12,
              textAlign: [null, null, 'center', null, null, 'left'],
            }}
            variant="t18"
          >
            DataCamp's proven learning methodology.
          </Text>
        </Box>
        <Box
          as="nav"
          sx={{
            '&:after': {
              bg: 'white',
              content: '""',
              display: [null, null, null, 'none'],
              height: 340,
              left: 36,
              position: 'absolute',
              top: 24,
              width: 4,
            },

            a: {
              zIndex: 10,
            },
            display: [null, null, null, 'flex'],
            flexWrap: [null, null, null, 'wrap'],
            justifyContent: [null, null, null, 'space-between'],
            maxWidth: 690,
            mx: 'auto',
            position: 'relative',
          }}
        >
          <Link
            href={SIGNAL_PATH}
            sx={{
              '&:active, &:focus, &:hover': {
                color: 'blue.200',
                svg: {
                  color: 'blue.200',
                  transform: 'scale(1.15)',
                },
                textDecoration: 'none',
              },
              alignItems: 'center',
              display: 'flex',
              ml: [null, null, null, 16],
              mt: [24],
              position: ['relative'],
              svg: {
                transition: '0.15s linear',
              },
            }}
          >
            <IconAssess
              sx={{
                ml: [null, null, null, 16],
                mr: [16, null, null, 0],
                order: [null, null, null, 1],
                width: 76,
              }}
            />
            <Box>
              <Text
                as="strong"
                sx={{
                  alignItems: 'center',
                  color: 'blue.200',
                  display: 'flex',
                }}
                variant="h28"
              >
                Assess
                <IconChevronRight sx={{ color: 'white', ml: 8, width: 7 }} />
              </Text>
              <Text
                as="p"
                sx={{
                  color: 'white',
                  fontSize: [300, null, null, 400],
                  fontWeight: 'regular',
                  maxWidth: 158,
                  mt: 4,
                }}
                variant="t16"
              >
                Test your skills and track progress
              </Text>
            </Box>
          </Link>
          <Link
            href={COURSES_PATH}
            sx={{
              '&:active, &:focus, &:hover': {
                color: 'green.200',
                svg: {
                  color: 'green.200',
                  transform: 'scale(1.15)',
                },
                textDecoration: 'none',
              },
              alignItems: 'center',
              display: 'flex',
              mt: [24],
              position: ['relative'],
              svg: {
                transition: '0.15s linear',
              },
            }}
          >
            <IconLearn
              sx={{
                mr: [16],
                width: 76,
              }}
            />
            <Box>
              <Text
                as="strong"
                sx={{
                  alignItems: 'center',
                  color: 'green.200',
                  display: 'flex',
                }}
                variant="h28"
              >
                Learn
                <IconChevronRight sx={{ color: 'white', ml: 8, width: 7 }} />
              </Text>
              <Text
                as="p"
                sx={{
                  color: 'white',
                  fontSize: [300, null, null, 400],
                  fontWeight: 'regular',
                  maxWidth: 178,
                  mt: 4,
                }}
                variant="t16"
              >
                Complete interactive courses
              </Text>
            </Box>
          </Link>
          <Link
            href={PRACTICE_URL}
            sx={{
              '&:active, &:focus, &:hover': {
                color: 'orange.200',
                svg: {
                  color: 'orange.200',
                  transform: 'scale(1.15)',
                },
                textDecoration: 'none',
              },
              alignItems: 'center',
              display: 'flex',
              mt: [24, null, null, 116],
              order: [null, null, null, 1],
              position: ['relative'],
              svg: {
                transition: '0.15s linear',
              },
            }}
          >
            <IconPractice
              sx={{
                mr: [16],
                width: 76,
              }}
            />
            <Box>
              <Text
                as="strong"
                sx={{
                  alignItems: 'center',
                  color: 'orange.200',
                  display: 'flex',
                }}
                variant="h28"
              >
                Practice
                <IconChevronRight sx={{ color: 'white', ml: 8, width: 7 }} />
              </Text>
              <Text
                as="p"
                sx={{
                  color: 'white',
                  fontSize: [300, null, null, 400],
                  fontWeight: 'regular',
                  maxWidth: 176,
                  mt: 4,
                }}
                variant="t16"
              >
                Practice with quick daily challenges
              </Text>
            </Box>
          </Link>
          <Link
            href={PROJECTS_PATH}
            sx={{
              '&:active, &:focus, &:hover': {
                '> svg': {
                  color: 'pink.200',
                },
                color: 'pink.200',
                svg: {
                  color: 'pink.200',
                  transform: 'scale(1.15)',
                },
                textDecoration: 'none',
              },
              alignItems: 'center',
              display: 'flex',
              mt: [24, null, null, 116],
              pl: [null, null, null, 16],
              position: 'relative',
              svg: {
                transition: '0.15s linear',
              },
            }}
          >
            <IconApply
              sx={{
                ml: [null, null, null, 32],
                mr: [16, null, null, 0],
                order: [null, null, null, 1],
                width: 76,
              }}
            />
            <Box>
              <Text
                as="strong"
                sx={{
                  alignItems: 'center',
                  color: 'pink.200',
                  display: 'flex',
                }}
                variant="h28"
              >
                Apply
                <IconChevronRight sx={{ color: 'white', ml: 8, width: 7 }} />
              </Text>
              <Text
                as="p"
                sx={{
                  color: 'white',
                  fontSize: [300, null, null, 400],
                  fontWeight: 'regular',
                  maxWidth: 137,
                  mt: 4,
                }}
                variant="t16"
              >
                Solve real-world problems
              </Text>
            </Box>
          </Link>
          <AlpaLoop
            sx={{
              display: ['none', null, null, null, null, 'block'],
              left: 166,
              position: 'absolute',
              top: 0,
              width: 358,
            }}
          />
        </Box>
      </Container>
      <VsWrapper
        sx={{
          display: ['none', null, null, null, null, 'flex'],
          justifyContent: [null, null, null, null, null, 'flex-end'],
          pr: [null, null, null, null, null, '50%'],
          top: -35,
        }}
      >
        <VsLeonard
          aria-hidden="true"
          sx={{
            height: 554,
            mr: 272,
          }}
        />
      </VsWrapper>
      <VsWrapper
        sx={{
          display: ['none', null, null, null, null, 'flex'],
          pl: [null, null, null, null, null, '50%'],
          top: 0,
        }}
      >
        <VsLeroy
          aria-hidden="true"
          sx={{
            ml: 570,
          }}
        />
      </VsWrapper>
    </Box>
  </>
);

export default Alpa;
