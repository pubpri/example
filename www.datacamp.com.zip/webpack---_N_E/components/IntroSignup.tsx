/** @jsxRuntime automatic */
/** @jsxImportSource theme-ui */
import FormSignUp from '@datacamp/growth-shared/lib/components/primitives/FormSignUp';
import VsWrapper from '@datacamp/growth-shared/lib/components/primitives/VsWrapper';
import React from 'react';
import { Box, Container, Flex } from 'theme-ui';

import VsHoratioLeft from 'assets/svg/vs/horatio-left.svg';
import VsHoratioRight from 'assets/svg/vs/horatio-right.svg';
import VsSmBeach from 'assets/svg/vs/sm-beach.svg';
import TechnologyLogos from 'components/primitives/TechnologyLogos';

type Props = {
  children: React.ReactElement;
  className?: string;
  formCta?: string;
  formIdPrefix?: string;
  formRedirectPath?: string;
  formTitleElement?: 'h1' | 'h2' | 'h3' | 'h4';
};

const IntroSignup: React.FC<Props> = ({
  children,
  className,
  formCta,
  formIdPrefix,
  formRedirectPath,
  formTitleElement,
}) => (
  <Box
    as="header"
    className={className}
    sx={{
      bg: 'navy.200',
      pb: [96, null, null, null, 170],
      position: 'relative',
      pt: [64],
    }}
  >
    <Container>
      <Flex
        sx={{
          alignItems: ['center'],
          flexDirection: ['column', null, null, null, 'row'],
          justifyContent: [null, null, null, 'space-between'],
        }}
      >
        {children}
        <FormSignUp
          formCta={formCta}
          idPrefix={formIdPrefix}
          redirectPath={formRedirectPath}
          title={formTitleElement}
        />
      </Flex>
      <Flex
        sx={{
          '> *': {
            m: 8,
          },
          alignItems: 'center',
          color: 'rgba(255, 255, 255, 0.8)',
          flexWrap: 'wrap',
          justifyContent: ['center', null, null, null, null, 'space-between'],
          maxWidth: [520, null, null, null, null, '100%'],
          mx: ['auto', null, null, null, null, -8],
          pt: 56,
        }}
      >
        <TechnologyLogos />
      </Flex>
    </Container>
    <VsWrapper
      className="ie-vsWrapper"
      sx={{
        alignItems: 'flex-end',
        bottom: [-70, null, null, null, -36],
        justifyContent: 'center',
      }}
    >
      <VsSmBeach
        aria-hidden="true"
        sx={{
          '.sm-beach_svg__p2': {
            fill: 'purple.200',
          },
          display: [null, null, null, null, 'none'],
          flexShrink: 0,
        }}
      />
      <VsHoratioLeft
        aria-hidden="true"
        sx={{
          display: ['none', null, null, null, 'block'],
          flexShrink: 0,
        }}
      />
      <VsHoratioRight
        aria-hidden="true"
        sx={{
          display: ['none', null, null, null, 'block'],
          flexShrink: 0,
          transform: 'translate(390px, 0)',
        }}
      />
    </VsWrapper>
  </Box>
);

export default IntroSignup;
