/** @jsxRuntime automatic */
/** @jsxImportSource theme-ui */
import { workspaceMarketing } from '@datacamp/growth-shared/lib/constants/routes';
import Button from '@datacamp/waffles-button';
import Image from 'next/image';
import React from 'react';
import { Box, Container, Flex, Text } from 'theme-ui';

import VSCircle from 'assets/svg/vs/vsCircle.svg';

const WorkspaceSection: React.FC = () => (
  <Box
    sx={{
      bg: 'navy.200',
      overflow: 'hidden',
      position: 'relative',
    }}
  >
    <Container
      sx={{
        alignItems: [null, null, null, null, null, 'center'],
        display: [null, null, null, null, null, 'flex'],
        height: ['auto', null, null, null, null, 626],
        justifyContent: [null, null, null, null, null, 'space-between'],
        maxWidth: [550, null, null, null, null, 1172],
        pb: [64, null, null, null, null, 90],
        position: 'relative',
        pt: [64, null, null, null, null, 72],
        zIndex: 10,
      }}
    >
      <Box
        sx={{
          pt: [48, null, null, null, 0],
          textAlign: [null, null, null, null, 'left'],
          width: ['100%', null, null, null, null, '40%'],
        }}
      >
        <Text as="p" sx={{ color: 'blue.200', mb: 12 }} variant="c14">
          Workspace
        </Text>
        <Text as="h2" sx={{ color: 'white', mb: 8 }} variant="h40">
          Start your own data analysis in seconds
        </Text>
        <Text as="p" sx={{ color: 'white', mb: 16 }} variant="t18">
          Your personal in-browser tool to write, run, and share your data
          analysis.
        </Text>
        <Button
          appearance="inverted"
          href={workspaceMarketing.LANDING_PATH}
          type="link"
        >
          Learn More
        </Button>
      </Box>
      <Flex
        sx={{
          alignItems: 'flex-start',
          flexShrink: 0,
          img: {
            height: 'auto',
            maxWidth: '100%',
          },
          justifyContent: [null, null, null, 'flex-start'],
          mt: [32, null, null, null, null, 0],
          mx: ['auto', null, null, null, 0],
        }}
      >
        <Image
          alt="Screenshot of workspace and user's photo"
          height={300}
          src="Marketing/Illustrations/workspace-header-img.png"
          width={424}
        />
        <Flex
          aria-hidden="true"
          sx={{
            bottom: -105,
            display: ['none', null, null, null, null, 'flex'],
            position: 'absolute',
            right: -350,
          }}
        >
          {' '}
          <VSCircle
            aria-hidden="true"
            sx={{
              flexShrink: 0,
            }}
          />
        </Flex>
      </Flex>
    </Container>
  </Box>
);

export default WorkspaceSection;
