import Image from 'next/image';
import React from 'react';
import { Flex } from 'theme-ui';

import Figure from './Figure';
import FigureCaption from './FigureCaption';
import FigureCaptionText from './FigureCaptionText';

type Props = {
  highlightColor?: string;
};

const CampusDragAndDropFigure: React.FC<Props> = ({ highlightColor }) => {
  return (
    <Figure
      sx={{
        '> *': { width: [null, null, null, null, '50%'] },
        alignItems: [null, null, null, null, 'center'],
        display: [null, null, null, null, 'flex'],
        mt: [80, null, null, null, 144],
      }}
    >
      <FigureCaption>
        <FigureCaptionText
          sx={{ maxWidth: 254, mx: ['auto', null, null, null, 0] }}
        >
          <span sx={{ color: highlightColor || 'pink.200' }}>Practice</span> and{' '}
          <span sx={{ color: highlightColor || 'pink.200' }}>apply</span> your
          skills
        </FigureCaptionText>
      </FigureCaption>
      <Flex
        sx={{
          '> span': {
            img: {
              height: 'auto',
              maxWidth: ['100%', null, null, 450],
            },
            mr: '16px !important',
          },
          alignItems: 'flex-start',
          flexShrink: 0,

          justifyContent: ['center', null, null, null, 'flex-end'],
          mt: [16, null, null, null, 0],
          mx: ['auto', null, null, null, 0],
          pr: [null, null, null, null, 40],
        }}
      >
        <Image
          alt="Screenshot of campus exercise and dragging answer"
          height={327.27}
          src="/Marketing/Illustrations/campus-drag-and-drop.png"
          width={450}
        />
      </Flex>
    </Figure>
  );
};

export default CampusDragAndDropFigure;
