import React from 'react';

type Props = {
  children?: React.ReactNode;
  highlightColor?: string;
};

const FigureCaption: React.FC<Props> = ({ children }) => {
  return (
    <figcaption
      sx={{
        maxWidth: [539, null, null, null, 'auto'],
        mx: ['auto', null, null, null, 0],
        order: [null, null, null, null, 1],
        pl: [null, null, null, null, 40],
        textAlign: ['center', null, null, null, 'left'],
      }}
    >
      {children}
    </figcaption>
  );
};

export default FigureCaption;
