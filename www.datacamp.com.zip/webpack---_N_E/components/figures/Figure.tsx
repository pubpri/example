import React from 'react';

type Props = {
  children?: React.ReactNode;
  className?: string;
  inverted?: boolean;
};

const Figure: React.FC<Props> = ({ children, className, inverted }) => {
  return (
    <figure
      className={className}
      sx={{
        flexDirection: inverted ? 'row-reverse' : 'row',
      }}
    >
      {children}
    </figure>
  );
};

export default Figure;
