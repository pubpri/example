import Image from 'next/image';
import React from 'react';
import { Flex } from 'theme-ui';

import Figure from './Figure';
import FigureCaption from './FigureCaption';
import FigureCaptionText from './FigureCaptionText';

type Props = {
  inverted?: boolean;
};

const CampusExerciseFigure: React.FC<Props> = ({ inverted }) => {
  return (
    <Figure
      inverted={inverted}
      sx={{
        '> *': { width: [null, null, null, null, '50%'] },
        alignItems: [null, null, null, null, 'center'],
        display: [null, null, null, null, 'flex'],
        mt: [80, null, null, null, 70],
      }}
    >
      <FigureCaption>
        <FigureCaptionText
          captions={[
            'No installation required',
            '— run code from your browser',
          ]}
          colors={['blue.200', 'white']}
        />
      </FigureCaption>
      <Flex
        sx={{
          alignItems: 'flex-start',
          flexShrink: 0,
          img: {
            aspectRatio: `${1022 / 580}`,
            height: 'auto',
            maxWidth: ['100%', null, null, 511],
          },
          justifyContent: ['center', null, null, null, 'flex-end'],
          mt: [16, null, null, null, 0],
          mx: ['auto', null, null, null, 0],
          pr: [null, null, null, null, 40],
        }}
      >
        <Image
          alt="Screenshot of Campus exercise"
          height={292}
          src="/Marketing/Screenshots/screenshot-campus-encoding-time.png"
          width={511}
        />
      </Flex>
    </Figure>
  );
};

export default CampusExerciseFigure;
