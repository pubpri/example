import Image from 'next/image';
import React from 'react';
import { Flex } from 'theme-ui';

import Figure from './Figure';
import FigureCaption from './FigureCaption';
import FigureCaptionText from './FigureCaptionText';

type Props = {
  highlightColor?: string;
};
const LearningExperienceFigure: React.FC<Props> = ({ highlightColor }) => {
  return (
    <Figure
      sx={{
        '> *': { width: [null, null, null, null, '50%'] },
        alignItems: [null, null, null, null, 'center'],
        display: [null, null, null, null, 'flex'],
        mt: [80, null, null, null, 144],
      }}
    >
      <FigureCaption>
        <FigureCaptionText
          captions={['Interactive exercises', 'short videos']}
          colors={[
            highlightColor || 'yellow.200',
            highlightColor || 'yellow.200',
          ]}
          sx={{ maxWidth: 372, mx: ['auto', null, null, null, 0] }}
        />
      </FigureCaption>
      <Flex
        sx={{
          alignItems: 'flex-start',
          flexShrink: 0,
          img: {
            aspectRatio: `${948 / 688}`,
            height: 'auto',
            maxWidth: ['100%', null, null, 473],
          },
          justifyContent: ['center', null, null, null, 'flex-end'],
          mt: [16, null, null, null, 0],
          mx: ['auto', null, null, null, 0],
          pr: [null, null, null, null, 40],
        }}
      >
        <Image
          alt="Screenshot of campus exercise with photo of Richie Cotton"
          height={344}
          src="/Marketing/Illustrations/hands-on-learning-experience.png"
          width={473}
        />
      </Flex>
    </Figure>
  );
};

export default LearningExperienceFigure;
