import Image from 'next/image';
import React from 'react';
import { Flex } from 'theme-ui';

import Figure from './Figure';
import FigureCaption from './FigureCaption';
import FigureCaptionText from './FigureCaptionText';

type Props = {
  inverted?: boolean;
};

const InstructorsFigure: React.FC<Props> = ({ inverted }) => {
  return (
    <Figure
      inverted={inverted}
      sx={{
        '> *': { width: [null, null, null, null, '50%'] },
        alignItems: [null, null, null, null, 'center'],
        display: [null, null, null, null, 'flex'],
        mt: [80, null, null, null, 144],
      }}
    >
      <FigureCaption>
        <FigureCaptionText
          captions={['Learn from the ', 'best instructors']}
          colors={['white', 'purple.200']}
          sx={{ maxWidth: 254, mx: ['auto', null, null, null, 0] }}
        />
      </FigureCaption>
      <Flex
        sx={{
          alignItems: 'flex-start',
          flexShrink: 0,
          img: {
            aspectRatio: `${902 / 728}`,
            height: 'auto',
            maxWidth: ['100%', null, null, 451],
          },
          justifyContent: ['center', null, null, null, 'flex-start'],
          mt: [16, null, null, null, 0],
          mx: ['auto', null, null, null, 0],
          pr: [null, null, null, null, 40],
        }}
      >
        <Image
          alt="Screenshot of Campus exercise"
          height={364}
          src="/Marketing/Illustrations/instructors.jpg"
          width={451}
        />
      </Flex>
    </Figure>
  );
};

export default InstructorsFigure;
