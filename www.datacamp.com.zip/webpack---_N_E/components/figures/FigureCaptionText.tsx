import React from 'react';
import { Text } from 'theme-ui';

type Props = {
  captions?: string[];
  children?: React.ReactNode;
  className?: string;
  colors?: string[];
};

const FigureCaptionText: React.FC<Props> = ({
  captions,
  children,
  className,
  colors,
}) => {
  return (
    <Text as="p" className={className} variant="h32">
      <span sx={{ color: colors ? colors[0] : 'white' }}>
        {captions ? captions[0] : ''}
      </span>
      <span sx={{ color: colors ? colors[1] : 'white' }}>
        {' '}
        {captions ? captions[1] : ''}
      </span>
      {children}
    </Text>
  );
};

export default FigureCaptionText;
