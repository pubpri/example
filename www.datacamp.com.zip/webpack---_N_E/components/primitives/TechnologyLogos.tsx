/** @jsxRuntime automatic */
/** @jsxImportSource theme-ui */
import React from 'react';

import Excel from 'assets/svg/technologies/excel.svg';
import ExcelTwo from 'assets/svg/technologies/excel-two.svg';
import Git from 'assets/svg/technologies/git.svg';
import Postgres from 'assets/svg/technologies/postgres.svg';
import PowerBi from 'assets/svg/technologies/power-bi.svg';
import Python from 'assets/svg/technologies/python.svg';
import R from 'assets/svg/technologies/r.svg';
import Scala from 'assets/svg/technologies/scala.svg';
import Shell from 'assets/svg/technologies/shell.svg';
import Spark from 'assets/svg/technologies/spark.svg';
import Spreadsheets from 'assets/svg/technologies/spreadsheets.svg';
import SqlServer from 'assets/svg/technologies/sql-server.svg';
import Tableau from 'assets/svg/technologies/tableau.svg';

type TechnologyLogosProps = {
  className?: string;
  color?: string;
  single?: string;
  singleWidth?: string;
};

const TechnologyLogos: React.FC<TechnologyLogosProps> = ({
  className,
  color,
  single,
  singleWidth,
}) => {
  const logos = {
    Excel,
    Git,
    Postgres,
    PowerBi,
    Python,
    R,
    Scala,
    Shell,
    Spark,
    Spreadsheets,
    SqlServer,
    Tableau,
  } as {
    [key: string]: React.FunctionComponent<React.SVGAttributes<SVGElement>>;
  };

  const Logo = (single && logos[single]) || Python;
  return (
    <>
      {single ? (
        <span className={className}>
          <i aria-hidden="true" sx={{ color: color || '' }}>
            <Logo className={single} width={singleWidth} />
          </i>
          <span className="visually-hidden">{single}</span>
        </span>
      ) : (
        <>
          <span>
            <i aria-hidden="true">
              <Python className="python" width="82" />
            </i>
            <span className="visually-hidden">Python</span>
          </span>
          <span>
            <i aria-hidden="true">
              <R className="r" width="19" />
            </i>
            <span className="visually-hidden">R</span>
          </span>
          <span>
            <i aria-hidden="true">
              <Postgres className="postgres" width="138" />
            </i>
            <span className="visually-hidden">PostgreSQL</span>
          </span>
          <span>
            <i aria-hidden="true">
              <Tableau className="tableau" width="116" />
            </i>
            <span className="visually-hidden">Tableau</span>
          </span>
          <span>
            <i aria-hidden="true">
              <PowerBi className="powerBi" width="91" />
            </i>
            <span className="visually-hidden">Power BI</span>
          </span>
          <span>
            <i aria-hidden="true">
              <ExcelTwo className="excel" width="62" />
            </i>
            <span className="visually-hidden">Excel</span>
          </span>
          <span>
            <i aria-hidden="true">
              <SqlServer className="sqlServer" width="108" />
            </i>
            <span className="visually-hidden">SQL Server</span>
          </span>
          <span>
            <i aria-hidden="true">
              <Git className="git" width="40" />
            </i>
            <span className="visually-hidden">Git</span>
          </span>
          <span>
            <i aria-hidden="true">
              <Shell className="shell" width="62" />
            </i>
            <span className="visually-hidden">Shell</span>
          </span>
          <span>
            <i aria-hidden="true">
              <Scala className="scala" width="62" />
            </i>
            <span className="visually-hidden">Scala</span>
          </span>
          <span>
            <i aria-hidden="true">
              <Spark className="spark" width="42" />
            </i>
            <span className="visually-hidden">Spark</span>
          </span>
          <span>
            <i aria-hidden="true">
              <Spreadsheets className="spreadsheets" width="100" />
            </i>
            <span className="visually-hidden">Spreadsheets</span>
          </span>
        </>
      )}
    </>
  );
};

export default TechnologyLogos;
