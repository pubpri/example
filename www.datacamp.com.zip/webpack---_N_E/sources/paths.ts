export const careers = {
  DATA_ANALYST: '/tracks/data-analyst-in-sql',
  DATA_ENGINEER: '/tracks/data-engineer-with-python',
  DATA_SCIENTIST: '/tracks/data-scientist-with-python',
  MACHINE_LEARNING_SCIENTIST: '/tracks/machine-learning-scientist-with-python',
  PROGRAMMER: '/tracks/r-programmer',
  STATISTICIAN: '/tracks/statistician-with-r',
};

export const skills = {
  APPLIED_FINANCE: '/tracks/applied-finance-in-r',
  DATA_LITERACY: '/tracks/data-literacy-fundamentals',
  DATA_VISUALIZATION: '/tracks/data-visualization-with-r',
  MACHINE_LEARNING: '/tracks/machine-learning-fundamentals-with-python',
  MARKETING_ANALYTICS: '/tracks/marketing-analytics-with-python',
  NLP: '/tracks/natural-language-processing-in-python',
  SQL_FUNDAMENTALS: '/tracks/sql-fundamentals',
  STATISTICS: '/tracks/statistics-fundamentals-with-python',
};

export const technologies = {
  EXCEL_PATH: '/courses/data-analysis-in-excel',
  GIT_PATH: '/courses/introduction-to-git',
  ORACLE_PATH: '/courses/introduction-to-oracle-sql',
  POWER_BI_PATH: '/courses/introduction-to-power-bi',
  PYTHON_PATH: '/courses/intro-to-python-for-data-science',
  R_PATH: '/courses/free-introduction-to-r',
  SCALA_PATH: '/courses/introduction-to-scala',
  SHELL_PATH: '/courses/introduction-to-shell',
  SPARK_PATH: '/courses/introduction-to-spark-sql-in-python',
  SPREADSHEETS_PATH: '/courses/introduction-to-spreadsheets',
  SQL_PATH: '/courses/introduction-to-sql',
  TABLEAU_PATH: '/courses/introduction-to-tableau',
};

export const careerLinks = [
  {
    name: 'Data Scientist',
    path: careers.DATA_SCIENTIST,
  },
  {
    name: 'Machine Learning Scientist',
    path: careers.MACHINE_LEARNING_SCIENTIST,
  },
  {
    name: 'Data Engineer',
    path: careers.DATA_ENGINEER,
  },
  {
    name: 'Data Analyst',
    path: careers.DATA_ANALYST,
  },
  {
    name: 'Statistician',
    path: careers.STATISTICIAN,
  },
  { name: 'Programmer', path: careers.PROGRAMMER },
];

export const skillLinks = [
  { name: 'SQL Fundamentals', path: skills.SQL_FUNDAMENTALS },
  {
    name: 'Data Literacy',
    path: skills.DATA_LITERACY,
  },
  {
    name: 'Machine Learning',
    path: skills.MACHINE_LEARNING,
  },
  {
    name: 'Statistics',
    path: skills.STATISTICS,
  },
  {
    name: 'Marketing Analytics',
    path: skills.MARKETING_ANALYTICS,
  },
  {
    name: 'NLP',
    path: skills.NLP,
  },
  {
    name: 'Applied Finance',
    path: skills.APPLIED_FINANCE,
  },
  {
    name: 'Data Visualization',
    path: skills.DATA_VISUALIZATION,
  },
];

export const technologyLinks = [
  {
    path: technologies.PYTHON_PATH,
    prop: 'Python',
    width: '138',
  },
  {
    path: technologies.R_PATH,
    prop: 'R',
    width: '37',
  },
  {
    path: technologies.SQL_PATH,
    prop: 'Postgres',
    width: '160',
  },
  {
    path: technologies.TABLEAU_PATH,
    prop: 'Tableau',
    width: '179',
  },
  {
    path: technologies.POWER_BI_PATH,
    prop: 'PowerBi',
    width: '138',
  },
  {
    path: technologies.EXCEL_PATH,
    prop: 'Excel',
    width: '116',
  },
  {
    path: technologies.SPREADSHEETS_PATH,
    prop: 'Spreadsheets',
    width: '160',
  },
  {
    path: technologies.SCALA_PATH,
    prop: 'Scala',
    width: '93',
  },
  {
    path: technologies.SPARK_PATH,
    prop: 'Spark',
    width: '80',
  },
  {
    path: technologies.SHELL_PATH,
    prop: 'Shell',
    width: '113',
  },
  {
    path: technologies.GIT_PATH,
    prop: 'Git',
    width: '73',
  },
];

export const b2bPaths = [
  '/blackrock-future-skills-training',
  '/business',
  '/business/demo',
  '/business/direct',
  '/groups/business',
  '/groups/business/custom-learning-solutions',
  '/groups/business/data-science-for-managers-free-trial',
  '/groups/business/customer-success',
  '/groups/business/integration',
  '/groups/business/reporting',
  '/learning-and-development-training',
  '/data-science-training-for-team-managers',
  '/roche-online-training',
  '/engie-online-training',
  '/uniper-online-training',
  '/natwest-future-skills-training',
  '/rolls-royce-online-training',
  '/hp-inc-future-skills-training',
  '/us-army-future-skills-training',
  '/us-air-force-future-skills-training',
  '/degreed-data-science-training',
  '/webinars',
  '/webinars/[slug]',
  '/business/partners/[slug]',
  '/business/build-the-future',
  '/compare-business-plans',
  '/hire-data-professionals',
];

export const pathsWithBusinessBanner = [
  '/courses/data-science-for-business',
  '/courses/machine-learning-for-business',
  '/courses/marketing-analytics-for-business',
  '/courses/data-driven-decision-making-for-business',
  '/courses/business-process-analytics-in-r',
  '/courses/analyzing-business-data-in-sql',
  '/tracks/foundational-data-skills-for-business-leaders',
  '/courses/financial-modeling-in-spreadsheets',
];

export const promoExclusionPaths: Array<string | RegExp> = [
  '/about/leadership',
  '/cookie-notice',
  '/data-processing-addendum',
  '/do-not-sell-my-personal-information',
  '/interactive-learning',
  '/pricing/learn/enterprise',
  '/pricing/workspace/enterprise',
  '/pricing/b2c',
  '/pricing', // show the free week banner on these during free week
  '/privacy-policy',
  '/privacy-policy/cookie_table',
  '/summerchallenge',
  '/terms-of-use',
  '/upgrade/professional',
  '/workspacecompetition',
  '/freeweek',
  '/freeweek-learn-teams',
  '/data-literacy-month',
  '/data-literacy-month/for-teams',
  '/analyst-takeover-2022',
  '/data-driven-organizations-2022',
  /\/workspace\/sign_up.*/,
  /\/hire-data-professionals\/sign_up.*/,
  /\/promo\.*/,
  /\/resources\.*/,
  ...b2bPaths,
  ...pathsWithBusinessBanner,
];

export const navbarExclusionPaths = [
  '/blackrock-future-skills-training',
  '/business',
  '/business/demo',
  '/business/direct',
  '/data-literacy-month',
  '/data-literacy-month/for-teams',
  '/groups/business/data-science-for-managers-free-trial',
  '/landing/1',
  '/landing/for-everyone',
  '/temp/checkout',
  '/webinars/[slug]',
  '/resources/[tag]/[slug]',
  '/webinars/datacamp-in-action-data-upskilling-for-your-organization',
  '/live/[slug]',
  '/promo/[slug]',
  '/promo/coming-soon-twosday',
  '/promo/zero-to-job-ready-sale-2022',
  '/why-datacamp',
  '/roche-online-training',
  '/engie-online-training',
  '/uniper-online-training',
  '/natwest-future-skills-training',
  '/rolls-royce-online-training',
  '/hp-inc-future-skills-training',
  '/us-army-future-skills-training',
  '/us-air-force-future-skills-training',
  '/business/partners/[slug]',
  '/business/build-the-future',
  '/promo/july-annual-sale-2022',
  '/workspace/sign_up',
  '/promo/workspace-launch-sale',
  '/freeweek',
  '/freeweek-learn-teams',
  '/promo/world-space-week-2022',
  '/hire-data-professionals/sign_up',
];

export const marketoInclusionPaths = [
  '/hire-data-professionals',
  '/business',
  '/business/demo',
  '/business/direct',
  '/degreed-data-science-training',
  '/webinars/[slug]',
  '/groups/classrooms',
  '/resources/[[...slug]]',
  '/resources/[tag]/[slug]',
  '/learning-and-development-training',
  '/data-science-training-for-team-managers',
  '/pricing/learn/enterprise',
  '/pricing/workspace/enterprise',
  '/pricing',
  '/compare-business-plans',
  '/groups/business',
  '/freeweek-learn-teams',
  '/freeweek',
  '/data-literacy-month/for-teams',
];

export const noMenuNavbar = [
  '/blog',
  '/cheat-sheet',
  '/podcast',
  '/search-resources',
  '/tutorial',
];

export const demoWebinarBannerInclusionPaths: Array<string | RegExp> = [
  /\/groups\/business.*/,
];

export const b2bBannerInclusionPaths: Array<string | RegExp> = [
  /\/groups\/business.*/,
  /\/resources\/.*/,
];

// This object can be used to configure where the user will be redirected
// after signin/signup based on the path they're on when they click the button.
//
// Paths starting with the path defined here will also match.
//
// for example: { '/groups/business': '/some-redirect-path' }
export const signInRedirectPaths: { [path: string]: string | undefined } = {
  '/hire-data-professionals/sign_up': '/recruit',
  '/workspace': '/workspace',
};

export const pathsWithCustomSeo = [
  '/blog/category/[category]',
  '/blog/category/[category]/page/[number]',
  '/blog',
  '/blog/[slug]',
  '/blog/page/[number]',
  '/business/partners/[slug]',
  '/e-books/[slug]',
  '/podcast/[slug]',
  '/podcast/page/[number]',
  '/podcast',
  '/podcast/category/[category]',
  '/podcast/category/[category]/page/[number]',
  '/learn/[slug]',
  '/courses/[slug]',
  '/tracks/[slug]',
  '/data-courses/[slug]',
  '/tutorial/[slug]',
  '/tutorial/page/[number]',
  '/tutorial',
  '/tutorial/category/[category]',
  '/tutorial/category/[category]/page/[number]',
  '/cheat-sheet/[slug]',
  '/cheat-sheet/page/[number]',
  '/cheat-sheet',
  '/cheat-sheet/category/[category]',
  '/cheat-sheet/category/[category]/page/[number]',
];
