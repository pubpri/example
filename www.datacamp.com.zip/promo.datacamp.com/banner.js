! function(e, n) {
    function t() {
        var t, o, a, i = document,
            r = "b2cNonPaying" === n ? "PROMOBANNER-" : "ATO-banner",
            c = e.data,
            s = (new Date).getTime() + 1e3 * c.time_remaining_in_seconds,
            d = "Triggered" === c.type || c.time_remaining_in_seconds < 604800,
            l = c.time_remaining_in_seconds < 86400,
            p = {
                b2cNonPaying: {
                    backgroundColor: "#65FF8F",
                    textColor: "#05192D",
                    fill: "#03EF62",
                    title: "SQL, Power BI and Tableau courses and data analyst certifications on sale.",
                    discount: !0,
                    timer: !0,
                    url: "https://www.datacamp.com/analyst-takeover-2022",
                    breakpoints: {
                        hideLogo: 1176,
                        smallText: 1470,
                        moveDiscount: 700
                    }
                },
                b2cPaid: {
                    backgroundColor: "#974DFF",
                    textColor: "#ffffff",
                    fill: "#7933FF",
                    title: "Live events: How to become a Data Analyst & Why Get Certified",
                    discount: !1,
                    timer: !1,
                    url: "https://www.datacamp.com/analyst-takeover-2022",
                    breakpoints: {
                        hideLogo: 1176,
                        smallText: 1290,
                        moveDiscount: 899
                    }
                },
                b2bNonPaying: {
                    backgroundColor: "#60E7FF",
                    textColor: "#05192D",
                    fill: "#06BDFC",
                    title: "Click here for resources on SQL, Tableau and Power BI",
                    discount: !0,
                    timer: !0,
                    url: "https://www.datacamp.com/data-driven-organizations-2022",
                    breakpoints: {
                        hideLogo: 1120,
                        smallText: 900,
                        moveDiscount: 0
                    }
                },
                b2bPaid: {
                    backgroundColor: "#FFBC4B",
                    textColor: "#05192D",
                    fill: "#FF931E",
                    title: "Click here for resources on SQL, Tableau and Power BI",
                    discount: !1,
                    timer: !1,
                    url: "https://www.datacamp.com/data-driven-organizations-2022",
                    breakpoints: {
                        hideLogo: 1120,
                        smallText: 900,
                        moveDiscount: 899
                    }
                }
            };
        if (!i.querySelector(".dc-ps-banner-wrapper") && (o = r + c.promo_key, !(a = i.cookie.match("(^|;) ?" + o + "=([^;]*)(;|$)")) || !a[2])) {
            var u = c.presentation_data || {
                    background_color: "#65FF8F",
                    background_color_hex: "#06bdfc",
                    countdown_text: "Offer ends in ",
                    text_color: "#05192d",
                    banner_text: "Supercharge your career with data literacy",
                    upgrade_banner_text: "Supercharge your career with data literacy",
                    banner_rect_colors: ["#7933FF", "#fcce0d", "#fcce0d", "#06BDFC"],
                    banner_rect_colors_emphasis: ["#7933FF", "#fcce0d", "#fcce0d", "#06BDFC"],
                    pricing_accent_color: "#60E7FF",
                    pricing_card_background_color: "linear-gradient(44.43deg, #60E7FF 24.91%, #06BDFC 71.14%)",
                    countdown_bar_background_color: "linear-gradient(83.1deg, #60E7FF 14.73%, #06BDFC 101.28%)",
                    time_background_color: "#05192d",
                    time_color: "#ffffff",
                    time_background_color_emphasis: "#05192d",
                    time_color_emphasis: "#ffffff"
                },
                m = i.getElementsByTagName("body"),
                g = (m[0].firstChild, l ? u.time_background_color_emphasis : u.time_background_color),
                h = l ? u.time_color_emphasis : u.time_color;
            l ? u.banner_rect_colors_emphasis : u.banner_rect_colors, countdownMarkup = 1 == d ? "<p class='dc-ps-banner-countdown'>" + u.countdown_text + "<time class='dc-ps-banner-time' data-countdown-wrapper><span data-countdown-days></span><span data-countdown-days-unit></span><span data-countdown-hours></span><span data-countdown-hours-unit></span><span data-countdown-minutes></span><span data-countdown-minutes-unit></span><span data-countdown-seconds></span><span data-countdown-seconds-unit></span><span class='dc-ps-banner-time-icon'><svg width='12' height='12' viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'><path d='M5.69 17.92a1.7 1.7 0 0 1-1.197-2.896l6.09-6.115-6.09-6.115A1.7 1.7 0 0 1 6.888.4l7.3 7.3a1.7 1.7 0 0 1 0 2.394l-7.3 7.299c-.312.33-.743.52-1.197.528z' fill='" + h + "' fill-rule='nonzero' /></svg></span></time></p>" : "", closeMarkup = "<button class='dc-ps-close' aria-label='Close' data-promo-close><svg width='18' height='18' viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'><path d='M6.86 9l-5.417 5.416a1.514 1.514 0 0 0 2.14 2.14L9 11.14l5.416 5.417a1.514 1.514 0 0 0 2.14-2.14L11.14 9l5.417-5.416a1.514 1.514 0 0 0-2.14-2.14L9 6.86 3.584 1.443a1.514 1.514 0 0 0-2.14 2.14L6.86 9z' fill='currentColor' fill-rule='nonzero' /></svg></button>", styles = "<style> @keyframes slideIn { to { max-height: 500px; opacity: 1; } } @keyframes slideOut { from { max-height: 500px; opacity: 1; } to { max-height: 0; opacity: 0.25; } } .dc-ps-banner-wrapper { font-family: Studio-Feixen-Sans, Arial; overflow: hidden; position: -webkit-sticky; position: sticky; top: 0; -webkit-font-smoothing: antialiased; z-index: 1080; } .dc-ps-banner { animation: 1s cubic-bezier(0.77, 0, 0.175, 1) 0.5s forwards slideIn; background: " + p[n].backgroundColor + "; border: 0; color: " + u.text_color + " !important; display: flex;  justify-content: center; max-height: 0; opacity: 0.25; overflow: hidden; transition: max-height 0.5s cubic-bezier(0.77, 0, 0.175, 1); text-decoration: none; } .dc-ps-banner.dc-is-hidden { animation: 0.5s cubic-bezier(0.77, 0, 0.175, 1) slideOut; } .dc-ps-banner:hover { text-decoration: none; } .dc-ps-banner-content {min-height: 62px; display: flex; justify-content: center; align-items: center; flex-direction: column; margin: 6px 42px 12px 12px; position: relative; text-align: center; } .dc-ps-banner-heading { color: " + p[n].textColor + " !important; font-size: 18px; margin: 0px; } .dc-ps-banner-no-countdown { display: inline-block; font-weight: bold; line-height: 1; margin: 4px 0 0 0; padding: 6px 30px; text-transform: uppercase;  background: " + g + "; border-radius: 16px; color: " + h + ";   } .dc-ps-banner-countdown { display: " + (p[n].timer ? "block;" : "none;") + " margin: 4px 0 0 0; } .dc-ps-banner-time { align-items: center; background: " + g + "; border-radius: 4px; color: " + h + "; display: inline-flex; font-weight: bold; line-height: 1; padding: 4px 6px 4px 4px; margin-top: 8px} .dc-ps-banner-time > span { padding-left: 4px; } .dc-ps-banner-time-icon { position: relative; top: 1px; } .dc-ps-close {color: " + p[n].textColor + "; background: none; border: 0; cursor: pointer; position: absolute; right: 8px; top: calc(50% - 10px); transition: opacity 0.3s cubic-bezier(0.77, 0, 0.175, 1); z-index: 1090; } .dc-ps-close:hover { opacity: 0.8; } .things { display: none; } .dc-ps-circle-discount { position: absolute; top: 0; right: 120px; z-index: 1; align-items: center; background-color: #FCCE0D; border-radius: 50%; display: " + (p[n].discount ? "flex;" : "none;") + " flex-direction: column; flex-shrink: 0; font-weight: bold; justify-content: center; height: 66px; margin: 4px 0; width: 66px; } .dc-ps-circle-text { align-items: center; display: flex; flex-direction: column; justify-content: center; line-height: 1; text-transform: uppercase; transform: rotate(15deg); color: #05192d; } .circle-sm { font-size: 8px; } .circle-md { font-size: 15px; } .circle-lg { font-size: 20px; } @media screen and (min-width: " + p[n].breakpoints.smallText + "px) { .dc-ps-banner-heading { font-size: 30px; margin: 0; } } @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) { .dc-ps-banner-wrapper { position: relative; } } .r1, .r2 { y: -600; } .r3, .r4 { y: 600; } @media screen and (min-width: 820px) { @keyframes leftSwoops { from { y: -600; } to { y: 600; } } @keyframes rightSwoops { from { y: 600; } to { y: -600; } }  .things { bottom: 0; display: block; left: 0; position: absolute; color: " + p[n].fill + " } .thing-left { position: absolute; left: calc(50% - 220px); top: -108px; z-index:-1;} .thing-right { position: absolute; left: calc(50% + 700px); top: -112px; z-index:-1;} .logo-left { position: absolute; left: 32px; top: 8px; z-index:1;} } @media screen and (max-width: " + p[n].breakpoints.hideLogo + "px) { .hide-on-small {display: none; } " + ("b2bNonPaying" === n ? ".dc-ps-circle-discount { right: 60px;" : ".dc-ps-circle-discount { right: calc(50% - 400px);") + "} @media screen and (max-width: " + p[n].breakpoints.moveDiscount + "px) { .dc-ps-circle-discount { right: calc(50% - 280px); }} @media screen and (max-width: 767px) { .dc-ps-circle-discount { display: none; } } @media screen and (max-width: 608px) { .dc-ps-banner-countdown { display: none; } }</style>", bannerMarkup = "<img alt='Data literacy month logo' class='logo-left hide-on-small'" + function(e) {
                switch (e) {
                    case "b2cPaid":
                        return "src='https://res.cloudinary.com/dyd911kmh/image/upload/v1665583993/Marketing/Oneoffs/analyst-takeover-2022/the-analyst-takeover-white.svg' width='140' />";
                    case "b2cNonPaying":
                        return "src='https://res.cloudinary.com/dyd911kmh/image/upload/v1665583993/Marketing/Oneoffs/analyst-takeover-2022/the-analyst-takeover-navy.svg' width='140' />";
                    case "b2cPaid":
                        return "src='https://res.cloudinary.com/dyd911kmh/image/upload/v1665583993/Marketing/Oneoffs/analyst-takeover-2022/the-analyst-takeover-white.svg' width='140' />";
                    default:
                        return "src='https://res.cloudinary.com/dyd911kmh/image/upload/v1665583993/Marketing/Oneoffs/analyst-takeover-2022/become-a-data-driven-organization-navy.svg' width='140' />"
                }
            }(n) + "<div class='dc-ps-circle-discount'><div class='dc-ps-circle-text'><span class='circle-sm'>Up to</span><span class='circle-lg'>60%</span><span class='circle-md'>Off</span></div></div><a class='dc-ps-banner' data-ps-banner href='" + p[n].url + "'><div class='dc-ps-banner-content'><h5 class='dc-ps-banner-heading'>" + p[n].title + "</h5>" + countdownMarkup + '<div class=\'things\'><svg class="thing-left" width="164" height="159" viewBox="0 0 164 159" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M73.1746 36.4315C73.1746 56.1324 57.5399 72.1583 38.0132 72.8127C37.728 72.8127 37.4596 72.8295 37.1744 72.8295C37.0402 72.8295 36.9061 72.8295 36.7718 72.8295L36.6879 72.8295C36.6879 72.8295 36.6041 72.8295 36.5538 72.8295L36.4028 72.8295C16.3058 72.8295 -1.42596e-06 56.5184 -3.18348e-06 36.4148C-4.94099e-06 16.3111 16.289 5.95745e-06 36.4028 4.19905e-06L36.4698 4.19318e-06C36.5873 4.18292e-06 36.7047 4.17265e-06 36.8222 4.16238e-06C56.9192 2.40545e-06 73.2249 16.2944 73.2249 36.4148L73.1578 36.4148" fill="currentColor"/><path d="M163.175 122.432C163.175 142.132 147.54 158.158 128.013 158.813C127.728 158.813 127.46 158.83 127.174 158.83C127.04 158.83 126.906 158.83 126.772 158.83L126.688 158.83C126.688 158.83 126.604 158.83 126.554 158.83L126.403 158.83C106.306 158.83 90 142.518 90 122.415C90 102.311 106.289 86 126.403 86L126.47 86C126.587 86 126.705 86 126.822 86C146.919 86 163.225 102.294 163.225 122.415L163.158 122.415" fill="currentColor"/></svg><svg class="thing-right" width="324" height="159" viewBox="0 0 324 159" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M73.1746 36.602C73.1746 56.3029 57.5399 72.3288 38.0132 72.9832C37.728 72.9832 37.4596 73 37.1744 73C37.0402 73 36.9061 73 36.7718 73L36.6879 73C36.6879 73 36.6041 73 36.5538 73L36.4028 73C16.3058 73 -1.42596e-06 56.6889 -3.18348e-06 36.5852C-4.94099e-06 16.4816 16.289 0.170477 36.4028 0.170475L36.4698 0.170475C36.5873 0.170475 36.7047 0.170475 36.8222 0.170475C56.9192 0.170474 73.2249 16.4648 73.2249 36.5852L73.1578 36.5852" fill="currentColor"/><path d="M153.175 36.602C153.175 56.3029 137.54 72.3288 118.013 72.9832C117.728 72.9832 117.46 73 117.174 73C117.04 73 116.906 73 116.772 73L116.688 73C116.688 73 116.604 73 116.554 73L116.403 73C96.3058 73 80 56.6889 80 36.5852C80 16.4816 96.289 0.170477 116.403 0.170475L116.47 0.170475C116.587 0.170475 116.705 0.170475 116.822 0.170475C136.919 0.170474 153.225 16.4648 153.225 36.5852L153.158 36.5852" fill="currentColor"/><path d="M203.175 36.602C203.175 56.3029 187.54 72.3288 168.013 72.9832C167.728 72.9832 167.46 73 167.174 73C167.04 73 166.906 73 166.772 73L166.688 73C166.688 73 166.604 73 166.554 73L166.403 73C146.306 73 130 56.6889 130 36.5852C130 16.4816 146.289 0.170477 166.403 0.170475L166.47 0.170475C166.587 0.170475 166.705 0.170475 166.822 0.170475C186.919 0.170474 203.225 16.4648 203.225 36.5852L203.158 36.5852" fill="currentColor"/><path d="M323.175 122.602C323.175 142.303 307.54 158.329 288.013 158.983C287.728 158.983 287.46 159 287.174 159C287.04 159 286.906 159 286.772 159L286.688 159C286.688 159 286.604 159 286.554 159L286.403 159C266.306 159 250 142.689 250 122.585C250 102.482 266.289 86.1705 286.403 86.1705L286.47 86.1705C286.587 86.1705 286.705 86.1705 286.822 86.1705C306.919 86.1705 323.225 102.465 323.225 122.585L323.158 122.585" fill="currentColor"/></svg></div></div></a>' + closeMarkup + styles, (t = i.createElement("article")).classList.add("dc-ps-banner-wrapper"), m[0].insertAdjacentElement("afterbegin", t), t.innerHTML = bannerMarkup, i.querySelector("[data-promo-close]").addEventListener("click", function() {
                var e, t, o = i.querySelector("[data-ps-banner]"),
                    a = i.querySelector(".dc-ps-banner-wrapper");
                o.classList.add("dc-is-hidden"), e = r + c.promo_key, t = "b2cNonPaying" === n ? (new Date).getTime() + 2592e5 : (new Date).getTime() + 6048e5, i.cookie = e + "=1;path=/;domain=datacamp.com;expires=" + new Date(t).toUTCString(), void 0 !== window.dcmfeSnowplow ? window.dcmfeSnowplow("trackStructEvent", {
                    category: "promo_banner",
                    action: "close",
                    label: c.title,
                    property: "",
                    value: c.time_remaining_in_seconds
                }) : void 0 !== window.snowplow && window.snowplow("trackStructEvent", "promo_banner", "close", c.title, "", c.time_remaining_in_seconds), setTimeout(function() {
                    a.parentNode.removeChild(a)
                }, 1e3)
            }), !0 === d && function(e) {
                i.querySelector("[data-countdown-wrapper]");
                var n = i.querySelector("[data-countdown-days]"),
                    t = i.querySelector("[data-countdown-days-unit]"),
                    o = i.querySelector("[data-countdown-hours]"),
                    a = i.querySelector("[data-countdown-hours-unit]"),
                    r = i.querySelector("[data-countdown-minutes]"),
                    s = i.querySelector("[data-countdown-minutes-unit]"),
                    d = i.querySelector("[data-countdown-seconds]");
                elCountdownSecondsUnit = i.querySelector("[data-countdown-seconds-unit]");
                var l, p, u, m, g = function(e, n, t) {
                    return 1 === e ? n : t
                };
                isNaN(e) || setInterval(function() {
                    var e, i;
                    c.time_remaining_in_seconds--, e = c.time_remaining_in_seconds, (i = parseInt(e)) >= 0 && (l = parseInt(i / 86400), i %= 86400, p = parseInt(i / 3600), i %= 3600, u = parseInt(i / 60), i %= 60, m = parseInt(i), n.innerHTML = parseInt(l, 10), t.innerHTML = g(l, "day", "days"), o.innerHTML = ("0" + p).slice(-2), a.innerHTML = g(p, "hr", "hrs"), r.innerHTML = ("0" + u).slice(-2), s.innerHTML = g(u, "min", "mins"), d.innerHTML = ("0" + m).slice(-2), elCountdownSecondsUnit.innerHTML = g(m, "sec", "secs"))
                }, 1e3)
            }(s), void 0 !== window.dcmfeSnowplow ? window.dcmfeSnowplow("trackStructEvent", {
                category: "promo_banner",
                action: "open",
                label: c.title,
                property: "",
                value: c.time_remaining_in_seconds
            }) : void 0 !== window.snowplow && window.snowplow("trackStructEvent", "promo_banner", "open", c.title, "", c.time_remaining_in_seconds)
        }
    }

    function o() {
        return "interactive" === document.readyState || "complete" === document.readyState
    }
    o() ? t() : document.onreadystatechange = function() {
        o() && t()
    }
}({
    "eligible": true,
    "data": {
        "remaining_discounted_subscriptions": 1,
        "all_coupon_codes": ["REGISTRATION-INTROOFFER", "INTRODISCOUNT_COURSE_COMPLETED", "INTRODISCOUNT_COURSE_COMPLETED_EM", "INTRO-ABANDON-CART", "INTRO-ACTIVATE-PROMO", "INTRO-ACTIVATE", "INTRO-COMEBACK-14-PROMO", "INTRO-COMEBACK-14", "INTRODISCOUNT_PREMIUM_EMERGING_75", "INTRODISCOUNT_PREMIUM", "INTRO-UPSELL-ANNUAL", "INTRO-UPSELL-ANNUAL-PROMO", "INTRO-WINBACK", "INTRO-WINBACK-EM", "OCT2022-EAST-EUR2", "OCT2022-LEARN-TEAMS", "OCT2022-EAST-EUR1", "OCT2022-AA-PROMO", "OCT2022-SEUR", "OCT2022-TIER2", "OCT2022-N-EUR", "OCT2022-UK", "OCT2022-TIER-1"],
        "coupon_codes": ["OCT2022-EAST-EUR2", "OCT2022-LEARN-TEAMS", "OCT2022-EAST-EUR1", "OCT2022-LEARN-TEAMS", "OCT2022-AA-PROMO", "OCT2022-LEARN-TEAMS", "OCT2022-AA-PROMO", "OCT2022-LEARN-TEAMS", "OCT2022-SEUR", "OCT2022-LEARN-TEAMS", "OCT2022-TIER2", "OCT2022-LEARN-TEAMS", "OCT2022-N-EUR", "OCT2022-LEARN-TEAMS", "OCT2022-UK", "OCT2022-LEARN-TEAMS", "OCT2022-TIER-1", "OCT2022-LEARN-TEAMS"],
        "time_remaining_in_seconds": 979411,
        "location_dependent_data": {
            "coupon_code": "OCT2022-AA-PROMO",
            "discount_percentage": 67,
            "annual_dollars": 49,
            "annual_in_currency": 49,
            "annual_dollars_without_discount": 149,
            "annual_in_currency_without_discount": 149,
            "currency_icon": "$",
            "currency_code": "USD",
            "b2b": {
                "coupon_code": "OCT2022-LEARN-TEAMS",
                "discount_percentage": 50,
                "annual_dollars": 149,
                "annual_in_currency": 149,
                "annual_dollars_without_discount": 300,
                "annual_in_currency_without_discount": 300
            }
        },
        "presentation_data": {
            "background_color": "#06bdfc",
            "background_color_hex": "#06bdfc",
            "countdown_text": "Offer ends in ",
            "text_color": "#05192d",
            "banner_text": "Live events: How to become a Data Analyst & Why Get Certified",
            "upgrade_banner_text": "SQL, Power BI and Tableau courses and data analyst certifications on sale.",
            "banner_rect_colors": ["#7933FF", "#fcce0d", "#fcce0d", "#06BDFC"],
            "banner_rect_colors_emphasis": ["#7933FF", "#fcce0d", "#fcce0d", "#06BDFC"],
            "pricing_accent_color": "#60E7FF",
            "pricing_card_background_color": "linear-gradient(44.43deg, #60E7FF 24.91%, #06BDFC 71.14%)",
            "countdown_bar_background_color": "linear-gradient(83.1deg, #60E7FF 14.73%, #06BDFC 101.28%)",
            "time_background_color": "#05192d",
            "time_color": "#ffffff",
            "time_background_color_emphasis": "#05192d",
            "time_color_emphasis": "#ffffff"
        },
        "promo_key": "analyst_takeover_2022",
        "landing_page": "https://www.datacamp.com/analyst-takeover-2022",
        "title": "Live events: How to become a Data Analyst & Why Get Certified",
        "mobile_title": "GET 67% OFF!",
        "cta_text": "Take Me To The Offer",
        "cta_link": "https://www.datacamp.com/analyst-takeover-2022",
        "checkout_link": "https://www.datacamp.com/billing/subscribe?pay_period=yearly&product=premium",
        "touchpoints": ["dropdown_banner", "learn_paywall", "learn_dashboard_ad", "b2c2b_dashboard_ad"],
        "product_slugs": ["learn.premium", "learn.teams"],
        "type": "Sitewide"
    }
}, "b2cNonPaying");