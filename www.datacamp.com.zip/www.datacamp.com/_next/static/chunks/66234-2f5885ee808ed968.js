"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [66234], {
        37294: function(e, l, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            l.Z = function(e) {
                return r.createElement("svg", a({
                    viewBox: "0 0 11 16",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), t || (t = r.createElement("path", {
                    d: "M10.54 7.18c.46.41.47 1.14 0 1.55v.02l-8.16 7.14-1.37-1.57 7.26-6.36L1 1.56 2.39 0l8.15 7.18z",
                    fill: "currentColor"
                })))
            }
        },
        30750: function(e, l, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            l.Z = function(e) {
                return r.createElement("svg", a({
                    viewBox: "0 0 99 98",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), t || (t = r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, r.createElement("ellipse", {
                    cx: 49.4,
                    cy: 48.75,
                    fill: "#ff6ea9",
                    rx: 49.4,
                    ry: 48.75
                }), r.createElement("g", {
                    fill: "#05192d",
                    fillRule: "nonzero"
                }, r.createElement("path", {
                    d: "M20.65 51.33 49.1 71.2l.31.21 28.83-20.04 1.64 1.16a3.3 3.3 0 0 1 .16 5.24l-.16.13-28.6 20.15a3.25 3.25 0 0 1-3.74 0L18.93 57.9a3.3 3.3 0 0 1 0-5.37l1.72-1.21z"
                }), r.createElement("path", {
                    d: "M47.53 19.44 18.93 39.6a3.25 3.25 0 0 0 0 5.32l28.6 20.15c1.12.79 2.62.79 3.74 0l28.6-20.15a3.25 3.25 0 0 0 0-5.32l-28.6-20.15a3.25 3.25 0 0 0-3.74 0zm1.87 6.63 22.96 16.18L49.4 58.42 26.44 42.25z"
                }), r.createElement("path", {
                    d: "m60.06 38.29 5.46 3.84.1.15-14.3 10.4c-1.1.8-2.56.83-3.69.09l-.13-.1-14.15-10.29 5.61-3.95 10.45 7.6z"
                }), r.createElement("path", {
                    d: "M52.65 13v34.03h-6.5V13z"
                })))))
            }
        },
        38579: function(e, l, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            l.Z = function(e) {
                return r.createElement("svg", a({
                    viewBox: "0 0 39 38",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), t || (t = r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, r.createElement("ellipse", {
                    cx: 19.02,
                    cy: 18.75,
                    fill: "#06bdfc",
                    rx: 19.02,
                    ry: 18.75
                }), r.createElement("g", {
                    fill: "#05192d",
                    transform: "translate(5.25 5)"
                }, r.createElement("path", {
                    d: "M13.72 0h.25v2.5h-.25a11.22 11.22 0 1 0 9.44 5.15l2.07-1.4A13.72 13.72 0 1 1 13.73 0zm.04 5.5h.2V8h-.2a5.76 5.76 0 1 0 4.88 2.72l2.07-1.41a8.26 8.26 0 1 1-6.96-3.81z",
                    fillRule: "nonzero"
                }), r.createElement("circle", {
                    cx: 13.72,
                    cy: 13.72,
                    r: 2.97
                }), r.createElement("path", {
                    d: "M15.22.03V13.9h-2.5V.03z",
                    fillRule: "nonzero"
                })))))
            }
        },
        13855: function(e, l, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            l.Z = function(e) {
                return r.createElement("svg", a({
                    viewBox: "0 0 99 98",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), t || (t = r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, r.createElement("ellipse", {
                    cx: 49.45,
                    cy: 48.75,
                    fill: "#03ef62",
                    rx: 49.45,
                    ry: 48.75
                }), r.createElement("g", {
                    fill: "#05192d",
                    fillRule: "nonzero"
                }, r.createElement("path", {
                    d: "M49.4 15.6a24.66 24.66 0 0 0-24.7 24.62v.32a24.6 24.6 0 0 0 12 20.8l.05.04V71.5H62.1V61.34l.16-.1A24.59 24.59 0 0 0 74.1 40.23 24.66 24.66 0 0 0 49.4 15.6zm0 6.5c10.05 0 18.2 8.12 18.2 18.12A18.09 18.09 0 0 1 57.42 56.5l-1.82.89V65H43.25v-7.6l-1.83-.88A18.11 18.11 0 0 1 49.4 22.1zm10.66 53.63-3.75 6.5H42.49l-3.75-6.5h21.32z"
                }), r.createElement("path", {
                    d: "m50.2 30.35-1.82 7.03h9.06l-3.37 14.17H47.4l1.83-7.67h-9.24l3.5-13.53z"
                })))))
            }
        },
        29759: function(e, l, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            l.Z = function(e) {
                return r.createElement("svg", a({
                    viewBox: "0 0 99 98",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), t || (t = r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, r.createElement("ellipse", {
                    cx: 49.45,
                    cy: 48.75,
                    fill: "#ff931e",
                    rx: 49.45,
                    ry: 48.75
                }), r.createElement("g", {
                    fill: "#05192d",
                    fillRule: "nonzero"
                }, r.createElement("path", {
                    d: "m25.35 37.15.02 22.56-6.5-3.75-.02-15.06zm9.75-5.3.03 33.8h-6.5l-.03-33.8zM73.45 60.08l-.03-23.32 6.51 3.76.01 15.8zm-9.75 5.57-.03-33.8h6.5l.03 33.8z"
                }), r.createElement("path", {
                    d: "M66.95 45.5V52H31.2v-6.5z"
                })))))
            }
        },
        69335: function(e, l, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            l.Z = function(e) {
                return r.createElement("svg", a({
                    height: 65,
                    width: 1998,
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), t || (t = r.createElement("g", {
                    fill: "none"
                }, r.createElement("path", {
                    d: "M1998 65V31h-248v34z",
                    fill: "#05192d",
                    className: "lenox_svg__path-1"
                }), r.createElement("path", {
                    d: "M1998 31V0h-248v31z",
                    fill: "#7933ff",
                    className: "lenox_svg__path-2"
                }), r.createElement("path", {
                    d: "M1750 31V0H0v31z",
                    fill: "#06bdfc",
                    className: "lenox_svg__path-3"
                }))))
            }
        },
        87347: function(e, l, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            l.Z = function(e) {
                return r.createElement("svg", a({
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 2024 554"
                }, e), t || (t = r.createElement("g", {
                    fill: "none"
                }, r.createElement("path", {
                    className: "leonard_svg__p1",
                    fill: "#213147",
                    d: "M2024 35v519-65h-292.83v65H1500V35zM0 35h1500v519H0z"
                }), r.createElement("path", {
                    className: "leonard_svg__p2",
                    fill: "#06BDFC",
                    d: "M2024 35V0h-294v35z"
                }), r.createElement("path", {
                    className: "leonard_svg__p3",
                    fill: "#7933FF",
                    d: "M1730 35V0H0v35z"
                }), r.createElement("path", {
                    className: "leonard_svg__p4",
                    fill: "#FF6EA9",
                    d: "M1730 70V35H0v35z"
                }))))
            }
        },
        66234: function(e, l, n) {
            n.d(l, {
                Z: function() {
                    return b
                }
            });
            var t, r = n(44103),
                a = n(87591),
                i = n(21217),
                o = n(22429),
                s = n(11720),
                c = n(7388);

            function u() {
                return u = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, u.apply(this, arguments)
            }
            var h, f = function(e) {
                    return s.createElement("svg", u({
                        viewBox: "0 0 358 357",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, e), t || (t = s.createElement("g", {
                        fill: "none",
                        fillRule: "evenodd",
                        strokeWidth: 7.44,
                        transform: "translate(3 3)"
                    }, s.createElement("ellipse", {
                        cx: 175.73,
                        cy: 175.42,
                        rx: 162.13,
                        ry: 161.59,
                        stroke: "#fff"
                    }), s.createElement("path", {
                        d: "m164.57 0 13.82 13.82-13.82 13.82",
                        stroke: "#fff"
                    }), s.createElement("path", {
                        d: "m153.94 0 13.82 13.82-13.82 13.82",
                        stroke: "#05192d"
                    }), s.createElement("path", {
                        d: "m0 179.03 13.82-13.82 13.82 13.82",
                        stroke: "#fff"
                    }), s.createElement("path", {
                        d: "m0 189.66 13.82-13.82 13.82 13.82",
                        stroke: "#05192d"
                    }), s.createElement("path", {
                        d: "m352.1 167.12-13.81 13.82-13.82-13.82",
                        stroke: "#fff"
                    }), s.createElement("path", {
                        d: "M352.1 156.5 338.3 170.3l-13.82-13.82",
                        stroke: "#05192d"
                    }), s.createElement("path", {
                        d: "m178.4 350.83-13.83-13.82 13.82-13.82",
                        stroke: "#fff"
                    }), s.createElement("path", {
                        d: "m189.02 350.83-13.82-13.82 13.82-13.82",
                        stroke: "#05192d"
                    }))))
                },
                p = n(37294),
                d = n(30750),
                v = n(38579),
                m = n(13855),
                g = n(29759),
                x = n(69335),
                w = n(87347);

            function y() {
                return y = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var n = arguments[l];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                    }
                    return e
                }, y.apply(this, arguments)
            }
            var E = function(e) {
                    return s.createElement("svg", y({
                        height: 70,
                        width: 2e3,
                        xmlns: "http://www.w3.org/2000/svg"
                    }, e), h || (h = s.createElement("g", {
                        fill: "none",
                        fillRule: "evenodd"
                    }, s.createElement("path", {
                        d: "M2000 70V35H0v35z",
                        fill: "#06bdfc"
                    }), s.createElement("path", {
                        d: "M2000 35V0H0v35z",
                        fill: "#7933ff"
                    }))))
                },
                b = function() {
                    return (0, r.BX)(r.HY, {
                        children: [(0, r.BX)(c.xu, {
                            as: "section",
                            className: "invert",
                            sx: {
                                bg: "purple.200",
                                pb: [60, null, null, null, null, 102],
                                position: "relative",
                                pt: [84, null, null, null, null, 112],
                                px: 16,
                                textAlign: "center"
                            },
                            children: [(0, r.tZ)(c.xv, {
                                as: "h2",
                                variant: "h50",
                                children: "What is DataCamp?"
                            }), (0, r.tZ)(c.xv, {
                                as: "p",
                                sx: {
                                    maxWidth: 548,
                                    mx: "auto",
                                    pb: 24,
                                    pt: 16
                                },
                                variant: "t24",
                                children: "Learn the data skills you need online at your own pace\u2014from non-coding essentials to data science and machine learning."
                            }), (0, r.tZ)(o.default, {
                                appearance: "primary",
                                href: i.SIGN_UP_PATH,
                                intent: "success",
                                type: "link",
                                children: "Start Learning For Free"
                            }), (0, r.tZ)(a.default, {
                                sx: {
                                    justifyContent: "flex-end",
                                    pr: ["20%", "25%", "50%"],
                                    top: -31
                                },
                                children: (0, r.tZ)(x.Z, {
                                    sx: {
                                        mr: [null, null, null, 100, 150, 323]
                                    }
                                })
                            })]
                        }), (0, r.BX)(c.xu, {
                            as: "section",
                            sx: {
                                bg: "navy.200",
                                pb: 80,
                                position: "relative",
                                pt: [76, null, null, null, null, 116]
                            },
                            children: [(0, r.BX)(c.W2, {
                                sx: {
                                    alignItems: [null, null, null, null, null, "center"],
                                    display: [null, null, null, null, null, "flex"]
                                },
                                children: [(0, r.BX)(c.xu, {
                                    sx: {
                                        maxWidth: [null, null, null, null, null, 260],
                                        position: "relative",
                                        zIndex: 5
                                    },
                                    children: [(0, r.tZ)(c.xv, {
                                        as: "h2",
                                        sx: {
                                            color: "white",
                                            mt: [null, null, null, null, 32],
                                            textAlign: [null, null, "center", null, null, "left"]
                                        },
                                        variant: "h40",
                                        children: "We learn best by doing"
                                    }), (0, r.tZ)(c.xv, {
                                        as: "p",
                                        sx: {
                                            color: "white",
                                            mb: 32,
                                            mt: 12,
                                            textAlign: [null, null, "center", null, null, "left"]
                                        },
                                        variant: "t18",
                                        children: "DataCamp's proven learning methodology."
                                    })]
                                }), (0, r.BX)(c.xu, {
                                    as: "nav",
                                    sx: {
                                        "&:after": {
                                            bg: "white",
                                            content: '""',
                                            display: [null, null, null, "none"],
                                            height: 340,
                                            left: 36,
                                            position: "absolute",
                                            top: 24,
                                            width: 4
                                        },
                                        a: {
                                            zIndex: 10
                                        },
                                        display: [null, null, null, "flex"],
                                        flexWrap: [null, null, null, "wrap"],
                                        justifyContent: [null, null, null, "space-between"],
                                        maxWidth: 690,
                                        mx: "auto",
                                        position: "relative"
                                    },
                                    children: [(0, r.BX)(c.rU, {
                                        href: i.SIGNAL_PATH,
                                        sx: {
                                            "&:active, &:focus, &:hover": {
                                                color: "blue.200",
                                                svg: {
                                                    color: "blue.200",
                                                    transform: "scale(1.15)"
                                                },
                                                textDecoration: "none"
                                            },
                                            alignItems: "center",
                                            display: "flex",
                                            ml: [null, null, null, 16],
                                            mt: [24],
                                            position: ["relative"],
                                            svg: {
                                                transition: "0.15s linear"
                                            }
                                        },
                                        children: [(0, r.tZ)(v.Z, {
                                            sx: {
                                                ml: [null, null, null, 16],
                                                mr: [16, null, null, 0],
                                                order: [null, null, null, 1],
                                                width: 76
                                            }
                                        }), (0, r.BX)(c.xu, {
                                            children: [(0, r.BX)(c.xv, {
                                                as: "strong",
                                                sx: {
                                                    alignItems: "center",
                                                    color: "blue.200",
                                                    display: "flex"
                                                },
                                                variant: "h28",
                                                children: ["Assess", (0, r.tZ)(p.Z, {
                                                    sx: {
                                                        color: "white",
                                                        ml: 8,
                                                        width: 7
                                                    }
                                                })]
                                            }), (0, r.tZ)(c.xv, {
                                                as: "p",
                                                sx: {
                                                    color: "white",
                                                    fontSize: [300, null, null, 400],
                                                    fontWeight: "regular",
                                                    maxWidth: 158,
                                                    mt: 4
                                                },
                                                variant: "t16",
                                                children: "Test your skills and track progress"
                                            })]
                                        })]
                                    }), (0, r.BX)(c.rU, {
                                        href: i.COURSES_PATH,
                                        sx: {
                                            "&:active, &:focus, &:hover": {
                                                color: "green.200",
                                                svg: {
                                                    color: "green.200",
                                                    transform: "scale(1.15)"
                                                },
                                                textDecoration: "none"
                                            },
                                            alignItems: "center",
                                            display: "flex",
                                            mt: [24],
                                            position: ["relative"],
                                            svg: {
                                                transition: "0.15s linear"
                                            }
                                        },
                                        children: [(0, r.tZ)(m.Z, {
                                            sx: {
                                                mr: [16],
                                                width: 76
                                            }
                                        }), (0, r.BX)(c.xu, {
                                            children: [(0, r.BX)(c.xv, {
                                                as: "strong",
                                                sx: {
                                                    alignItems: "center",
                                                    color: "green.200",
                                                    display: "flex"
                                                },
                                                variant: "h28",
                                                children: ["Learn", (0, r.tZ)(p.Z, {
                                                    sx: {
                                                        color: "white",
                                                        ml: 8,
                                                        width: 7
                                                    }
                                                })]
                                            }), (0, r.tZ)(c.xv, {
                                                as: "p",
                                                sx: {
                                                    color: "white",
                                                    fontSize: [300, null, null, 400],
                                                    fontWeight: "regular",
                                                    maxWidth: 178,
                                                    mt: 4
                                                },
                                                variant: "t16",
                                                children: "Complete interactive courses"
                                            })]
                                        })]
                                    }), (0, r.BX)(c.rU, {
                                        href: i.PRACTICE_URL,
                                        sx: {
                                            "&:active, &:focus, &:hover": {
                                                color: "orange.200",
                                                svg: {
                                                    color: "orange.200",
                                                    transform: "scale(1.15)"
                                                },
                                                textDecoration: "none"
                                            },
                                            alignItems: "center",
                                            display: "flex",
                                            mt: [24, null, null, 116],
                                            order: [null, null, null, 1],
                                            position: ["relative"],
                                            svg: {
                                                transition: "0.15s linear"
                                            }
                                        },
                                        children: [(0, r.tZ)(g.Z, {
                                            sx: {
                                                mr: [16],
                                                width: 76
                                            }
                                        }), (0, r.BX)(c.xu, {
                                            children: [(0, r.BX)(c.xv, {
                                                as: "strong",
                                                sx: {
                                                    alignItems: "center",
                                                    color: "orange.200",
                                                    display: "flex"
                                                },
                                                variant: "h28",
                                                children: ["Practice", (0, r.tZ)(p.Z, {
                                                    sx: {
                                                        color: "white",
                                                        ml: 8,
                                                        width: 7
                                                    }
                                                })]
                                            }), (0, r.tZ)(c.xv, {
                                                as: "p",
                                                sx: {
                                                    color: "white",
                                                    fontSize: [300, null, null, 400],
                                                    fontWeight: "regular",
                                                    maxWidth: 176,
                                                    mt: 4
                                                },
                                                variant: "t16",
                                                children: "Practice with quick daily challenges"
                                            })]
                                        })]
                                    }), (0, r.BX)(c.rU, {
                                        href: i.PROJECTS_PATH,
                                        sx: {
                                            "&:active, &:focus, &:hover": {
                                                "> svg": {
                                                    color: "pink.200"
                                                },
                                                color: "pink.200",
                                                svg: {
                                                    color: "pink.200",
                                                    transform: "scale(1.15)"
                                                },
                                                textDecoration: "none"
                                            },
                                            alignItems: "center",
                                            display: "flex",
                                            mt: [24, null, null, 116],
                                            pl: [null, null, null, 16],
                                            position: "relative",
                                            svg: {
                                                transition: "0.15s linear"
                                            }
                                        },
                                        children: [(0, r.tZ)(d.Z, {
                                            sx: {
                                                ml: [null, null, null, 32],
                                                mr: [16, null, null, 0],
                                                order: [null, null, null, 1],
                                                width: 76
                                            }
                                        }), (0, r.BX)(c.xu, {
                                            children: [(0, r.BX)(c.xv, {
                                                as: "strong",
                                                sx: {
                                                    alignItems: "center",
                                                    color: "pink.200",
                                                    display: "flex"
                                                },
                                                variant: "h28",
                                                children: ["Apply", (0, r.tZ)(p.Z, {
                                                    sx: {
                                                        color: "white",
                                                        ml: 8,
                                                        width: 7
                                                    }
                                                })]
                                            }), (0, r.tZ)(c.xv, {
                                                as: "p",
                                                sx: {
                                                    color: "white",
                                                    fontSize: [300, null, null, 400],
                                                    fontWeight: "regular",
                                                    maxWidth: 137,
                                                    mt: 4
                                                },
                                                variant: "t16",
                                                children: "Solve real-world problems"
                                            })]
                                        })]
                                    }), (0, r.tZ)(f, {
                                        sx: {
                                            display: ["none", null, null, null, null, "block"],
                                            left: 166,
                                            position: "absolute",
                                            top: 0,
                                            width: 358
                                        }
                                    })]
                                })]
                            }), (0, r.tZ)(a.default, {
                                sx: {
                                    display: ["none", null, null, null, null, "flex"],
                                    justifyContent: [null, null, null, null, null, "flex-end"],
                                    pr: [null, null, null, null, null, "50%"],
                                    top: -35
                                },
                                children: (0, r.tZ)(w.Z, {
                                    "aria-hidden": "true",
                                    sx: {
                                        height: 554,
                                        mr: 272
                                    }
                                })
                            }), (0, r.tZ)(a.default, {
                                sx: {
                                    display: ["none", null, null, null, null, "flex"],
                                    pl: [null, null, null, null, null, "50%"],
                                    top: 0
                                },
                                children: (0, r.tZ)(E, {
                                    "aria-hidden": "true",
                                    sx: {
                                        ml: 570
                                    }
                                })
                            })]
                        })]
                    })
                }
        }
    }
]);
//# sourceMappingURL=66234-2f5885ee808ed968.js.map