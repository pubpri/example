(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [82437, 31015, 41393], {
        67381: function(n, t, e) {
            "use strict";

            function l(n) {
                return l = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(n) {
                    return typeof n
                } : function(n) {
                    return n && "function" === typeof Symbol && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n
                }, l(n)
            }
            e(19601), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = function(n) {
                if (n && n.__esModule) return n;
                if (null === n || "object" !== l(n) && "function" !== typeof n) return {
                    default: n
                };
                var t = u();
                if (t && t.has(n)) return t.get(n);
                var e = {},
                    r = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var o in n)
                    if (Object.prototype.hasOwnProperty.call(n, o)) {
                        var i = r ? Object.getOwnPropertyDescriptor(n, o) : null;
                        i && (i.get || i.set) ? Object.defineProperty(e, o, i) : e[o] = n[o]
                    }
                e.default = n, t && t.set(n, e);
                return e
            }(e(11720));

            function u() {
                if ("function" !== typeof WeakMap) return null;
                var n = new WeakMap;
                return u = function() {
                    return n
                }, n
            }

            function o() {
                return o = Object.assign || function(n) {
                    for (var t = 1; t < arguments.length; t++) {
                        var e = arguments[t];
                        for (var l in e) Object.prototype.hasOwnProperty.call(e, l) && (n[l] = e[l])
                    }
                    return n
                }, o.apply(this, arguments)
            }
            var i = function(n) {
                return r.createElement("svg", o({
                    height: 171,
                    width: 1270
                }, n), r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, r.createElement("path", {
                    d: "M0 0v135h1067V0z",
                    fill: "#06bdfc"
                }), r.createElement("path", {
                    d: "M1067 135.07v35h203v-35z",
                    fill: "#7933ff"
                })))
            };
            t.default = i
        },
        37322: function(n, t, e) {
            "use strict";
            t.Z = void 0;
            var l = e(21217),
                r = s(e(10491)),
                u = s(e(22429)),
                o = e(18733),
                i = s(e(67381)),
                a = e(34505);

            function s(n) {
                return n && n.__esModule ? n : {
                    default: n
                }
            }
            var f = function(n) {
                var t = n.className;
                return (0, o.jsx)(o.Box, {
                    as: "section",
                    className: t,
                    sx: {
                        pb: [190, null, null, null, null, 120],
                        position: "relative",
                        pt: [96, null, null, null, null, 128]
                    }
                }, (0, o.jsx)(o.Container, {
                    sx: {
                        alignItems: [null, null, null, null, null, "center"],
                        display: [null, null, null, null, null, "flex"],
                        justifyContent: [null, null, null, null, null, "space-between"],
                        px: [null, null, null, null, null, 56],
                        textAlign: "center"
                    }
                }, (0, o.jsx)(o.Box, {
                    sx: {
                        textAlign: [null, null, null, null, null, "left"]
                    }
                }, (0, o.jsx)(o.Text, {
                    variant: "h40"
                }, "Are you an educator?"), (0, o.jsx)(o.Text, {
                    as: "p",
                    sx: {
                        maxWidth: 440,
                        mb: 24,
                        mt: 16,
                        mx: ["auto", null, null, null, null, 0]
                    },
                    variant: "t24"
                }, "DataCamp for Classrooms is", " ", (0, o.jsx)(o.Text, {
                    as: "span",
                    sx: {
                        color: "purple.200",
                        fontWeight: "bold"
                    },
                    variant: "t24"
                }, "always free"), " ", "for you and your students."), (0, o.jsx)(u.default, {
                    href: l.EDUCATION_PATH,
                    type: "link"
                }, "Learn More")), (0, o.jsx)(o.Flex, {
                    as: "ul",
                    sx: {
                        "> *": {
                            mt: "32px !important",
                            width: [null, null, "50%"]
                        },
                        alignItems: ["center", null, null, "flex-start"],
                        flexDirection: ["column", null, null, "row"],
                        flexWrap: ["nowrap", null, null, "wrap"],
                        li: {
                            px: [0, null, null, 16]
                        },
                        maxWidth: 600,
                        mx: ["auto", null, null, null, null, 0],
                        span: {
                            display: "block",
                            maxWidth: 200,
                            mx: "auto"
                        },
                        strong: {
                            color: "purple.200",
                            display: "block",
                            fontSize: 1e3
                        }
                    }
                }, (0, o.jsx)(o.Text, {
                    as: "li",
                    variant: "t18"
                }, (0, o.jsx)(o.Text, {
                    as: "strong",
                    variant: "h50"
                }, (0, a.roundDown)(r.default.noOfStudentsServed, 1e4), "+"), " ", (0, o.jsx)("span", null, "students served")), (0, o.jsx)(o.Text, {
                    as: "li",
                    variant: "t18"
                }, (0, o.jsx)(o.Text, {
                    as: "strong",
                    variant: "h50"
                }, (0, a.roundDown)(r.default.noOfClassrooms, 100), "+"), " ", (0, o.jsx)("span", null, "classrooms using DataCamp in 2020")), (0, o.jsx)(o.Text, {
                    as: "li",
                    variant: "t18"
                }, (0, o.jsx)(o.Text, {
                    as: "strong",
                    variant: "h50"
                }, (0, a.roundDown)(r.default.noOfCountries, 5), "+"), " ", (0, o.jsx)("span", null, "countries represented")), (0, o.jsx)(o.Text, {
                    as: "li",
                    variant: "t18"
                }, (0, o.jsx)(o.Text, {
                    as: "strong",
                    variant: "h50"
                }, r.default.noOfFreeMonthsPerClassroom), " ", (0, o.jsx)("span", null, "months of free access for every classroom"))), (0, o.jsx)(o.Flex, {
                    "aria-hidden": "true",
                    sx: {
                        bottom: -36,
                        height: 171,
                        justifyContent: "flex-end",
                        left: 0,
                        overflow: "hidden",
                        position: "absolute",
                        pr: "50%",
                        right: 0
                    }
                }, (0, o.jsx)(i.default, {
                    "aria-hidden": "true",
                    sx: {
                        ".beekman-left_svg__p1": {
                            fill: "yellow.200"
                        },
                        ".beekman-left_svg__p2": {
                            fill: "purple.200"
                        },
                        flexShrink: 0,
                        mr: [32, null, null, null, 243, 367]
                    }
                }))))
            };
            t.Z = f
        },
        64396: function(n, t, e) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var l = e(18733),
                r = v(e(49748)),
                u = v(e(63427)),
                o = v(e(39556)),
                i = v(e(12453)),
                a = v(e(78982)),
                s = v(e(40207)),
                f = v(e(35307)),
                c = v(e(47852)),
                d = v(e(88410)),
                p = v(e(87875)),
                x = v(e(53463)),
                m = v(e(64930));

            function v(n) {
                return n && n.__esModule ? n : {
                    default: n
                }
            }
            var h = function(n) {
                var t = n.className,
                    e = n.primaryOnly,
                    v = void 0 !== e && e;
                return (0, l.jsx)("article", {
                    className: t,
                    sx: {
                        color: "rgba(255, 255, 255, 0.65)",
                        display: [null, null, null, null, "flex"],
                        justifyContent: [null, null, null, null, "center"]
                    }
                }, (0, l.jsx)(l.Flex, {
                    className: "primary",
                    sx: {
                        "> *": {
                            mt: [12, null, null, null, null, 21],
                            mx: 16
                        },
                        alignItems: "center",
                        flexWrap: "wrap",
                        justifyContent: "space-between",
                        maxWidth: [340, null, null, null, null, 430],
                        mx: ["auto", null, null, null, 0],
                        pt: [24, null, null, null, null, 8]
                    }
                }, (0, l.jsx)(s.default, {
                    "data-test-id": "google-logo",
                    sx: {
                        width: [74, null, null, null, null, 99]
                    }
                }), (0, l.jsx)(d.default, {
                    "data-test-id": "microsoft-logo",
                    sx: {
                        width: [100, null, null, null, null, 143]
                    }
                }), (0, l.jsx)(a.default, {
                    sx: {
                        width: [63, null, null, null, null, 84]
                    }
                }), (0, l.jsx)("hr", {
                    sx: {
                        borderColor: "transparent",
                        m: "0 !important",
                        width: "100%"
                    }
                }), (0, l.jsx)(p.default, {
                    "data-test-id": "paypal-logo",
                    sx: {
                        width: [69, null, null, null, null, 104]
                    }
                }), (0, l.jsx)(m.default, {
                    "data-test-id": "uber-logo",
                    sx: {
                        width: [62, null, null, null, null, 79]
                    }
                }), (0, l.jsx)(i.default, {
                    "data-test-id": "deloitte-logo",
                    sx: {
                        width: [91, null, null, null, null, 122]
                    }
                })), !v && (0, l.jsx)(l.Flex, {
                    className: "secondary",
                    sx: {
                        "> *": {
                            mt: [12, null, null, null, null, 20]
                        },
                        alignItems: "center",
                        display: ["none", null, null, null, "flex"],
                        flexWrap: "wrap",
                        justifyContent: "space-between",
                        maxWidth: [440, null, null, null, null, 580],
                        pl: [null, null, null, null, 24],
                        pt: [32, null, null, null, null, 16]
                    }
                }, (0, l.jsx)(f.default, {
                    "data-test-id": "hsbc-logo",
                    sx: {
                        width: [97, null, null, null, null, 131]
                    }
                }), (0, l.jsx)(u.default, {
                    sx: {
                        width: [144, null, null, null, null, 190]
                    }
                }), (0, l.jsx)(x.default, {
                    "data-test-id": "tmobile-logo",
                    sx: {
                        width: [118, null, null, null, null, 156]
                    }
                }), (0, l.jsx)("hr", {
                    sx: {
                        borderColor: "transparent",
                        m: "0 !important",
                        width: "100%"
                    }
                }), (0, l.jsx)(o.default, {
                    "data-test-id": "credit-suisse-logo",
                    sx: {
                        transform: "translateY(-4px)",
                        width: [116, null, null, null, null, 154]
                    }
                }), (0, l.jsx)(c.default, {
                    "data-test-id": "mercedes-logo",
                    sx: {
                        width: [140, null, null, null, null, 185]
                    }
                }), (0, l.jsx)(r.default, {
                    "data-test-id": "bnp-logo",
                    sx: {
                        width: [106, null, null, null, null, 138]
                    }
                })))
            };
            t.default = h
        },
        87591: function(n, t, e) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var l = e(18733),
                r = function(n) {
                    var t = n.children,
                        e = n.className;
                    return (0, l.jsx)(l.Flex, {
                        "aria-hidden": "true",
                        className: "ie-vsWrapper ".concat(e),
                        sx: {
                            "> svg": {
                                flexShrink: 0
                            },
                            left: 0,
                            overflow: "hidden",
                            pointerEvents: "none",
                            position: "absolute",
                            right: 0
                        }
                    }, t)
                };
            t.default = r
        },
        10491: function(n, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            t.default = {
                noOfAcademicOrgs: 3e3,
                noOfCareerTracks: 12,
                noOfClassrooms: 3700,
                noOfCompanies: 2500,
                noOfContentHours: 1500,
                noOfCountries: 180,
                noOfCourses: 354,
                noOfDonatedSubscriptions: 25e3,
                noOfExercises: 10400,
                noOfFreeMonthsPerClassroom: 6,
                noOfNonProfitOrgs: 120,
                noOfPracticeSessions: 50,
                noOfSkillTracks: 51,
                noOfStudentsServed: 35e4,
                noOfUsersForCSMEligibility: 20,
                percentOfFortune1000: 80
            }
        },
        34505: function(n, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.roundDown = t.roundNumber = void 0;
            t.roundNumber = function(n, t) {
                return t ? (Math.round(n / t) * t).toLocaleString() : n.toLocaleString()
            };
            t.roundDown = function(n, t) {
                return t ? (Math.floor(n / t) * t).toLocaleString() : n.toLocaleString()
            }
        },
        59110: function(n, t, e) {
            "use strict";
            var l = e(11720),
                r = e(70917),
                u = l.forwardRef((function(n, t) {
                    var e = n["aria-hidden"],
                        l = void 0 !== e && e,
                        u = n.className,
                        o = n.color,
                        i = void 0 === o ? "currentColor" : o,
                        a = n.size,
                        s = void 0 === a ? "medium" : a,
                        f = n.title,
                        c = n.titleId,
                        d = "medium" === s ? 16 : "small" === s ? 14 : 12;
                    return (0, r.jsx)("svg", {
                        viewBox: "0 0 18 18",
                        "aria-hidden": l,
                        className: u,
                        height: d,
                        ref: t,
                        role: "img",
                        width: d,
                        "aria-labelledby": c
                    }, void 0 === f ? (0, r.jsx)("title", {
                        id: c
                    }, "Cross") : f ? (0, r.jsx)("title", {
                        id: c
                    }, f) : null, (0, r.jsx)("path", {
                        fill: i,
                        d: "M9.005 7.625l4.83-4.83a.976.976 0 011.38 1.38l-4.83 4.83 4.82 4.82a.976.976 0 11-1.38 1.38l-4.82-4.82-4.83 4.83a.976.976 0 01-1.38-1.38l4.83-4.83-4.84-4.84a.976.976 0 111.38-1.38l4.84 4.84z",
                        fillRule: "evenodd"
                    }))
                }));
            u.propTypes = {}, t.Z = u
        },
        82772: function(n, t, e) {
            "use strict";
            var l = e(82109),
                r = e(1702),
                u = e(41318).indexOf,
                o = e(9341),
                i = r([].indexOf),
                a = !!i && 1 / i([1], 1, -0) < 0,
                s = o("indexOf");
            l({
                target: "Array",
                proto: !0,
                forced: a || !s
            }, {
                indexOf: function(n) {
                    var t = arguments.length > 1 ? arguments[1] : void 0;
                    return a ? i(this, n, t) || 0 : u(this, n, t)
                }
            })
        },
        69246: function(n, t, e) {
            "use strict";

            function l(n, t) {
                (null == t || t > n.length) && (t = n.length);
                for (var e = 0, l = new Array(t); e < t; e++) l[e] = n[e];
                return l
            }

            function r(n, t) {
                return function(n) {
                    if (Array.isArray(n)) return n
                }(n) || function(n, t) {
                    var e = null == n ? null : "undefined" !== typeof Symbol && n[Symbol.iterator] || n["@@iterator"];
                    if (null != e) {
                        var l, r, u = [],
                            o = !0,
                            i = !1;
                        try {
                            for (e = e.call(n); !(o = (l = e.next()).done) && (u.push(l.value), !t || u.length !== t); o = !0);
                        } catch (a) {
                            i = !0, r = a
                        } finally {
                            try {
                                o || null == e.return || e.return()
                            } finally {
                                if (i) throw r
                            }
                        }
                        return u
                    }
                }(n, t) || function(n, t) {
                    if (!n) return;
                    if ("string" === typeof n) return l(n, t);
                    var e = Object.prototype.toString.call(n).slice(8, -1);
                    "Object" === e && n.constructor && (e = n.constructor.name);
                    if ("Map" === e || "Set" === e) return Array.from(e);
                    if ("Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e)) return l(n, t)
                }(n, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useIntersection = function(n) {
                var t = n.rootRef,
                    e = n.rootMargin,
                    l = n.disabled || !i,
                    f = u.useRef(),
                    c = r(u.useState(!1), 2),
                    d = c[0],
                    p = c[1],
                    x = r(u.useState(t ? t.current : null), 2),
                    m = x[0],
                    v = x[1],
                    h = u.useCallback((function(n) {
                        f.current && (f.current(), f.current = void 0), l || d || n && n.tagName && (f.current = function(n, t, e) {
                            var l = function(n) {
                                    var t, e = {
                                            root: n.root || null,
                                            margin: n.rootMargin || ""
                                        },
                                        l = s.find((function(n) {
                                            return n.root === e.root && n.margin === e.margin
                                        }));
                                    l ? t = a.get(l) : (t = a.get(e), s.push(e));
                                    if (t) return t;
                                    var r = new Map,
                                        u = new IntersectionObserver((function(n) {
                                            n.forEach((function(n) {
                                                var t = r.get(n.target),
                                                    e = n.isIntersecting || n.intersectionRatio > 0;
                                                t && e && t(e)
                                            }))
                                        }), n);
                                    return a.set(e, t = {
                                        id: e,
                                        observer: u,
                                        elements: r
                                    }), t
                                }(e),
                                r = l.id,
                                u = l.observer,
                                o = l.elements;
                            return o.set(n, t), u.observe(n),
                                function() {
                                    if (o.delete(n), u.unobserve(n), 0 === o.size) {
                                        u.disconnect(), a.delete(r);
                                        var t = s.findIndex((function(n) {
                                            return n.root === r.root && n.margin === r.margin
                                        }));
                                        t > -1 && s.splice(t, 1)
                                    }
                                }
                        }(n, (function(n) {
                            return n && p(n)
                        }), {
                            root: m,
                            rootMargin: e
                        }))
                    }), [l, m, e, d]),
                    y = u.useCallback((function() {
                        p(!1)
                    }), []);
                return u.useEffect((function() {
                    if (!i && !d) {
                        var n = o.requestIdleCallback((function() {
                            return p(!0)
                        }));
                        return function() {
                            return o.cancelIdleCallback(n)
                        }
                    }
                }), [d]), u.useEffect((function() {
                    t && v(t.current)
                }), [t]), [h, d, y]
            };
            var u = e(11720),
                o = e(44686),
                i = "undefined" !== typeof IntersectionObserver;
            var a = new Map,
                s = [];
            ("function" === typeof t.default || "object" === typeof t.default && null !== t.default) && (Object.assign(t.default, t), n.exports = t.default)
        },
        48318: function() {},
        92703: function(n, t, e) {
            "use strict";
            var l = e(50414);

            function r() {}

            function u() {}
            u.resetWarningCache = r, n.exports = function() {
                function n(n, t, e, r, u, o) {
                    if (o !== l) {
                        var i = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                        throw i.name = "Invariant Violation", i
                    }
                }

                function t() {
                    return n
                }
                n.isRequired = n;
                var e = {
                    array: n,
                    bigint: n,
                    bool: n,
                    func: n,
                    number: n,
                    object: n,
                    string: n,
                    symbol: n,
                    any: n,
                    arrayOf: t,
                    element: n,
                    elementType: n,
                    instanceOf: t,
                    node: n,
                    objectOf: t,
                    oneOf: t,
                    oneOfType: t,
                    shape: t,
                    exact: t,
                    checkPropTypes: u,
                    resetWarningCache: r
                };
                return e.PropTypes = e, e
            }
        },
        45697: function(n, t, e) {
            n.exports = e(92703)()
        },
        50414: function(n) {
            "use strict";
            n.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
        },
        18733: function(n, t, e) {
            "use strict";
            e.r(t), e.d(t, {
                Alert: function() {
                    return i.bZ
                },
                AspectImage: function() {
                    return i.bp
                },
                AspectRatio: function() {
                    return i.oM
                },
                Avatar: function() {
                    return i.qE
                },
                Badge: function() {
                    return i.Ct
                },
                BaseStyles: function() {
                    return s
                },
                Box: function() {
                    return i.xu
                },
                Button: function() {
                    return i.zx
                },
                Card: function() {
                    return i.Zb
                },
                Checkbox: function() {
                    return i.XZ
                },
                Close: function() {
                    return i.x8
                },
                Container: function() {
                    return i.W2
                },
                Divider: function() {
                    return i.iz
                },
                Donut: function() {
                    return i.yi
                },
                Embed: function() {
                    return i.cx
                },
                Field: function() {
                    return i.gN
                },
                Flex: function() {
                    return i.kC
                },
                Grid: function() {
                    return i.rj
                },
                Heading: function() {
                    return i.X6
                },
                IconButton: function() {
                    return i.hU
                },
                Image: function() {
                    return i.Ee
                },
                InitializeColorMode: function() {
                    return r.sv
                },
                Input: function() {
                    return i.II
                },
                Label: function() {
                    return i.__
                },
                Link: function() {
                    return i.rU
                },
                MenuButton: function() {
                    return i.j2
                },
                Message: function() {
                    return i.v0
                },
                NavLink: function() {
                    return i.OL
                },
                Paragraph: function() {
                    return i.nv
                },
                Progress: function() {
                    return i.Ex
                },
                Radio: function() {
                    return i.Y8
                },
                Select: function() {
                    return i.Ph
                },
                Slider: function() {
                    return i.iR
                },
                Spinner: function() {
                    return i.$j
                },
                Styled: function() {
                    return u.RQ
                },
                Switch: function() {
                    return i.rs
                },
                Text: function() {
                    return i.xv
                },
                Textarea: function() {
                    return i.gx
                },
                ThemeProvider: function() {
                    return o.f
                },
                Themed: function() {
                    return u.Ge
                },
                __ThemeUIContext: function() {
                    return l.nr
                },
                components: function() {
                    return u.wx
                },
                createElement: function() {
                    return l.az
                },
                css: function() {
                    return a.iv
                },
                get: function() {
                    return a.U2
                },
                jsx: function() {
                    return f
                },
                merge: function() {
                    return l.TS
                },
                useColorMode: function() {
                    return r.If
                },
                useThemeUI: function() {
                    return l.B7
                }
            });
            var l = e(50743),
                r = e(86197),
                u = e(77058),
                o = e(32139),
                i = e(7388),
                a = e(33431);
            const s = n => f("div", { ...n,
                    sx: {
                        fontFamily: "body",
                        lineHeight: "body",
                        fontWeight: "body",
                        variant: "styles"
                    }
                }),
                f = l.tZ
        }
    }
]);
//# sourceMappingURL=82437-b8e08385feac918b.js.map