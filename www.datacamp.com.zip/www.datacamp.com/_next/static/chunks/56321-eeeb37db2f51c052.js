"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [56321], {
        29519: function(e, t, n) {
            function r(e) {
                return r = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, r(e)
            }
            n(19601), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== r(e) && "function" !== typeof e) return {
                    default: e
                };
                var t = i();
                if (t && t.has(e)) return t.get(e);
                var n = {},
                    o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in e)
                    if (Object.prototype.hasOwnProperty.call(e, a)) {
                        var l = o ? Object.getOwnPropertyDescriptor(e, a) : null;
                        l && (l.get || l.set) ? Object.defineProperty(n, a, l) : n[a] = e[a]
                    }
                n.default = e, t && t.set(e, n);
                return n
            }(n(11720));

            function i() {
                if ("function" !== typeof WeakMap) return null;
                var e = new WeakMap;
                return i = function() {
                    return e
                }, e
            }

            function a() {
                return a = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            var l = function(e) {
                return o.createElement("svg", a({
                    viewBox: "0 0 26 34"
                }, e), o.createElement("path", {
                    d: "M14.001 25.028v-7.224l11.393-6.498-2.77-1.588-8.623 4.918V7.391c0-.491-.265-.95-.69-1.194L2.938.245a1.974 1.974 0 00-2.006.06A1.98 1.98 0 000 1.992v20.375c0 .69.35 1.321.934 1.687a1.973 1.973 0 002.002.061l8.317-4.743v6.457c0 .494.266.952.695 1.196l10.658 6.067 2.771-1.589-11.376-6.475zm-2.748-16.84v8.016l-8.504 4.85V3.31l8.504 4.88z",
                    fill: "#03EF62",
                    fillRule: "evenodd"
                }))
            };
            t.default = l
        },
        46141: function(e, t, n) {
            function r(e) {
                return r = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, r(e)
            }
            n(19601), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== r(e) && "function" !== typeof e) return {
                    default: e
                };
                var t = i();
                if (t && t.has(e)) return t.get(e);
                var n = {},
                    o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in e)
                    if (Object.prototype.hasOwnProperty.call(e, a)) {
                        var l = o ? Object.getOwnPropertyDescriptor(e, a) : null;
                        l && (l.get || l.set) ? Object.defineProperty(n, a, l) : n[a] = e[a]
                    }
                n.default = e, t && t.set(e, n);
                return n
            }(n(11720));

            function i() {
                if ("function" !== typeof WeakMap) return null;
                var e = new WeakMap;
                return i = function() {
                    return e
                }, e
            }

            function a() {
                return a = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            var l = function(e) {
                return o.createElement("svg", a({
                    width: 135,
                    height: 29
                }, e), o.createElement("path", {
                    d: "M31.47 6.657v2.088a8.016 8.016 0 100 11.686v1.765h2.532V6.657h-2.531zm-5.483 13.41a5.478 5.478 0 110-10.956 5.478 5.478 0 010 10.955zm32.175-13.41v2.088a8.016 8.016 0 100 11.686v1.765h2.531V6.657h-2.53zm-5.485 13.41a5.478 5.478 0 11.001-10.956 5.478 5.478 0 010 10.955zM40.407 9.083l.001 9.559c0 .566.46 1.026 1.027 1.026h2.947v2.529h-2.947a3.56 3.56 0 01-3.555-3.555l-.007-9.559H35.14V6.63h2.732V2.37h2.534v4.26H44.9v2.454h-4.494zm85.812-2.499c-2.114 0-4.035.82-5.467 2.156V6.657h-2.532v21.885h2.532v-8.081a8.016 8.016 0 105.467-13.876zm0 13.494a5.477 5.477 0 01-5.467-5.15v-.656a5.477 5.477 0 115.467 5.806zm-49.578-.77a8.016 8.016 0 11.202-9.14l-2.428 1.262a5.322 5.322 0 10-.364 6.617l2.59 1.262zm36.472-12.063c.226-.372.63-.598 1.066-.598h.487c1.034 0 1.873.838 1.873 1.872v13.676h-2.582V10.61a4386.84 4386.84 0 00-6.737 10.989c-.227.371-.63.597-1.065.597h-.529c-.69 0-1.248-.559-1.248-1.248V10.58a1904.214 1904.214 0 00-7.031 11.499l-.07.116h-2.478V6.648h2.584v.031l-.06 10.722 6.192-10.155a1.25 1.25 0 011.067-.598h.49c1.033 0 1.871.835 1.873 1.868.005 2.857.015 8.063.015 8.82l6.153-10.09zm-20.186 7.342v-7.93h-2.531v2.087a8.016 8.016 0 100 11.686v1.765h2.531V14.59zm-8.016 5.478a5.478 5.478 0 110-10.955 5.478 5.478 0 010 10.955zM14.424.23v8.515a8.016 8.016 0 100 11.686v1.765h2.531V.23h-2.531zM8.94 20.066a5.477 5.477 0 110-10.955 5.477 5.477 0 010 10.955z",
                    fill: "#FFF",
                    fillRule: "evenodd"
                }))
            };
            t.default = l
        },
        48655: function(e, t, n) {
            function r(e) {
                return r = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, r(e)
            }
            n(19601), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== r(e) && "function" !== typeof e) return {
                    default: e
                };
                var t = i();
                if (t && t.has(e)) return t.get(e);
                var n = {},
                    o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in e)
                    if (Object.prototype.hasOwnProperty.call(e, a)) {
                        var l = o ? Object.getOwnPropertyDescriptor(e, a) : null;
                        l && (l.get || l.set) ? Object.defineProperty(n, a, l) : n[a] = e[a]
                    }
                n.default = e, t && t.set(e, n);
                return n
            }(n(11720));

            function i() {
                if ("function" !== typeof WeakMap) return null;
                var e = new WeakMap;
                return i = function() {
                    return e
                }, e
            }

            function a() {
                return a = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            var l = function(e) {
                return o.createElement("svg", a({
                    width: 22,
                    height: 22
                }, e), o.createElement("path", {
                    d: "M8.777.138C3.884.652.322 5.054.836 9.948c.514 4.893 4.915 8.455 9.809 7.941a8.874 8.874 0 004.119-1.52l.278-.2 4.6 4.948 1.68-1.22-4.783-5.142a8.9 8.9 0 002.05-6.673C18.073 3.188 13.67-.376 8.776.138zm.215 2.049h.002a6.872 6.872 0 017.546 6.111 6.872 6.872 0 01-6.11 7.544 6.871 6.871 0 01-7.545-6.109 6.872 6.872 0 016.107-7.546z",
                    fill: "currentColor",
                    fillRule: "evenodd"
                }))
            };
            t.default = l
        },
        36643: function(e, t, n) {
            function r(e) {
                return r = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, r(e)
            }
            n(19601), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== r(e) && "function" !== typeof e) return {
                    default: e
                };
                var t = i();
                if (t && t.has(e)) return t.get(e);
                var n = {},
                    o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in e)
                    if (Object.prototype.hasOwnProperty.call(e, a)) {
                        var l = o ? Object.getOwnPropertyDescriptor(e, a) : null;
                        l && (l.get || l.set) ? Object.defineProperty(n, a, l) : n[a] = e[a]
                    }
                n.default = e, t && t.set(e, n);
                return n
            }(n(11720));

            function i() {
                if ("function" !== typeof WeakMap) return null;
                var e = new WeakMap;
                return i = function() {
                    return e
                }, e
            }

            function a() {
                return a = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            var l = function(e) {
                return o.createElement("svg", a({
                    width: 10,
                    height: 12,
                    fill: "none"
                }, e), o.createElement("path", {
                    d: "M9.252 3.971a.363.363 0 00-.323-.182h-3.35L7.46.457a.284.284 0 00-.015-.306A.37.37 0 007.143 0H4.286a.363.363 0 00-.323.18l-3.214 6a.284.284 0 00.02.304.37.37 0 00.303.147h2.932l-2.546 4.932c-.068.144-.007.31.145.392a.39.39 0 00.46-.07l7.14-7.578a.287.287 0 00.05-.336z",
                    fill: "#65707C"
                }))
            };
            t.default = l
        },
        53153: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, o = n(21217),
                i = (r = n(42186)) && r.__esModule ? r : {
                    default: r
                },
                a = n(18733);
            var l = function(e) {
                var t = e.className,
                    n = e.excited ? "We're Hiring!" : "We're Hiring";
                return (0, a.jsx)(a.Link, {
                    className: t,
                    href: o.CAREERS_PATH
                }, (0, a.jsx)("strong", {
                    sx: {
                        "&:hover": {
                            color: "green.100"
                        },
                        backgroundColor: "".concat(i.default.colors.navy[100]),
                        borderRadius: 4,
                        color: "green.200",
                        display: "inline-block",
                        fontSize: 14,
                        px: 4,
                        textTransform: "uppercase",
                        transition: "color 0.3s cubic-bezier(0.85, 0, 0.15, 1)"
                    }
                }, n))
            };
            t.default = l
        },
        38068: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = u(n(62677)),
                o = n(11720),
                i = n(18733),
                a = n(53726),
                l = u(n(30242));

            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var s = function(e) {
                var t = e.authenticated,
                    n = e.device,
                    u = (0, o.useRef)(null),
                    s = (0, o.useRef)(null),
                    c = (0, o.useRef)(null),
                    f = (0, a.useNavState)((function(e) {
                        return e.isOpen
                    })),
                    d = (0, a.useNavDispatcher)(),
                    p = function(e) {
                        d((function() {
                            return {
                                isOpen: e
                            }
                        }))
                    },
                    v = function(e) {
                        var t, n;
                        (null === e || void 0 === e ? void 0 : e.target) instanceof Node && (null === (t = u.current) || void 0 === t ? void 0 : t.contains(e.target)) && (p(!f), e.stopPropagation()), f && (null === e || void 0 === e ? void 0 : e.target) instanceof Node && !(null === (n = s.current) || void 0 === n ? void 0 : n.contains(e.target)) && p(!1)
                    };
                return (0, o.useEffect)((function() {
                    return document.addEventListener("mousedown", v),
                        function() {
                            document.removeEventListener("mousedown", v)
                        }
                }), [f]), (0, o.useEffect)((function() {
                    f || d((function() {
                        return {
                            activePanel: -1,
                            activeTab: "mobile" === n ? -1 : 0,
                            lastHoverX: 1 / 0
                        }
                    }))
                }), [f, n]), (0, i.jsx)(i.Box, {
                    "aria-label": "Learn Menu",
                    onMouseEnter: function() {
                        "desktop" === n && p(!0)
                    },
                    onMouseLeave: function() {
                        p(!1)
                    }
                }, (0, i.jsx)(i.Button, {
                    className: "ds-snowplow-navbar-explore",
                    ref: u,
                    sx: {
                        "> span": {
                            pointerEvents: "none"
                        },
                        alignItems: "center",
                        display: "flex",
                        ml: [8, null, null, 18, null, 0],
                        mr: 8,
                        px: 16,
                        py: 12
                    },
                    variant: "navbarIcon"
                }, (0, i.jsx)(i.Text, {
                    as: "span",
                    sx: {
                        color: "white"
                    },
                    variant: "t16"
                }, "Explore"), (0, i.jsx)(r.default, {
                    "aria-hidden": !0,
                    sx: {
                        ml: "4px",
                        mt: 1
                    },
                    title: ""
                })), (0, i.jsx)(l.default, {
                    authenticated: t,
                    device: n,
                    isOpen: f,
                    listRef: c,
                    menuRef: s
                }))
            };
            t.default = s
        },
        88570: function(e, t, n) {
            n(82526), n(57327), n(89554), n(82772), n(21249), n(47042), n(19601), n(38880), n(49337), n(47941), n(54747), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n(21217),
                o = d(n(65949)),
                i = d(n(82848)),
                a = n(52987),
                l = d(n(23279)),
                u = n(11720),
                s = n(18733),
                c = d(n(36643)),
                f = n(53726);

            function d(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function p() {
                return p = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, p.apply(this, arguments)
            }

            function v(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function b(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? v(Object(n), !0).forEach((function(t) {
                        y(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : v(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function y(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var h = function(e) {
                    return e ? {
                        borderBottom: "1px solid #CCCFD2",
                        display: "flex",
                        flexDirection: "column",
                        flexShrink: 0,
                        pb: 8,
                        pt: 8
                    } : {
                        borderBottom: "1px solid #CCCFD2",
                        display: "flex",
                        flexDirection: "column",
                        flexShrink: 0
                    }
                },
                x = function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "#03EF62";
                    return e ? {
                        "&:active, &:focus, &:hover": {
                            background: "grey.200"
                        },
                        alignItems: "center",
                        background: "transparent",
                        border: "none",
                        boxShadow: "none",
                        cursor: "pointer",
                        display: "flex",
                        justifyContent: "space-between",
                        outline: "none",
                        p: 0,
                        svg: {
                            mr: 8
                        },
                        textAlign: "left",
                        textDecoration: "none",
                        transition: "background 0.3s ease-in-out"
                    } : b({
                        "&:active, &:focus, &:hover": {
                            outline: "none",
                            textDecoration: "none"
                        },
                        ":last-child": {
                            mb: 12
                        },
                        alignItems: "center",
                        background: "transparent",
                        borderColor: "transparent",
                        borderLeft: "4px solid",
                        borderLeftColor: "transparent",
                        display: "flex",
                        p: 0,
                        textAlign: "left"
                    }, t ? {
                        background: "white",
                        borderBottomLeftRadius: "4px",
                        borderLeftColor: n,
                        borderTopLeftRadius: "4px",
                        cursor: "pointer",
                        display: "flex",
                        justifyContent: "space-between",
                        svg: {
                            mr: 16,
                            opacity: 1
                        },
                        textDecoration: "none"
                    } : {})
                },
                m = function(e) {
                    return e ? {
                        color: "text",
                        fontSize: 200,
                        py: 14
                    } : {
                        color: "text",
                        fontSize: 200,
                        fontWeight: "regular",
                        lineHeight: "22px",
                        pl: 12,
                        py: [12, null, null, 11, null, 8]
                    }
                },
                g = function(e) {
                    return e ? {
                        color: "text",
                        fontSize: 400,
                        fontWeight: 600
                    } : {
                        color: "text",
                        fontSize: 200,
                        fontWeight: 600,
                        lineHeight: "20px",
                        pl: 12,
                        py: 8
                    }
                },
                j = function(e) {
                    return e ? {
                        color: "navy.200",
                        opacity: 1,
                        verticalAlign: "middle"
                    } : {
                        color: "blue.400",
                        opacity: 0,
                        transition: "visibility .3s ease",
                        verticalAlign: "middle"
                    }
                },
                w = function(e) {
                    var t = e.isMobile;
                    return (0, s.jsx)(u.Fragment, null, t ? (0, s.jsx)(i.default, {
                        "aria-hidden": !0,
                        size: 12,
                        sx: {
                            width: 12
                        },
                        title: ""
                    }) : (0, s.jsx)(o.default, {
                        "aria-hidden": !0,
                        size: 12,
                        sx: b(b({}, j(t)), {}, {
                            width: 11
                        }),
                        title: ""
                    }))
                },
                S = function(e) {
                    var t = e.children,
                        n = e.device,
                        r = e.indexTab,
                        o = e.slug,
                        i = e.styles,
                        a = (0, f.useNavDispatcher)(),
                        u = (0, f.useNavState)((function(e) {
                            return e.lastHoverX
                        })),
                        c = b({
                            href: o,
                            onClick: function() {
                                a((function() {
                                    return {
                                        activePanel: -1,
                                        activeTab: r
                                    }
                                }))
                            }
                        }, "desktop" === n ? {
                            onMouseMove: (0, l.default)((function(e) {
                                e.pageX - u > 3 ? a((function() {
                                    return {
                                        lastHoverX: e.pageX
                                    }
                                })) : a((function() {
                                    return {
                                        activePanel: -1,
                                        activeTab: r,
                                        lastHoverX: e.pageX
                                    }
                                }))
                            }), 100, {
                                leading: !0,
                                trailing: !1
                            })
                        } : {});
                    return "desktop" === n && o ? (0, s.jsx)(s.Link, p({
                        sx: i
                    }, c), t) : (0, s.jsx)(s.Button, p({
                        sx: i
                    }, c), t)
                },
                O = function(e) {
                    var t = e.authenticated,
                        n = e.device,
                        o = a.menuTabsComponentMapper[a.menuTabsComponentMapper.length - 1],
                        i = a.menuTabsComponentMapper.indexOf(o),
                        l = "mobile" === n,
                        u = (0, f.useNavState)((function(e) {
                            return e.activeTab
                        }));
                    return l && u > -1 ? null : (0, s.jsx)(s.Flex, {
                        sx: {
                            b: {
                                pt: 8
                            },
                            bg: ["white", null, null, "grey.200"],
                            display: "flex",
                            flexDirection: "column",
                            flexShrink: 0,
                            pb: 10,
                            pl: [16, null, null, 8],
                            pr: [16, null, null, 0],
                            pt: [0, null, null, 10],
                            width: [327, 432, null, "26%", null, "21%"]
                        }
                    }, (0, s.jsx)(s.Flex, {
                        sx: {
                            alignItems: "center",
                            height: "auto",
                            justifyContent: "space-between"
                        }
                    }, (0, s.jsx)(s.Text, {
                        as: "b",
                        sx: b(b({}, g(l)), {}, {
                            mb: 0,
                            mt: [8, null, null, 0],
                            pl: [0, null, null, 16]
                        })
                    }, "Learn"), !t && l && (0, s.jsx)(s.Link, {
                        href: r.SIGN_IN_PATH,
                        sx: {
                            color: "#0075AD",
                            float: "right",
                            fontSize: 16,
                            fontWeight: "bold",
                            mr: 14,
                            mt: 16,
                            textDecoration: "none"
                        }
                    }, "Log in")), (0, s.jsx)("div", {
                        sx: h(l)
                    }, a.menuTabsComponentMapper.slice(0, 3).map((function(e, t) {
                        var r = t;
                        return (0, s.jsx)(S, {
                            device: n,
                            indexTab: r,
                            key: "tab-".concat(r),
                            slug: e.slug,
                            styles: b(b({}, x(l, r === u)), m(l))
                        }, e.title, (0, s.jsx)(w, {
                            isMobile: l
                        }))
                    }))), (0, s.jsx)(s.Text, {
                        as: "b",
                        sx: b(b({}, g(l)), {}, {
                            mt: [12, null, null, 4],
                            pl: [0, null, null, 16]
                        })
                    }, "I want to"), (0, s.jsx)("div", {
                        sx: h(l)
                    }, a.menuTabsComponentMapper.slice(3, 6).map((function(e, t) {
                        var r = 3 + t;
                        return (0, s.jsx)(S, {
                            device: n,
                            indexTab: r,
                            key: "tab-".concat(r),
                            slug: e.slug,
                            styles: b(b({}, x(l, r === u)), m(l))
                        }, (0, s.jsx)(s.Flex, {
                            sx: {
                                alignItems: "center",
                                display: "inline-flex"
                            }
                        }, (0, s.jsx)(c.default, {
                            sx: {
                                mr: "10px !important"
                            }
                        }), e.title), (0, s.jsx)(w, {
                            isMobile: l
                        }))
                    }))), (0, s.jsx)("div", {
                        sx: b(b({}, h(l)), {}, {
                            mt: [0, null, null, 8]
                        })
                    }, a.menuTabsComponentMapper.slice(6, 9).map((function(e, t) {
                        var r = 6 + t;
                        return (0, s.jsx)(S, {
                            device: n,
                            indexTab: r,
                            key: "tab-".concat(r),
                            slug: e.slug,
                            styles: b(b(b({}, x(l, r === u, e.color)), g(l)), {}, {
                                py: 8
                            })
                        }, e.title, (0, s.jsx)(w, {
                            isMobile: l
                        }))
                    }))), "desktop" !== n && (0, s.jsx)(s.Box, {
                        sx: {
                            pt: 10
                        }
                    }, (0, s.jsx)(s.Link, {
                        href: r.PRICING_PATH,
                        sx: b(b({}, g(l)), {}, {
                            display: "block",
                            pl: [0, null, null, 16],
                            py: 8,
                            width: "100%"
                        })
                    }, "Pricing"), (0, s.jsx)(s.Link, {
                        href: r.BUSINESS_PATH,
                        sx: b(b({}, g(l)), {}, {
                            display: "block",
                            pl: [0, null, null, 16],
                            py: 8,
                            width: "100%"
                        })
                    }, "For Business")), (0, s.jsx)(S, {
                        device: n,
                        indexTab: i,
                        key: "tab-".concat(i),
                        slug: o.slug,
                        styles: b(b(b({}, x(l, i === u)), g(l)), {}, {
                            mt: [null, null, null, null, null, 8],
                            py: 8
                        })
                    }, o.title, (0, s.jsx)(w, {
                        isMobile: l
                    })))
                };
            t.default = O
        },
        30242: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n(18733),
                o = u(n(88570)),
                i = u(n(35766)),
                a = u(n(63586)),
                l = u(n(61369));

            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var s = function(e) {
                var t = e.authenticated,
                    n = e.device,
                    u = e.isOpen,
                    s = e.listRef,
                    c = e.menuRef;
                return (0, r.jsx)(r.Box, {
                    ref: c,
                    sx: {
                        display: u ? "initial" : "none",
                        left: [12, null, null, null, null, 16],
                        pointerEvents: "auto",
                        position: "absolute",
                        pt: 18,
                        top: 50,
                        transition: "visibility .15s, opacity .3s ease, top .25s",
                        width: "calc(100% - 32px)",
                        zIndex: 800
                    }
                }, (0, r.jsx)(r.Flex, {
                    as: "div",
                    ref: s,
                    sx: {
                        bg: "white",
                        borderRadius: "rounded",
                        boxShadow: "0px 0px 1px rgba(5, 25, 45, 0.3), 0px 8px 12px -4px rgba(5, 25, 45, 0.3)",
                        color: "text",
                        flexDirection: "row",
                        overflowX: "hidden",
                        overflowY: "scroll"
                    }
                }, (0, r.jsx)(o.default, {
                    authenticated: t,
                    device: n
                }), (0, r.jsx)(a.default, {
                    device: n
                }), (0, r.jsx)(l.default, {
                    device: n
                }), "desktop" === n && (0, r.jsx)(i.default, null)))
            };
            t.default = s
        },
        73278: function(e, t, n) {
            n(82526), n(41817), n(32165), n(91038), n(66992), n(47042), n(68309), n(41539), n(39714), n(78783), n(33948), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n(21217),
                o = v(n(22429)),
                i = v(n(74104)),
                a = n(11720),
                l = n(11720),
                u = n(18733),
                s = n(13350),
                c = n(53726),
                f = v(n(88570)),
                d = v(n(63586)),
                p = v(n(61369));

            function v(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function b(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" === typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        o = !1,
                        i = void 0;
                    try {
                        for (var a, l = e[Symbol.iterator](); !(r = (a = l.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                    } catch (u) {
                        o = !0, i = u
                    } finally {
                        try {
                            r || null == l.return || l.return()
                        } finally {
                            if (o) throw i
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" === typeof e) return y(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return y(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function y(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var h = function(e) {
                var t, n = e.authenticated,
                    v = e.hide,
                    y = e.isMobileVisible,
                    h = b((0, a.useState)(0), 2),
                    x = h[0],
                    m = h[1],
                    g = (0, c.useNavDispatcher)(),
                    j = function() {
                        m(0)
                    };
                return (0, a.useEffect)((function() {
                    var e, t = (0, s.getBannerOffsetHeight)();
                    m(t);
                    var n = document.querySelector(".dc-ps-close");
                    return null === (e = (0, l.findDOMNode)(n)) || void 0 === e || e.addEventListener("click", j),
                        function() {
                            var e;
                            null === (e = (0, l.findDOMNode)(n)) || void 0 === e || e.removeEventListener("click", j)
                        }
                }), [y]), (0, u.jsx)(a.Fragment, null, (0, u.jsx)(u.Box, {
                    sx: {
                        bg: "rgba(5, 25, 45, 0.7)",
                        bottom: 0,
                        left: 0,
                        position: "fixed",
                        right: 0,
                        top: x
                    }
                }), (0, u.jsx)(u.Box, {
                    as: "div",
                    sx: {
                        bg: "white",
                        flexDirection: "row",
                        height: x > 0 ? "calc(".concat((null === (t = window) || void 0 === t ? void 0 : t.innerHeight) - x, "px)") : "100%",
                        overflowY: "scroll",
                        pb: 80,
                        position: "fixed",
                        top: x,
                        zIndex: 100
                    }
                }, (0, u.jsx)(f.default, {
                    authenticated: n,
                    device: "mobile"
                }), (0, u.jsx)(d.default, {
                    device: "mobile"
                }), (0, u.jsx)(p.default, {
                    device: "mobile"
                }), (0, u.jsx)(u.Flex, {
                    sx: {
                        backgroundColor: "white",
                        bottom: 0,
                        boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.25), 0px -4px 16px rgba(5, 25, 45, 0.04)",
                        justifyContent: "space-between",
                        p: 16,
                        position: "fixed",
                        width: [327, 432],
                        zIndex: 1e3
                    }
                }, n ? (0, u.jsx)(a.Fragment, null, (0, u.jsx)(o.default, {
                    "aria-label": "My dashboard",
                    href: r.BASE_PATH,
                    intent: "success",
                    sx: {
                        "> span": {
                            fontFamily: "inherit"
                        },
                        borderColor: "navy.200",
                        width: "48.8%"
                    },
                    type: "link"
                }, "My dashboard"), (0, u.jsx)(o.default, {
                    appearance: "primary",
                    "aria-label": "Sign Out",
                    href: "undefined" !== typeof window ? (0, r.getSignOutRedirectPath)(window.location.pathname) : r.SIGN_OUT_PATH,
                    sx: {
                        width: "48.8%"
                    },
                    type: "link"
                }, "Sign Out")) : (0, u.jsx)(a.Fragment, null, (0, u.jsx)(o.default, {
                    "aria-label": "Sign in",
                    href: r.SIGN_IN_PATH,
                    sx: {
                        "> span": {
                            fontFamily: "inherit"
                        },
                        borderColor: "navy.200",
                        width: "48.8%"
                    },
                    type: "link"
                }, "Sign In"), (0, u.jsx)(o.default, {
                    appearance: "primary",
                    "aria-label": "Get started",
                    href: r.SIGN_UP_PATH,
                    intent: "success",
                    sx: {
                        width: "48.8%"
                    },
                    type: "link"
                }, "Get Started")))), (0, u.jsx)(u.Button, {
                    "aria-label": "Close menu",
                    onClick: function() {
                        v(), g((function() {
                            return {
                                activePanel: -1,
                                activeTab: -1
                            }
                        }))
                    },
                    sx: {
                        "&:active, &:focus, &:hover": {
                            bg: "rgba(5, 25, 45, 0)"
                        },
                        display: "inline-flex",
                        height: "100%",
                        justifyContent: "center",
                        position: "absolute",
                        right: 0,
                        top: 0,
                        width: 48
                    },
                    variant: "navbarIcon"
                }, (0, u.jsx)(i.default, {
                    "aria-hidden": !0,
                    sx: {
                        color: "white",
                        mt: 18
                    },
                    title: ""
                })))
            };
            t.default = h
        },
        63586: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, o = (r = n(75520)) && r.__esModule ? r : {
                    default: r
                },
                i = n(52987),
                a = n(18733),
                l = n(53726);
            var u = function(e) {
                var t, n = e.device,
                    r = (0, l.useNavState)((function(e) {
                        return {
                            activePanel: e.activePanel,
                            activeTab: e.activeTab
                        }
                    })),
                    u = r.activePanel,
                    s = r.activeTab,
                    c = (0, l.useNavDispatcher)(),
                    f = "mobile" === n,
                    d = f && s > -1 && -1 === u,
                    p = s > -1 && i.menuTabsComponentMapper[s].secondPanel;
                return f && u > -1 ? null : (0, a.jsx)("div", {
                    sx: {
                        width: [327, 432, null, "37%", null, "29%"]
                    }
                }, d && (0, a.jsx)(a.Flex, {
                    sx: {
                        alignItems: "center",
                        bg: "white",
                        borderBottom: "1px solid #CCCFD2",
                        height: 56,
                        justifyContent: "center",
                        position: "sticky",
                        top: 0,
                        width: [327, 432],
                        zIndex: 11
                    }
                }, (0, a.jsx)(a.Text, {
                    "aria-label": "Go back",
                    as: "button",
                    onClick: (t = -1, function() {
                        c((function() {
                            return {
                                activePanel: -1,
                                activeTab: t
                            }
                        }))
                    }),
                    sx: {
                        bg: "transparent",
                        border: "none",
                        left: 14,
                        mt: 4,
                        p: 0,
                        position: "absolute"
                    }
                }, (0, a.jsx)(o.default, {
                    "aria-hidden": !0,
                    size: 18
                })), (0, a.jsx)(a.Text, {
                    sx: {
                        fontSize: 16,
                        fontWeight: 600
                    }
                }, i.menuTabsComponentMapper[s].title)), p && (0, a.jsx)(p, {
                    device: n
                }))
            };
            t.default = u
        },
        45321: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n(18733),
                o = function() {
                    return (0, r.jsx)(r.Link, {
                        href: "#main",
                        sx: {
                            "&:focus": {
                                bg: "white",
                                borderColor: "yellow.200",
                                borderStyle: "solid",
                                borderWidth: 4,
                                color: "text",
                                height: "auto",
                                left: 20,
                                outline: "none",
                                overflow: "auto",
                                px: 15,
                                py: 10,
                                textDecoration: "none",
                                top: 20,
                                width: "auto",
                                zIndex: 9999
                            },
                            height: 1,
                            left: -999,
                            overflow: "hidden",
                            position: "absolute",
                            top: "auto",
                            width: 1
                        }
                    }, "Skip to main content")
                };
            t.default = o
        },
        61369: function(e, t, n) {
            n(82526), n(41817), n(32165), n(91038), n(66992), n(47042), n(68309), n(41539), n(39714), n(78783), n(33948), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, o = (r = n(75520)) && r.__esModule ? r : {
                    default: r
                },
                i = n(31100),
                a = n(52987),
                l = n(18733),
                u = n(53726);

            function s(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" === typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        o = !1,
                        i = void 0;
                    try {
                        for (var a, l = e[Symbol.iterator](); !(r = (a = l.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                    } catch (u) {
                        o = !0, i = u
                    } finally {
                        try {
                            r || null == l.return || l.return()
                        } finally {
                            if (o) throw i
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" === typeof e) return c(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return c(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function c(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var f = function(e) {
                var t, n = e.device,
                    r = (0, u.useNavDispatcher)(),
                    c = s((0, u.useNavState)((function(e) {
                        return "mobile" === n ? [e.activeTab, e.activePanel] : [e.activeTab]
                    })), 2),
                    f = c[0],
                    d = c[1],
                    p = void 0 === d ? -1 : d,
                    v = "mobile" === n && f > -1 && p > -1,
                    b = f > -1 && a.menuTabsComponentMapper[f].thirdPanel;
                return (0, l.jsx)("div", {
                    sx: {
                        position: "relative",
                        width: [327, 432, null, "37%", null, "29%"]
                    }
                }, v && (0, l.jsx)(l.Flex, {
                    sx: {
                        alignItems: "center",
                        bg: "white",
                        borderBottom: "1px solid #CCCFD2",
                        height: 56,
                        justifyContent: "center",
                        position: "sticky",
                        top: 0,
                        width: [327, 432],
                        zIndex: 11
                    }
                }, (0, l.jsx)(l.Text, {
                    "aria-label": "Go back",
                    as: "button",
                    onClick: (t = -1, function() {
                        r((function() {
                            return {
                                activePanel: t
                            }
                        }))
                    }),
                    sx: {
                        bg: "transparent",
                        border: "none",
                        left: 14,
                        mt: 4,
                        p: 0,
                        position: "absolute"
                    }
                }, (0, l.jsx)(o.default, {
                    "aria-hidden": !0,
                    size: 18
                })), i.navbarTabs[f][p].slug ? (0, l.jsx)(l.Link, {
                    href: i.navbarTabs[f][p].slug,
                    sx: {
                        color: "navy.200",
                        fontSize: 16,
                        fontWeight: 600
                    }
                }, i.navbarTabs[f][p].label) : (0, l.jsx)(l.Text, {
                    sx: {
                        color: "navy.200",
                        fontSize: 16,
                        fontWeight: 600
                    }
                }, i.navbarTabs[f][p].label)), b && (0, l.jsx)(b, {
                    device: n,
                    tabContent: i.navbarTabs[f]
                }))
            };
            t.default = f
        },
        56321: function(e, t, n) {
            function r(e) {
                return r = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, r(e)
            }
            n(82526), n(41817), n(32165), n(91038), n(26699), n(66992), n(47042), n(68309), n(41539), n(39714), n(32023), n(78783), n(33948), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n(21217),
                i = m(n(22429)),
                a = m(n(21658)),
                l = function(e) {
                    if (e && e.__esModule) return e;
                    if (null === e || "object" !== r(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var t = x();
                    if (t && t.has(e)) return t.get(e);
                    var n = {},
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var i in e)
                        if (Object.prototype.hasOwnProperty.call(e, i)) {
                            var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                            a && (a.get || a.set) ? Object.defineProperty(n, i, a) : n[i] = e[i]
                        }
                    n.default = e, t && t.set(e, n);
                    return n
                }(n(11720)),
                u = n(18733),
                s = m(n(48655)),
                c = m(n(29519)),
                f = m(n(46141)),
                d = m(n(53153)),
                p = m(n(23485)),
                v = m(n(12728)),
                b = m(n(38068)),
                y = m(n(73278)),
                h = m(n(45321));

            function x() {
                if ("function" !== typeof WeakMap) return null;
                var e = new WeakMap;
                return x = function() {
                    return e
                }, e
            }

            function m(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function g(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" === typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        o = !1,
                        i = void 0;
                    try {
                        for (var a, l = e[Symbol.iterator](); !(r = (a = l.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                    } catch (u) {
                        o = !0, i = u
                    } finally {
                        try {
                            r || null == l.return || l.return()
                        } finally {
                            if (o) throw i
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" === typeof e) return j(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return j(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function j(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var w = function(e) {
                var t, n, r = e.className,
                    x = e.includingMenu,
                    m = void 0 === x || x,
                    j = e.searchComponent,
                    w = e.signInRedirectPath,
                    S = (0, p.default)(),
                    O = S.isSignedIn,
                    P = S.loading,
                    _ = !P && O,
                    M = g((0, l.useState)(!1), 2),
                    k = M[0],
                    C = M[1],
                    I = g((0, l.useState)(!1), 2),
                    T = I[0],
                    N = I[1],
                    A = g((0, l.useState)(!1), 2),
                    z = A[0],
                    E = A[1],
                    H = (0, v.default)({
                        desktop: 1200
                    }),
                    D = "undefined" !== typeof window ? window.location.pathname : "";
                (0, l.useEffect)((function() {
                    T && "mobile" !== H && N(!1)
                }), [H, T]), w ? (t = (0, o.getSignInRedirectPath)(w), n = (0, o.getSignUpRedirectPath)(w)) : "undefined" !== typeof window ? (t = (0, o.getSignInRedirectPath)(window.location.pathname), n = (0, o.getSignUpRedirectPath)(window.location.pathname)) : (t = o.SIGN_IN_PATH, n = o.SIGN_UP_PATH), (0, l.useEffect)((function() {
                    (D.includes("/certification-for-business") || D.includes("/groups/business") || D.includes("/hire-data-professionals") || D.includes("/resources") || D.includes("/webinars")) && E(!0)
                }), [D]);
                return (0, u.jsx)(l.Fragment, null, (0, u.jsx)(h.default, null), (0, u.jsx)(u.Box, {
                    "aria-label": "Sitewide Navigation",
                    as: "nav",
                    className: r,
                    sx: {
                        bg: "navy.200",
                        position: "sticky",
                        top: 0,
                        zIndex: 800
                    }
                }, (0, u.jsx)(u.Container, {
                    sx: {
                        pb: 12,
                        position: "relative",
                        pt: 14
                    }
                }, (0, u.jsx)(u.Box, {
                    sx: {
                        alignItems: "center",
                        display: "flex",
                        justifyContent: "space-between"
                    }
                }, (0, u.jsx)(u.Flex, {
                    sx: {
                        alignItems: "center"
                    }
                }, (0, u.jsx)(u.Link, {
                    "aria-label": "Navigate to Home Page",
                    className: "ds-snowplow-navbar-logo",
                    href: o.BASE_PATH,
                    sx: {
                        "&:active, &:focus, &:hover": {
                            borderBottom: 0
                        },
                        alignItems: "center",
                        borderBottom: 0,
                        display: "flex"
                    }
                }, (0, u.jsx)(c.default, {
                    height: "34",
                    sx: {
                        transform: "translateY(-3px)"
                    },
                    width: "25"
                }), (0, u.jsx)(f.default, {
                    sx: {
                        ml: 8
                    }
                })), (0, u.jsx)(d.default, {
                    sx: {
                        display: ["none", null, null, null, null, "flex"],
                        ml: 8,
                        mr: [0, null, null, null, null, 42]
                    }
                })), m && "mobile" !== H && (0, u.jsx)(u.Box, {
                    sx: {
                        alignItems: "center",
                        display: "flex",
                        flexGrow: 2
                    }
                }, (0, u.jsx)(b.default, {
                    authenticated: _,
                    device: H
                }), "desktop" === H && (0, u.jsx)(l.Fragment, null, (0, u.jsx)(u.Link, {
                    className: "ds-snowplow-navbar-pricing ds-snowplow-li-main-menu-pricing",
                    href: o.PRICING_PATH,
                    sx: {
                        display: ["none", null, null, null, null, "flex"]
                    },
                    variant: "navbar"
                }, "Pricing"), (0, u.jsx)(u.Link, {
                    className: "ds-snowplow-navbar-for-business ds-snowplow-li-main-menu-for-business",
                    href: o.BUSINESS_PATH,
                    sx: {
                        display: ["none", null, null, null, null, "flex"]
                    },
                    target: "_blank",
                    variant: "navbar"
                }, "For Business"))), (0, u.jsx)(u.Flex, {
                    sx: {
                        justifyContent: "space-between"
                    }
                }, "mobile" === H ? (0, u.jsx)(u.Button, {
                    "aria-label": "Open mobile menu",
                    className: "ds-snowplow-navbar-mobile",
                    onClick: function() {
                        return N(!0)
                    },
                    sx: {
                        ml: 8
                    },
                    variant: "navbarIcon"
                }, (0, u.jsx)(a.default, {
                    "aria-hidden": !0,
                    sx: {
                        height: 27,
                        opacity: .5,
                        width: 27
                    },
                    title: ""
                })) : (0, u.jsx)(u.Flex, {
                    sx: {
                        display: [null, null, null, "flex"]
                    }
                }, m && (0, u.jsx)(u.Button, {
                    "aria-label": "Search",
                    className: "ds-snowplow-navbar-search",
                    onClick: function() {
                        return C(!k)
                    },
                    sx: {
                        alignItems: "center",
                        display: [null, null, null, "flex"],
                        width: 36
                    },
                    variant: "navbarIcon"
                }, (0, u.jsx)(s.default, {
                    sx: {
                        color: "white",
                        display: "block",
                        mx: "auto"
                    }
                })), !P && (0, u.jsx)((function() {
                    return (0, u.jsx)(l.default.Fragment, null, _ ? (0, u.jsx)(l.default.Fragment, null, (0, u.jsx)(i.default, {
                        appearance: "primary",
                        "aria-label": "Go to my dashboard",
                        className: "ds-snowplow-navbar-my-dashboard",
                        href: o.BASE_PATH,
                        intent: "success",
                        size: "small",
                        sx: {
                            ml: 8
                        },
                        type: "link"
                    }, "Go to my dashboard"), (0, u.jsx)(i.default, {
                        appearance: "inverted",
                        "aria-label": "Sign Out",
                        className: "ds-snowplow-navbar-sign-out",
                        href: "undefined" !== typeof window ? (0, o.getSignOutRedirectPath)(window.location.pathname) : o.SIGN_OUT_PATH,
                        sx: {
                            "&:active, &:focus, &:hover": {
                                borderColor: "green.200"
                            },
                            "> span": {
                                color: "white",
                                lineHeight: "36px"
                            },
                            height: 36,
                            mx: 8
                        },
                        type: "link"
                    }, "Sign Out")) : (0, u.jsx)(l.default.Fragment, null, (0, u.jsx)(i.default, {
                        appearance: "inverted",
                        "aria-label": "Sign In",
                        className: "ds-snowplow-navbar-sign-in",
                        href: t,
                        sx: {
                            "&:active, &:focus, &:hover": {
                                borderColor: "green.200"
                            },
                            "> span": {
                                color: "white",
                                lineHeight: "36px"
                            },
                            height: 36,
                            mx: 8
                        },
                        type: "link"
                    }, "Sign In"), z ? (0, u.jsx)(i.default, {
                        appearance: "inverted",
                        "aria-label": "Request a Demo",
                        className: "ds-snowplow-navbar-sign-up",
                        href: o.BUSINESS_DEMO_PATH,
                        sx: {
                            "&:active, &:focus, &:hover": {
                                bg: function(e) {
                                    return "".concat(e.colors.green[200], " !important")
                                },
                                borderColor: "green.200"
                            },
                            "> span": {
                                color: "text",
                                lineHeight: "36px"
                            },
                            bg: "white !important",
                            height: 36,
                            mx: 8,
                            textTransform: "unset"
                        },
                        type: "link"
                    }, "Request a Demo") : (0, u.jsx)(i.default, {
                        appearance: "inverted",
                        "aria-label": "Get Started",
                        className: "ds-snowplow-navbar-sign-up",
                        href: n,
                        sx: {
                            "&:active, &:focus, &:hover": {
                                bg: function(e) {
                                    return "".concat(e.colors.green[200], " !important")
                                },
                                borderColor: "green.200"
                            },
                            "> span": {
                                color: "text",
                                lineHeight: "36px"
                            },
                            bg: "white !important",
                            height: 36
                        },
                        type: "link"
                    }, "Get Started")))
                }), null))))), k && (0, l.cloneElement)(j, {
                    hide: function() {
                        return C(!1)
                    }
                }), T && (0, u.jsx)(y.default, {
                    authenticated: _,
                    hide: function() {
                        return N(!1)
                    },
                    isMobileVisible: T
                })))
            };
            t.default = w
        },
        13350: function(e, t, n) {
            function r(e) {
                return r = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, r(e)
            }
            n(82526), n(41817), n(32165), n(66992), n(41539), n(78783), n(33948), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getBannerOffsetHeight = void 0;
            t.getBannerOffsetHeight = function() {
                if ("object" === ("undefined" === typeof window ? "undefined" : r(window))) {
                    var e = document.querySelector(".dc-ps-banner-wrapper");
                    if (e) return e.offsetHeight;
                    var t = document.querySelector('[data-banner="banner"]');
                    if (t) return t.offsetHeight
                }
                return 0
            }
        },
        12728: function(e, t, n) {
            n(82526), n(41817), n(32165), n(91038), n(66992), n(47042), n(68309), n(41539), n(39714), n(78783), n(33948), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, o = n(11720),
                i = (r = n(62693)) && r.__esModule ? r : {
                    default: r
                };

            function a(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" === typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        o = !1,
                        i = void 0;
                    try {
                        for (var a, l = e[Symbol.iterator](); !(r = (a = l.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                    } catch (u) {
                        o = !0, i = u
                    } finally {
                        try {
                            r || null == l.return || l.return()
                        } finally {
                            if (o) throw i
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" === typeof e) return l(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return l(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function l(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var u = function(e) {
                var t = e.desktop,
                    n = void 0 === t ? 992 : t,
                    r = e.mobile,
                    l = void 0 === r ? 768 : r,
                    u = (0, i.default)(),
                    s = a((0, o.useState)("mobile"), 2),
                    c = s[0],
                    f = s[1];
                return (0, o.useEffect)((function() {
                    u.width && (u.width < l ? f("mobile") : u.width >= l && u.width < n ? f("tablet") : f("desktop"))
                }), [n, l, u.width]), c
            };
            t.default = u
        },
        62693: function(e, t, n) {
            n(82526), n(41817), n(32165), n(91038), n(66992), n(47042), n(68309), n(41539), n(39714), n(78783), n(33948), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n(11720);

            function o(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" === typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        o = !1,
                        i = void 0;
                    try {
                        for (var a, l = e[Symbol.iterator](); !(r = (a = l.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                    } catch (u) {
                        o = !0, i = u
                    } finally {
                        try {
                            r || null == l.return || l.return()
                        } finally {
                            if (o) throw i
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" === typeof e) return i(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return i(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function i(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var a = function() {
                var e = o((0, r.useState)({
                        height: void 0,
                        width: void 0
                    }), 2),
                    t = e[0],
                    n = e[1];
                return (0, r.useEffect)((function() {
                    function e() {
                        n({
                            height: window.innerHeight,
                            width: window.innerWidth
                        })
                    }
                    return window.addEventListener("load", e), window.addEventListener("resize", e), e(),
                        function() {
                            window.removeEventListener("load", e), window.removeEventListener("resize", e)
                        }
                }), []), t
            };
            t.default = a
        },
        75520: function(e, t, n) {
            var r = n(20862),
                o = n(95318);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n(45697)),
                a = r(n(11720)),
                l = n(70917),
                u = a.forwardRef((function(e, t) {
                    var n = e["aria-hidden"],
                        r = void 0 !== n && n,
                        o = e.className,
                        i = e.color,
                        a = void 0 === i ? "currentColor" : i,
                        u = e.size,
                        s = void 0 === u ? 18 : u,
                        c = e.title,
                        f = e.titleId;
                    return (0, l.jsx)("svg", {
                        viewBox: "0 0 18 18",
                        "aria-hidden": r,
                        className: o,
                        height: s,
                        ref: t,
                        role: "img",
                        width: s,
                        "aria-labelledby": f
                    }, void 0 === c ? (0, l.jsx)("title", {
                        id: f
                    }, "Left Arrow") : c ? (0, l.jsx)("title", {
                        id: f
                    }, c) : null, (0, l.jsx)("path", {
                        fill: a,
                        d: "M4.42 8L16 7.998a1 1 0 010 2L4.41 10l3.285 3.296a.998.998 0 11-1.417 1.41l-4.93-4.948A.998.998 0 011.36 8.23l4.933-4.938a1 1 0 011.414 0c.39.391.39 1.025 0 1.416L4.42 7.999z",
                        fillRule: "evenodd"
                    }))
                }));
            u.propTypes = {
                "aria-hidden": i.default.bool,
                className: i.default.string,
                color: i.default.string,
                size: i.default.oneOf([12, 18, 24]),
                title: i.default.string,
                titleId: i.default.string
            };
            var s = u;
            t.default = s
        },
        62677: function(e, t, n) {
            var r = n(20862),
                o = n(95318);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n(45697)),
                a = r(n(11720)),
                l = n(70917),
                u = a.forwardRef((function(e, t) {
                    var n = e["aria-hidden"],
                        r = void 0 !== n && n,
                        o = e.className,
                        i = e.color,
                        a = void 0 === i ? "currentColor" : i,
                        u = e.size,
                        s = void 0 === u ? 18 : u,
                        c = e.title,
                        f = e.titleId;
                    return (0, l.jsx)("svg", {
                        viewBox: "0 0 18 18",
                        "aria-hidden": r,
                        className: o,
                        height: s,
                        ref: t,
                        role: "img",
                        width: s,
                        "aria-labelledby": f
                    }, void 0 === c ? (0, l.jsx)("title", {
                        id: f
                    }, "Down Chevron") : c ? (0, l.jsx)("title", {
                        id: f
                    }, c) : null, (0, l.jsx)("path", {
                        fill: a,
                        d: "M8.244 12.155l-4.95-4.947a1 1 0 111.415-1.415l4.294 4.291 4.293-4.279a.998.998 0 011.413.003c.39.392.388 1.025-.003 1.415l-5.002 4.986a.998.998 0 01-1.46-.054z",
                        fillRule: "evenodd"
                    }))
                }));
            u.propTypes = {
                "aria-hidden": i.default.bool,
                className: i.default.string,
                color: i.default.string,
                size: i.default.oneOf([12, 18, 24]),
                title: i.default.string,
                titleId: i.default.string
            };
            var s = u;
            t.default = s
        },
        74104: function(e, t, n) {
            var r = n(20862),
                o = n(95318);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n(45697)),
                a = r(n(11720)),
                l = n(70917),
                u = a.forwardRef((function(e, t) {
                    var n = e["aria-hidden"],
                        r = void 0 !== n && n,
                        o = e.className,
                        i = e.color,
                        a = void 0 === i ? "currentColor" : i,
                        u = e.size,
                        s = void 0 === u ? 18 : u,
                        c = e.title,
                        f = e.titleId;
                    return (0, l.jsx)("svg", {
                        viewBox: "0 0 18 18",
                        "aria-hidden": r,
                        className: o,
                        height: s,
                        ref: t,
                        role: "img",
                        width: s,
                        "aria-labelledby": f
                    }, void 0 === c ? (0, l.jsx)("title", {
                        id: f
                    }, "Cross") : c ? (0, l.jsx)("title", {
                        id: f
                    }, c) : null, (0, l.jsx)("path", {
                        fill: a,
                        d: "M9.005 7.625l4.83-4.83a.976.976 0 011.38 1.38l-4.83 4.83 4.82 4.82a.976.976 0 11-1.38 1.38l-4.82-4.82-4.83 4.83a.976.976 0 01-1.38-1.38l4.83-4.83-4.84-4.84a.976.976 0 111.38-1.38l4.84 4.84z",
                        fillRule: "evenodd"
                    }))
                }));
            u.propTypes = {
                "aria-hidden": i.default.bool,
                className: i.default.string,
                color: i.default.string,
                size: i.default.oneOf([12, 18, 24]),
                title: i.default.string,
                titleId: i.default.string
            };
            var s = u;
            t.default = s
        },
        21658: function(e, t, n) {
            var r = n(20862),
                o = n(95318);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n(45697)),
                a = r(n(11720)),
                l = n(70917),
                u = a.forwardRef((function(e, t) {
                    var n = e["aria-hidden"],
                        r = void 0 !== n && n,
                        o = e.className,
                        i = e.color,
                        a = void 0 === i ? "currentColor" : i,
                        u = e.size,
                        s = void 0 === u ? 18 : u,
                        c = e.title,
                        f = e.titleId;
                    return (0, l.jsx)("svg", {
                        viewBox: "0 0 18 18",
                        "aria-hidden": r,
                        className: o,
                        height: s,
                        ref: t,
                        role: "img",
                        width: s,
                        "aria-labelledby": f
                    }, void 0 === c ? (0, l.jsx)("title", {
                        id: f
                    }, "Menu") : c ? (0, l.jsx)("title", {
                        id: f
                    }, c) : null, (0, l.jsx)("path", {
                        fill: a,
                        d: "M4 6a1 1 0 110-2h10a1 1 0 010 2H4zm0 4a1 1 0 110-2h10a1 1 0 010 2H4zm0 4a1 1 0 010-2h10a1 1 0 010 2H4z",
                        fillRule: "evenodd"
                    }))
                }));
            u.propTypes = {
                "aria-hidden": i.default.bool,
                className: i.default.string,
                color: i.default.string,
                size: i.default.oneOf([12, 18, 24]),
                title: i.default.string,
                titleId: i.default.string
            };
            var s = u;
            t.default = s
        }
    }
]);
//# sourceMappingURL=56321-eeeb37db2f51c052.js.map