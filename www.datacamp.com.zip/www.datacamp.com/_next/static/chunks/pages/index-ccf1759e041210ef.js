(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [95405], {
        47159: function(l, n, e) {
            "use strict";
            var t, r = e(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(l) {
                    for (var n = 1; n < arguments.length; n++) {
                        var e = arguments[n];
                        for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (l[t] = e[t])
                    }
                    return l
                }, a.apply(this, arguments)
            }
            n.Z = function(l) {
                return r.createElement("svg", a({
                    viewBox: "0 0 743 458",
                    xmlns: "http://www.w3.org/2000/svg"
                }, l), t || (t = r.createElement("path", {
                    d: "m732.36 251.65-.4.36-234.34 205.43-39.55-45.12L633 258.97l-632.14.15-.02-60 631.33-.15L458.02 45.63 497.67.6 732 206.94a30 30 0 0 1 .36 44.7z",
                    fill: "currentColor"
                })))
            }
        },
        48312: function(l, n, e) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
                return e(79754)
            }])
        },
        29407: function(l, n, e) {
            "use strict";
            var t = e(44103),
                r = (e(11720), e(7388)),
                a = e(83564),
                i = e(53166),
                u = e(74255),
                s = e(2294);
            n.Z = function(l) {
                var n = l.className,
                    e = l.highlightColor;
                return (0, t.BX)(r.W2, {
                    className: n,
                    children: [(0, t.BX)(r.xv, {
                        as: "h2",
                        sx: {
                            fontSize: ["800", null, null, null, "800"],
                            textAlign: "center"
                        },
                        variant: "h40",
                        children: [(0, t.tZ)("span", {
                            sx: {
                                color: e ? "white" : "green.200"
                            },
                            children: "Hands-on"
                        }), " ", "learning experience"]
                    }), (0, t.tZ)(i.Z, {}), (0, t.tZ)(u.Z, {}), (0, t.tZ)(s.Z, {}), (0, t.tZ)(a.Z, {})]
                })
            }
        },
        83564: function(l, n, e) {
            "use strict";
            var t = e(44103),
                r = e(25675),
                a = e.n(r),
                i = (e(11720), e(7388)),
                u = e(8683),
                s = e(66674),
                c = e(42725);
            n.Z = function(l) {
                var n = l.highlightColor;
                return (0, t.BX)(u.Z, {
                    sx: {
                        "> *": {
                            width: [null, null, null, null, "50%"]
                        },
                        alignItems: [null, null, null, null, "center"],
                        display: [null, null, null, null, "flex"],
                        mt: [80, null, null, null, 144]
                    },
                    children: [(0, t.tZ)(s.Z, {
                        children: (0, t.BX)(c.Z, {
                            sx: {
                                maxWidth: 254,
                                mx: ["auto", null, null, null, 0]
                            },
                            children: [(0, t.tZ)("span", {
                                sx: {
                                    color: n || "pink.200"
                                },
                                children: "Practice"
                            }), " and", " ", (0, t.tZ)("span", {
                                sx: {
                                    color: n || "pink.200"
                                },
                                children: "apply"
                            }), " your skills"]
                        })
                    }), (0, t.tZ)(i.kC, {
                        sx: {
                            "> span": {
                                img: {
                                    height: "auto",
                                    maxWidth: ["100%", null, null, 450]
                                },
                                mr: "16px !important"
                            },
                            alignItems: "flex-start",
                            flexShrink: 0,
                            justifyContent: ["center", null, null, null, "flex-end"],
                            mt: [16, null, null, null, 0],
                            mx: ["auto", null, null, null, 0],
                            pr: [null, null, null, null, 40]
                        },
                        children: (0, t.tZ)(a(), {
                            alt: "Screenshot of campus exercise and dragging answer",
                            height: 327.27,
                            src: "/Marketing/Illustrations/campus-drag-and-drop.png",
                            width: 450
                        })
                    })]
                })
            }
        },
        74255: function(l, n, e) {
            "use strict";
            var t = e(44103),
                r = e(25675),
                a = e.n(r),
                i = (e(11720), e(7388)),
                u = e(8683),
                s = e(66674),
                c = e(42725);
            n.Z = function(l) {
                var n = l.inverted;
                return (0, t.BX)(u.Z, {
                    inverted: n,
                    sx: {
                        "> *": {
                            width: [null, null, null, null, "50%"]
                        },
                        alignItems: [null, null, null, null, "center"],
                        display: [null, null, null, null, "flex"],
                        mt: [80, null, null, null, 144]
                    },
                    children: [(0, t.tZ)(s.Z, {
                        children: (0, t.tZ)(c.Z, {
                            captions: ["Learn from the ", "best instructors"],
                            colors: ["white", "purple.200"],
                            sx: {
                                maxWidth: 254,
                                mx: ["auto", null, null, null, 0]
                            }
                        })
                    }), (0, t.tZ)(i.kC, {
                        sx: {
                            alignItems: "flex-start",
                            flexShrink: 0,
                            img: {
                                aspectRatio: "".concat(902 / 728),
                                height: "auto",
                                maxWidth: ["100%", null, null, 451]
                            },
                            justifyContent: ["center", null, null, null, "flex-start"],
                            mt: [16, null, null, null, 0],
                            mx: ["auto", null, null, null, 0],
                            pr: [null, null, null, null, 40]
                        },
                        children: (0, t.tZ)(a(), {
                            alt: "Screenshot of Campus exercise",
                            height: 364,
                            src: "/Marketing/Illustrations/instructors.jpg",
                            width: 451
                        })
                    })]
                })
            }
        },
        79754: function(l, n, e) {
            "use strict";
            e.r(n), e.d(n, {
                __N_SSG: function() {
                    return I
                },
                default: function() {
                    return M
                }
            });
            var t, r = e(44103),
                a = e(79547),
                i = e.n(a),
                u = (e(48318), e(37322)),
                s = e(13035),
                c = e(58423),
                o = e(64396),
                h = e(89077),
                d = e(21217),
                x = e(10491),
                p = e(34505),
                m = e(22429),
                f = e(25675),
                g = e.n(f),
                b = e(7388),
                v = e(47159),
                Z = e(38579),
                k = e(22163),
                y = e(66234),
                w = e(67979),
                B = e(51707),
                W = e(26303),
                C = e(29407),
                S = e(11720);

            function E() {
                return E = Object.assign ? Object.assign.bind() : function(l) {
                    for (var n = 1; n < arguments.length; n++) {
                        var e = arguments[n];
                        for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (l[t] = e[t])
                    }
                    return l
                }, E.apply(this, arguments)
            }
            var j = function(l) {
                    return S.createElement("svg", E({
                        width: 1062,
                        height: 1029,
                        xmlns: "http://www.w3.org/2000/svg"
                    }, l), t || (t = S.createElement("g", {
                        fill: "none",
                        fillRule: "evenodd"
                    }, S.createElement("path", {
                        d: "M558.9 125.83C369.7 92.46 187.27 182.87 94.6 338.92",
                        stroke: "#102337",
                        strokeWidth: 2.1
                    }), S.createElement("path", {
                        d: "M790.7 351.48c-53.32-82.3-138.78-143.67-242.71-163.87a372.66 372.66 0 0 0-233.82 30.15",
                        stroke: "#102337",
                        strokeWidth: 2.1
                    }), S.createElement("path", {
                        d: "M175.57 514.57c-29.6 167.9 82.63 326.96 250.44 356.55M175.57 514.57a305.83 305.83 0 0 0 26.39 188.2",
                        stroke: "#06BDFC",
                        strokeWidth: 15.75
                    }), S.createElement("path", {
                        d: "M175.57 514.57a305.83 305.83 0 0 0 26.39 188.2",
                        stroke: "#7933FF",
                        strokeWidth: 15.75
                    }), S.createElement("path", {
                        d: "M101.22 496.19a383.1 383.1 0 0 0 3.38 149.7 383.71 383.71 0 0 0 36.84 98.96",
                        stroke: "#102337",
                        strokeWidth: 2.1
                    }), S.createElement("path", {
                        d: "M770.95 458.13c-37.6-97.74-124.02-173.91-234.66-193.42",
                        stroke: "#06BDFC",
                        strokeWidth: 15.75
                    }), S.createElement("path", {
                        d: "M786.7 622.32A307.26 307.26 0 0 0 768 450.76",
                        stroke: "#FF6EA9",
                        strokeWidth: 15.75
                    }), S.createElement("path", {
                        d: "M256.62 302.82c75.74-64.17 179.24-95.27 285.38-76.55",
                        stroke: "#102337",
                        strokeWidth: 12.6
                    }), S.createElement("path", {
                        d: "M426.16 871.15c75.9 13.38 150.6-1.32 211.9-37.68",
                        stroke: "#7933FF",
                        strokeWidth: 15.75
                    }), S.createElement("path", {
                        d: "M314.19 846.6c31.65 19.45 68.1 32.8 109.36 40.08 153.37 27.04 300.91-56.73 358.9-193.93",
                        stroke: "#213147",
                        strokeWidth: 15.75
                    }), S.createElement("path", {
                        d: "M328.76 317.68c-70.05 41.8-122.23 112.73-137.52 199.45a295.3 295.3 0 0 0-3.2 23.67",
                        stroke: "#FF6EA9",
                        strokeWidth: 15.75
                    }), S.createElement("path", {
                        d: "M191.2 517.32c-11.1 63.02-1.91 125 24.87 178.46",
                        stroke: "#FFF",
                        strokeWidth: 15.75
                    }), S.createElement("path", {
                        d: "M671.68 912.26C773.14 856.47 849.33 756.89 871 633.99M311.36 208.67c-93.04 44.22-167.7 124.06-203.48 225.18a398.22 398.22 0 0 0-16.73 63.7",
                        stroke: "#FF6EA9",
                        strokeWidth: 21
                    }), S.createElement("path", {
                        d: "M619.04 936.38c18.2-6.77 37.78-16.03 54.7-25.34",
                        stroke: "#06BDFC",
                        strokeWidth: 21
                    }), S.createElement("path", {
                        d: "M724.08 975.92c114.1-68.39 199.05-184.06 223.97-325.4 20.99-119-4.25-235.48-62.8-330.98M562.63 99.83c-164.32-28.98-323.8 30.27-429.9 143.71",
                        stroke: "#213147",
                        strokeWidth: 52.5,
                        opacity: .4
                    }), S.createElement("path", {
                        d: "M781.56 694.99a331.07 331.07 0 0 0 20.6-69.65c11.13-63.13 3.02-125.28-19.6-180.58",
                        stroke: "#FFF",
                        strokeWidth: 15.75
                    }))))
                },
                X = function() {
                    return (0, r.tZ)(b.xu, {
                        sx: {
                            bg: "navy.200",
                            overflow: "hidden",
                            position: "relative"
                        },
                        children: (0, r.BX)(b.W2, {
                            sx: {
                                alignItems: [null, null, null, null, null, "center"],
                                display: [null, null, null, null, null, "flex"],
                                height: ["auto", null, null, null, null, 626],
                                justifyContent: [null, null, null, null, null, "space-between"],
                                maxWidth: [550, null, null, null, null, 1172],
                                pb: [64, null, null, null, null, 90],
                                position: "relative",
                                pt: [64, null, null, null, null, 72],
                                zIndex: 10
                            },
                            children: [(0, r.BX)(b.xu, {
                                sx: {
                                    pt: [48, null, null, null, 0],
                                    textAlign: [null, null, null, null, "left"],
                                    width: ["100%", null, null, null, null, "40%"]
                                },
                                children: [(0, r.tZ)(b.xv, {
                                    as: "p",
                                    sx: {
                                        color: "blue.200",
                                        mb: 12
                                    },
                                    variant: "c14",
                                    children: "Workspace"
                                }), (0, r.tZ)(b.xv, {
                                    as: "h2",
                                    sx: {
                                        color: "white",
                                        mb: 8
                                    },
                                    variant: "h40",
                                    children: "Start your own data analysis in seconds"
                                }), (0, r.tZ)(b.xv, {
                                    as: "p",
                                    sx: {
                                        color: "white",
                                        mb: 16
                                    },
                                    variant: "t18",
                                    children: "Your personal in-browser tool to write, run, and share your data analysis."
                                }), (0, r.tZ)(m.default, {
                                    appearance: "inverted",
                                    href: d.workspaceMarketing.LANDING_PATH,
                                    type: "link",
                                    children: "Learn More"
                                })]
                            }), (0, r.BX)(b.kC, {
                                sx: {
                                    alignItems: "flex-start",
                                    flexShrink: 0,
                                    img: {
                                        height: "auto",
                                        maxWidth: "100%"
                                    },
                                    justifyContent: [null, null, null, "flex-start"],
                                    mt: [32, null, null, null, null, 0],
                                    mx: ["auto", null, null, null, 0]
                                },
                                children: [(0, r.tZ)(g(), {
                                    alt: "Screenshot of workspace and user's photo",
                                    height: 300,
                                    src: "Marketing/Illustrations/workspace-header-img.png",
                                    width: 424
                                }), (0, r.BX)(b.kC, {
                                    "aria-hidden": "true",
                                    sx: {
                                        bottom: -105,
                                        display: ["none", null, null, null, null, "flex"],
                                        position: "absolute",
                                        right: -350
                                    },
                                    children: [" ", (0, r.tZ)(j, {
                                        "aria-hidden": "true",
                                        sx: {
                                            flexShrink: 0
                                        }
                                    })]
                                })]
                            })]
                        })
                    })
                },
                A = e(81831),
                I = !0,
                M = function(l) {
                    var n = l.stats;
                    return (0, r.BX)(r.HY, {
                        children: [(0, r.tZ)(i(), {
                            id: "c80dbc0b64ccf72d",
                            children: "body{background-color:#f7f3eb}"
                        }), (0, r.tZ)(B.Z, {
                            formIdPrefix: "intro",
                            formTitleElement: "h2",
                            children: (0, r.BX)(b.xu, {
                                sx: {
                                    pb: [32, null, null, null, 0],
                                    pr: [null, null, null, null, 32, null],
                                    textAlign: ["left", "center", null, null, "left"]
                                },
                                children: [(0, r.tZ)(b.xv, {
                                    as: "h1",
                                    sx: {
                                        color: "white",
                                        maxWidth: [null, null, 525],
                                        mx: ["auto", null, null, null, 0]
                                    },
                                    variant: "h50",
                                    children: "Build data skills online"
                                }), (0, r.tZ)(b.xv, {
                                    as: "p",
                                    sx: {
                                        color: "white",
                                        maxWidth: [null, null, 420],
                                        mb: 24,
                                        mt: 16,
                                        mx: ["auto", null, null, null, 0]
                                    },
                                    variant: "t24",
                                    children: "Data drives everything. Get the skills you need for the future of work."
                                }), (0, r.tZ)(m.default, {
                                    appearance: "primary",
                                    href: d.SIGN_UP_PATH,
                                    intent: "success",
                                    size: "large",
                                    sx: {
                                        display: "flex",
                                        mx: ["auto", null, null, null, 0],
                                        width: [null, 365]
                                    },
                                    type: "link",
                                    children: "Start Learning For Free"
                                }), (0, r.tZ)(m.default, {
                                    appearance: "inverted",
                                    href: d.BUSINESS_PATH,
                                    intent: "neutral",
                                    size: "large",
                                    sx: {
                                        display: "flex",
                                        mt: 16,
                                        mx: ["auto", null, null, null, 0],
                                        width: [null, 365]
                                    },
                                    type: "link",
                                    children: "DataCamp For Business"
                                })]
                            })
                        }), (0, r.BX)("main", {
                            className: "jsx-c80dbc0b64ccf72d",
                            children: [(0, r.tZ)(b.xu, {
                                sx: {
                                    py: [86, null, null, null, 128]
                                },
                                children: (0, r.BX)(b.W2, {
                                    sx: {
                                        alignItems: "center",
                                        display: "flex",
                                        flexDirection: ["column", null, null, null, "row"],
                                        justifyContent: "space-between"
                                    },
                                    children: [(0, r.BX)(b.xu, {
                                        sx: {
                                            pt: [48, null, null, null, 0],
                                            textAlign: ["center", null, null, null, "left"],
                                            width: ["100%", null, null, null, "50%"]
                                        },
                                        children: [(0, r.tZ)(b.xv, {
                                            as: "p",
                                            sx: {
                                                color: "red.200",
                                                mb: 12
                                            },
                                            variant: "c14",
                                            children: "Loved by learners at thousands of companies"
                                        }), (0, r.tZ)(b.xv, {
                                            as: "h2",
                                            sx: {
                                                mb: 8
                                            },
                                            variant: "h40",
                                            children: "Skill up at scale. Data training designed for your business."
                                        }), (0, r.tZ)(b.xv, {
                                            as: "p",
                                            sx: {
                                                mb: 16
                                            },
                                            variant: "t18",
                                            children: "Join ".concat((0, p.roundNumber)(x.default.noOfCompanies, 100), "+ companies and ").concat(x.default.percentOfFortune1000, "% of the Fortune 1000 who use DataCamp to\n          upskill their teams.")
                                        }), (0, r.tZ)(m.default, {
                                            appearance: "primary",
                                            href: d.BUSINESS_PATH,
                                            intent: "neutral",
                                            type: "link",
                                            children: "Learn More"
                                        })]
                                    }), (0, r.tZ)(o.default, {
                                        primaryOnly: !0,
                                        sx: {
                                            "> div": {
                                                maxWidth: 500
                                            },
                                            color: "text",
                                            maxWidth: 500,
                                            mt: [null, null, null, null, -48],
                                            svg: {
                                                mt: [null, null, null, null, 48]
                                            }
                                        }
                                    })]
                                })
                            }), (0, r.BX)(b.xu, {
                                sx: {
                                    backgroundImage: "url(/marketing-backgrounds/bg-home.svg)",
                                    backgroundPosition: ["center 600px", null, "center 1000px", "center 300px", null, "center 100px", "center 250px"],
                                    backgroundRepeat: "no-repeat"
                                },
                                children: [(0, r.tZ)(y.Z, {}), (0, r.tZ)(b.xu, {
                                    as: "section",
                                    className: "invert",
                                    sx: {
                                        bg: ["navy.200", null, null, "transparent"],
                                        pt: [48, null, null, null, null, 96]
                                    },
                                    children: (0, r.tZ)(C.Z, {})
                                }), (0, r.BX)(b.xu, {
                                    as: "section",
                                    children: [(0, r.tZ)(b.xu, {
                                        "aria-labelledby": "learning-paths",
                                        as: "nav",
                                        children: (0, r.BX)(b.W2, {
                                            sx: {
                                                pb: 64,
                                                pt: [64, null, null, null, null, null, 250],
                                                textAlign: ["center", null, null, null, null, "left"]
                                            },
                                            children: [(0, r.BX)(b.xv, {
                                                as: "h2",
                                                id: "learning-paths",
                                                sx: {
                                                    color: ["white"]
                                                },
                                                variant: "h40",
                                                children: ["Learning paths", " ", (0, r.tZ)("span", {
                                                    sx: {
                                                        color: "green.200"
                                                    },
                                                    className: "jsx-c80dbc0b64ccf72d",
                                                    children: "designed by experts"
                                                })]
                                            }), (0, r.tZ)(b.xv, {
                                                as: "h3",
                                                sx: {
                                                    color: "white",
                                                    mb: 8,
                                                    mt: 32
                                                },
                                                variant: "h32",
                                                children: "Learn a new technology"
                                            }), (0, r.BX)(b.kC, {
                                                sx: {
                                                    flexWrap: "wrap",
                                                    justifyContent: "center",
                                                    mx: -16
                                                },
                                                children: [A.qf.map((function(l) {
                                                    return (0, r.tZ)(b.rU, {
                                                        className: "ie-accentBottom",
                                                        href: l.path,
                                                        sx: {
                                                            alignItems: "center",
                                                            boxShadow: "0 1px 4px -1px rgba(5, 25, 45, 0.3), 0 0 1px 0 rgba(5, 25, 45, 0.3);",
                                                            display: "flex",
                                                            height: 103,
                                                            justifyContent: "center",
                                                            m: 16,
                                                            width: 260
                                                        },
                                                        variant: "accentBottom",
                                                        children: (0, r.tZ)(W.Z, {
                                                            single: l.prop,
                                                            singleWidth: l.width
                                                        })
                                                    }, l.path)
                                                })), (0, r.BX)(b.rU, {
                                                    className: "ie-accentBottom",
                                                    href: "/courses/introduction-to-oracle-sql",
                                                    sx: {
                                                        alignItems: "center",
                                                        boxShadow: "0 1px 4px -1px rgba(5, 25, 45, 0.3), 0 0 1px 0 rgba(5, 25, 45, 0.3);",
                                                        display: "flex",
                                                        height: 103,
                                                        justifyContent: "center",
                                                        m: 16,
                                                        width: 260
                                                    },
                                                    variant: "accentBottom",
                                                    children: [(0, r.tZ)("i", {
                                                        "aria-hidden": "true",
                                                        className: "jsx-c80dbc0b64ccf72d",
                                                        children: (0, r.tZ)(k.Z, {
                                                            width: "148"
                                                        })
                                                    }), (0, r.tZ)("span", {
                                                        className: "jsx-c80dbc0b64ccf72d visually-hidden",
                                                        children: "Oracle"
                                                    })]
                                                })]
                                            }), (0, r.tZ)(b.kC, {
                                                sx: {
                                                    justifyContent: ["center", null, null, null, null, "flex-end"]
                                                },
                                                children: (0, r.BX)(b.rU, {
                                                    href: d.COURSES_PATH,
                                                    sx: {
                                                        "&:active, &:focus, &:hover": {
                                                            color: "blue.200",
                                                            textDecoration: "none"
                                                        },
                                                        alignItems: "center",
                                                        color: "text",
                                                        display: "flex",
                                                        fontSize: 400,
                                                        mt: 8,
                                                        svg: {
                                                            color: "blue.200"
                                                        },
                                                        transition: "color 0.3s cubic-bezier(0.85, 0, 0.15, 1)"
                                                    },
                                                    children: ["Explore All Technologies", " ", (0, r.tZ)(v.Z, {
                                                        sx: {
                                                            ml: 8
                                                        },
                                                        width: "18"
                                                    })]
                                                })
                                            })]
                                        })
                                    }), (0, r.tZ)(b.xu, {
                                        "aria-labelledby": "career",
                                        as: "nav",
                                        children: (0, r.BX)(b.W2, {
                                            sx: {
                                                pb: 64,
                                                textAlign: ["center", null, null, null, null, "left"]
                                            },
                                            children: [(0, r.tZ)(b.xv, {
                                                as: "h3",
                                                id: "career",
                                                sx: {
                                                    mb: 8,
                                                    mt: 32
                                                },
                                                variant: "h32",
                                                children: "Launch your career"
                                            }), (0, r.tZ)(b.kC, {
                                                sx: {
                                                    flexWrap: "wrap",
                                                    justifyContent: "center",
                                                    mx: -16
                                                },
                                                children: A.y3.map((function(l) {
                                                    return (0, r.tZ)(b.rU, {
                                                        className: "ie-accentBottom",
                                                        href: l.path,
                                                        sx: {
                                                            "&::after": {
                                                                bg: "pink.200"
                                                            },
                                                            alignItems: "center",
                                                            boxShadow: "0 1px 4px -1px rgba(5, 25, 45, 0.3), 0 0 1px 0 rgba(5, 25, 45, 0.3);",
                                                            color: "text",
                                                            display: "flex",
                                                            fontSize: 600,
                                                            fontWeight: "bold",
                                                            justifyContent: "center",
                                                            m: 16,
                                                            maxWidth: 358,
                                                            pb: 38,
                                                            pt: 35,
                                                            textAlign: "center",
                                                            width: "100%"
                                                        },
                                                        variant: "accentBottom",
                                                        children: (0, r.tZ)("span", {
                                                            sx: {
                                                                position: "relative"
                                                            },
                                                            className: "jsx-c80dbc0b64ccf72d",
                                                            children: l.name
                                                        })
                                                    }, l.path)
                                                }))
                                            }), (0, r.tZ)(b.kC, {
                                                sx: {
                                                    justifyContent: ["center", null, null, null, null, "flex-end"]
                                                },
                                                children: (0, r.BX)(b.rU, {
                                                    href: d.tracks.CAREER_PATH,
                                                    sx: {
                                                        "&:active, &:focus, &:hover": {
                                                            color: "pink.200",
                                                            textDecoration: "none"
                                                        },
                                                        alignItems: "center",
                                                        color: "text",
                                                        display: "flex",
                                                        fontSize: 400,
                                                        mt: 8,
                                                        svg: {
                                                            color: "pink.200"
                                                        },
                                                        transition: "color 0.3s cubic-bezier(0.85, 0, 0.15, 1)"
                                                    },
                                                    children: ["Explore All Career Tracks", " ", (0, r.tZ)(v.Z, {
                                                        sx: {
                                                            ml: 8
                                                        },
                                                        width: "18"
                                                    })]
                                                })
                                            })]
                                        })
                                    }), (0, r.tZ)(b.xu, {
                                        "aria-labelledby": "skills",
                                        as: "nav",
                                        children: (0, r.BX)(b.W2, {
                                            sx: {
                                                pb: 150,
                                                textAlign: ["center", null, null, null, null, "left"]
                                            },
                                            children: [(0, r.tZ)(b.xv, {
                                                as: "h3",
                                                id: "skills",
                                                sx: {
                                                    mb: 8,
                                                    mt: 32
                                                },
                                                variant: "h32",
                                                children: "Master a specific skill"
                                            }), (0, r.tZ)(b.kC, {
                                                sx: {
                                                    flexWrap: "wrap",
                                                    justifyContent: "center",
                                                    mx: -16
                                                },
                                                children: A.oJ.map((function(l) {
                                                    return (0, r.tZ)(b.rU, {
                                                        className: "ie-accentBottom",
                                                        href: l.path,
                                                        sx: {
                                                            "&::after": {
                                                                bg: "purple.200"
                                                            },
                                                            alignItems: "center",
                                                            boxShadow: "0 1px 4px -1px rgba(5, 25, 45, 0.3), 0 0 1px 0 rgba(5, 25, 45, 0.3);",
                                                            color: "text",
                                                            display: "flex",
                                                            fontSize: 600,
                                                            fontWeight: "bold",
                                                            justifyContent: "center",
                                                            m: 16,
                                                            maxWidth: 260,
                                                            pb: 38,
                                                            pt: 35,
                                                            px: 12,
                                                            textAlign: "center",
                                                            width: "100%"
                                                        },
                                                        variant: "accentBottom",
                                                        children: (0, r.tZ)("span", {
                                                            sx: {
                                                                position: "relative"
                                                            },
                                                            className: "jsx-c80dbc0b64ccf72d",
                                                            children: l.name
                                                        })
                                                    }, l.path)
                                                }))
                                            }), (0, r.tZ)(b.kC, {
                                                sx: {
                                                    justifyContent: ["center", null, null, null, null, "flex-end"]
                                                },
                                                children: (0, r.BX)(b.rU, {
                                                    href: d.tracks.SKILL_PATH,
                                                    sx: {
                                                        "&:active, &:focus, &:hover": {
                                                            color: "purple.200",
                                                            textDecoration: "none"
                                                        },
                                                        alignItems: "center",
                                                        color: "text",
                                                        display: "flex",
                                                        fontSize: 400,
                                                        mt: 8,
                                                        svg: {
                                                            color: "purple.200"
                                                        },
                                                        transition: "color 0.3s cubic-bezier(0.85, 0, 0.15, 1)"
                                                    },
                                                    children: ["Explore All Skill Tracks", " ", (0, r.tZ)(v.Z, {
                                                        sx: {
                                                            ml: 8
                                                        },
                                                        width: "18"
                                                    })]
                                                })
                                            })]
                                        })
                                    })]
                                })]
                            }), (0, r.tZ)(b.xu, {
                                sx: {
                                    bg: "navy.200",
                                    pb: 56,
                                    position: "relative"
                                },
                                children: (0, r.BX)(b.W2, {
                                    sx: {
                                        alignItems: [null, null, null, null, null, "center"],
                                        display: [null, null, null, null, null, "flex"],
                                        justifyContent: [null, null, null, null, null, "space-between"],
                                        maxWidth: [550, null, null, null, null, 1172],
                                        position: "relative",
                                        py: [64, null, null, null, null, 120],
                                        zIndex: 10
                                    },
                                    children: [(0, r.BX)(b.xu, {
                                        children: [(0, r.BX)(b.xv, {
                                            as: "h1",
                                            sx: {
                                                alignItems: "center",
                                                color: "blue.200",
                                                display: "flex",
                                                maxWidth: [null, null, 525],
                                                mb: 16
                                            },
                                            variant: "h24",
                                            children: [(0, r.tZ)(Z.Z, {
                                                sx: {
                                                    mr: 10,
                                                    width: 39
                                                }
                                            }), "DataCamp Signal", (0, r.tZ)("sup", {
                                                sx: {
                                                    fontSize: 100,
                                                    ml: 4,
                                                    mt: -8
                                                },
                                                className: "jsx-c80dbc0b64ccf72d",
                                                children: "TM"
                                            })]
                                        }), (0, r.BX)(b.xv, {
                                            as: "p",
                                            sx: {
                                                color: "white",
                                                maxWidth: [null, null, 525]
                                            },
                                            variant: "h50",
                                            children: ["Discover your data skill level", " ", (0, r.tZ)("span", {
                                                sx: {
                                                    color: "blue.200"
                                                },
                                                className: "jsx-c80dbc0b64ccf72d",
                                                children: "for free"
                                            })]
                                        }), (0, r.tZ)(b.xv, {
                                            as: "p",
                                            sx: {
                                                color: "white",
                                                maxWidth: [null, null, 420],
                                                mb: 24,
                                                mt: 16
                                            },
                                            variant: "t18",
                                            children: "Effective learning starts with assessment. Learning a new skill is hard work\u2014Signal makes it easier."
                                        }), (0, r.tZ)(m.default, {
                                            appearance: "primary",
                                            href: d.SIGNAL_PATH,
                                            intent: "success",
                                            type: "link",
                                            children: "Take An Assessment"
                                        }), (0, r.tZ)(m.default, {
                                            appearance: "inverted",
                                            href: d.BUSINESS_DEMO_PATH,
                                            intent: "neutral",
                                            sx: {
                                                mb: [16, null, null, null, null, null, 0],
                                                ml: [0, null, null, null, null, 16],
                                                mt: [16, null, null, null, null, 0]
                                            },
                                            type: "link",
                                            children: "Request a DataCamp For Business Demo"
                                        })]
                                    }), (0, r.tZ)(g(), {
                                        alt: "Screenshot of a an assessment with a score of 100",
                                        height: 271,
                                        src: "/Marketing/Screenshots/screenshot-signal-100.png",
                                        sx: {
                                            aspectRatio: "".concat(1100 / 543)
                                        },
                                        width: 550
                                    })]
                                })
                            }), (0, r.tZ)(w.Z, {}), (0, r.tZ)(X, {}), (0, r.tZ)(s.default, {
                                title: "Don\u2019t just take our word for it."
                            }), (0, r.tZ)(u.Z, {
                                sx: {
                                    "> div > div:last-of-type": {
                                        display: "none"
                                    },
                                    bg: "background"
                                }
                            }), (0, r.tZ)(c.Z, {
                                registeredUsers: n.numberOfUsers
                            })]
                        }), (0, r.tZ)(h.default, {})]
                    })
                }
        }
    },
    function(l) {
        l.O(0, [7388, 44948, 89077, 76724, 22429, 25675, 37046, 39277, 86529, 79547, 75043, 49956, 89853, 21098, 52449, 24004, 13035, 82437, 26303, 66234, 50547, 92888, 40179], (function() {
            return n = 48312, l(l.s = n);
            var n
        }));
        var n = l.O();
        _N_E = n
    }
]);
//# sourceMappingURL=index-ccf1759e041210ef.js.map