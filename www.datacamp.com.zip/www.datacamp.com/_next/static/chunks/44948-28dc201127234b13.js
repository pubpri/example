(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [44948], {
        21217: function(t, a, c) {
            "use strict";
            var n = c(83454);
            c(92222), Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.getSignOutRedirectPath = a.getSignUpRedirectPath = a.getSignInRedirectPath = a.HIRING_PROCESS_URL = a.BILLING_APP_URL = a.HIRE_DATA_PROFESSIONALS_PATH = a.getJobPath = a.JOBS_PATH = a.DIRECTORY_PATH = a.SUPPORT_TECHNOLOGIES_URL = a.SUPPORT_SIGNAL_URL = a.SUPPORT_URL = a.CREATE_PATH = a.AFFILIATES_PATH = a.SEARCH_PATH = a.social = a.community = a.WHITE_PAPER_SIGNAL_URL = a.RESOURCES_PATH = a.RDOCUMENTATION_URL = a.OPEN_SOURCE_PATH = a.DISCOVER_WEBINARS_PATH = a.TEACH_PATH = a.COURSE_EDITOR_PATH = a.getFooterMobileUrl = a.BUSINESS_PRICING_PATH = a.PROMO_PATH = a.GROUP_UPGRADE_PATH = a.DONATES_PATH = a.BUY_PROFESSIONAL_DISCOUNT_PATH = a.BUY_PROFESSIONAL_PATH = a.PRICING_PATH = a.EDUCATION_POST_PATH = a.EDUCATION_PATH = a.BUSINESS_DEMO_PATH = a.BUSINESS_PATH = a.SECURITY_PATH = a.ACCESSIBILITY_PATH = a.TERMS_OF_USE_PATH = a.PRIVACY_POLICY_PATH = a.DO_NOT_PATH = a.COOKIE_NOTICE_PATH = a.productEducation = a.certification = a.auth = a.WORKSPACE_DOCUMENTATION = a.workspaceMarketing = a.ROADMAP_PATH = a.PRACTICE_URL = a.INTERACTIVE_LEARNING_PATH = a.INSTRUCTORS_PATH = a.tracks = a.SIGNAL_PATH = a.dataCourses = a.learn = a.projectTopicPath = a.getProjectContinuePathForId = a.PROJECTS_PATH = a.COURSES_ALL_PATH = a.COMPETITIONS_PATH = a.COURSES_PATH = a.COURSE_PATH = a.SIGN_OUT_PATH = a.SIGN_IN_PATH = a.SIGN_UP_PATH = a.MOBILE_PATH = a.STORIES_PATH = a.PRESS_PATH = a.LEADERSHIP_PATH = a.CONTACT_URL = a.CAREERS_PATH = a.ABOUT_PATH = a.BASE_PATH = void 0;
            var o = c(52033),
                r = n.env.NEXT_PUBLIC_GROWTH_SHARED_BASE_URL || n.env.GROWTH_SHARED_BASE_URL || "",
                e = "".concat(r, "/");
            a.BASE_PATH = e;
            var s = "".concat(r, "/about");
            a.ABOUT_PATH = s;
            var A = "".concat(r, "/careers");
            a.CAREERS_PATH = A;
            a.CONTACT_URL = "https://support.datacamp.com/hc/en-us/articles/360021185634";
            var T = "".concat(r, "/about/leadership");
            a.LEADERSHIP_PATH = T;
            var _ = "".concat(r, "/press");
            a.PRESS_PATH = _;
            var i = "".concat(r, "/stories");
            a.STORIES_PATH = i;
            var P = "".concat(r, "/mobile");
            a.MOBILE_PATH = P;
            var u = "".concat(r, "/users/sign_up");
            a.SIGN_UP_PATH = u;
            var E = "".concat(r, "/users/sign_in");
            a.SIGN_IN_PATH = E;
            var S = "".concat(r, "/users/sign_out");
            a.SIGN_OUT_PATH = S;
            var R = "".concat(r, "/courses");
            a.COURSE_PATH = R;
            var I = "".concat(r, "/courses-all");
            a.COURSES_PATH = I;
            var H = "".concat(r, "/data-science-competitions");
            a.COMPETITIONS_PATH = H;
            var O = "".concat(r, "/search?tab=courses");
            a.COURSES_ALL_PATH = O;
            var p = "".concat(r, "/projects");
            a.PROJECTS_PATH = p;
            a.getProjectContinuePathForId = function(t) {
                return "".concat(r, "/projects/").concat(t, "/continue")
            };
            a.projectTopicPath = function(t) {
                return "".concat(r, "/projects/topic:").concat(t)
            };
            var d = {
                POWER_BI_PATH: "".concat(r, "/learn/power-bi"),
                PYTHON_PATH: "".concat(r, "/learn/python"),
                R_PATH: "".concat(r, "/learn/r"),
                SQL_PATH: "".concat(r, "/learn/sql"),
                TABLEAU_PATH: "".concat(r, "/learn/tableau")
            };
            a.learn = d;
            var N = {
                DATA_ANALYSIS_PATH: "".concat(r, "/data-courses/data-analysis-courses"),
                DATA_ENGINEERING_PATH: "".concat(r, "/data-courses/data-engineering-courses"),
                DATA_VISUALIZATION_PATH: "".concat(r, "/data-courses/data-visualization-courses"),
                MACHINE_LEARNING_PATH: "".concat(r, "/data-courses/machine-learning-courses"),
                POWER_BI_PATH: "".concat(r, "/data-courses/power-bi"),
                PYTHON_PATH: "".concat(r, "/data-courses/python"),
                R_PATH: "".concat(r, "/data-courses/r-courses"),
                SPREADSHEET_PATH: "".concat(r, "/data-courses/spreadsheet-courses"),
                SQL_PATH: "".concat(r, "/data-courses/sql"),
                TABLEAU_PATH: "".concat(r, "/data-courses/tableau")
            };
            a.dataCourses = N;
            var C = "".concat(r, "/signal");
            a.SIGNAL_PATH = C;
            var l = {
                CAREER_PATH: "".concat(r, "/tracks/career"),
                SKILL_PATH: "".concat(r, "/tracks/skill")
            };
            a.tracks = l;
            var U = "".concat(r, "/instructors");
            a.INSTRUCTORS_PATH = U;
            var v = "".concat(r, "/interactive-learning");
            a.INTERACTIVE_LEARNING_PATH = v;
            var m = "".concat(r, "https://app.datacamp.com/learn/practice");
            a.PRACTICE_URL = m;
            var L = "".concat(r, "/learn/data-science-roadmap");
            a.ROADMAP_PATH = L;
            var h = "".concat(r, "/workspace"),
                g = {
                    INTEGRATIONS_PATH: "".concat(h, "/integrations"),
                    LANDING_PATH: h,
                    TEMPLATES_PATH: "".concat(h, "/templates")
                };
            a.workspaceMarketing = g;
            a.WORKSPACE_DOCUMENTATION = "https://workspace-docs.datacamp.com";
            var f = {
                FACEBOOK_PATH: "".concat(r, "/users/auth/facebook"),
                GOOGLE_PATH: "".concat(r, "/users/auth/google_oauth2"),
                LINKEDIN_PATH: "".concat(r, "/users/auth/linkedin"),
                USERS_PATH: "".concat(r, "/users")
            };
            a.auth = f;
            var b = {
                CERTIFICATION_APP_PATH: "https://app.datacamp.com/certification",
                CERTIFICATION_DA_LANDING_PATH: "".concat(r, "/certification/data-analyst"),
                CERTIFICATION_DS_LANDING_PATH: "".concat(r, "/certification/data-scientist"),
                CERTIFICATION_FOR_BUSINESS_PATH: "".concat(r, "/certification-for-business"),
                CERTIFICATION_LANDING_PATH: "".concat(r, "/certification"),
                SUMMER_CHALLENGE_PATH: "".concat(r, "/summerchallenge")
            };
            a.certification = b;
            var w = {
                CUSTOM_LEARNING_PATH: "".concat(r, "/groups/business/custom-learning-solutions"),
                CUSTOM_TRACKS: "".concat(r, "/custom-tracks"),
                CUSTOMER_SUCCESS_PATH: "".concat(r, "/groups/business/customer-success"),
                INTEGRATION_PATH: "".concat(r, "/groups/business/integration"),
                INTERACTIVE_LEARNING_PATH: "".concat(r, "/interactive-learning"),
                REPORTING_PATH: "".concat(r, "/groups/business/reporting")
            };
            a.productEducation = w;
            var D = "".concat(r, "/cookie-notice");
            a.COOKIE_NOTICE_PATH = D;
            var G = "".concat(r, "/do-not-sell-my-personal-information");
            a.DO_NOT_PATH = G;
            var B = "".concat(r, "/privacy-policy");
            a.PRIVACY_POLICY_PATH = B;
            var M = "".concat(r, "/terms-of-use");
            a.TERMS_OF_USE_PATH = M;
            var y = "".concat(r, "/accessibility");
            a.ACCESSIBILITY_PATH = y;
            var k = "".concat(r, "/security");
            a.SECURITY_PATH = k;
            var F = "".concat(r, "/groups/business");
            a.BUSINESS_PATH = F;
            var j = "".concat(r, "/business/demo");
            a.BUSINESS_DEMO_PATH = j;
            var Y = "".concat(r, "/groups/classrooms");
            a.EDUCATION_PATH = Y;
            var x = "".concat(r, "/groups/academic_applications");
            a.EDUCATION_POST_PATH = x;
            var W = "".concat(r, "/pricing");
            a.PRICING_PATH = W;
            var K = "".concat(r, "/groups/subscribe");
            a.BUY_PROFESSIONAL_PATH = K;
            var V = "".concat(r, "/groups/subscribe/quantity");
            a.BUY_PROFESSIONAL_DISCOUNT_PATH = V;
            var J = "".concat(r, "/donates");
            a.DONATES_PATH = J;
            var q = "".concat(r, "/groups/upgrade");
            a.GROUP_UPGRADE_PATH = q;
            var Q = "".concat(r, "/promo");
            a.PROMO_PATH = Q;
            var z = "".concat(r, "/compare-business-plans");
            a.BUSINESS_PRICING_PATH = z;
            a.getFooterMobileUrl = function(t) {
                return "https://datacamp.app.link/LVjaAoDt99?src_url=".concat(encodeURIComponent(t))
            };
            var X = "".concat(r, "/create");
            a.COURSE_EDITOR_PATH = X;
            var Z = "".concat(r, "/teach/home/get_started");
            a.TEACH_PATH = Z;
            var $ = "".concat(r, "/webinars");
            a.DISCOVER_WEBINARS_PATH = $;
            var tt = "".concat(r, "/open-source");
            a.OPEN_SOURCE_PATH = tt;
            a.RDOCUMENTATION_URL = "https://www.rdocumentation.org";
            var at = "".concat(r, "/resources/");
            a.RESOURCES_PATH = at;
            a.WHITE_PAPER_SIGNAL_URL = "https://www.datacamp.com/resources/whitepapers/datacamp-signal";
            var ct = {
                BLOG_PATH: "".concat(r, "/blog"),
                CHEATSHEETS_PATH: "".concat(r, "/cheat-sheet"),
                HOME_PATH: "".concat(r, "/community"),
                PODCASTS_PATH: "".concat(r, "/podcast"),
                TUTORIALS_PATH: "".concat(r, "/tutorial")
            };
            a.community = ct;
            a.social = {
                FACEBOOK_URL: "https://www.facebook.com/datacampinc/",
                INSTAGRAM_URL: "https://www.instagram.com/datacamp/",
                LINKEDIN_URL: "https://www.linkedin.com/school/datacampinc/",
                TWITTER_URL: "https://twitter.com/datacamp",
                YOUTUBE_URL: "https://www.youtube.com/channel/UC79Gv3mYp6zKiSwYemEik9A"
            };
            var nt = "".concat(r, "/search");
            a.SEARCH_PATH = nt;
            var ot = "".concat(r, "/affiliates");
            a.AFFILIATES_PATH = ot;
            var rt = "".concat(r, "/create");
            a.CREATE_PATH = rt;
            a.SUPPORT_URL = "https://support.datacamp.com/hc/en-us";
            a.SUPPORT_SIGNAL_URL = "https://support.datacamp.com/hc/en-us/articles/360023859774-What-is-DataCamp-Signal";
            a.SUPPORT_TECHNOLOGIES_URL = "https://support.datacamp.com/hc/en-us/articles/360046896474-Data-Science-Technologies-An-Overview";
            var et = "".concat(r, "/directory");
            a.DIRECTORY_PATH = et;
            var st = "".concat(r, "/jobs");
            a.JOBS_PATH = st;
            a.getJobPath = function(t) {
                return "".concat(st, "?department=").concat(t)
            };
            var At = "".concat(r, "/hire-data-professionals");
            a.HIRE_DATA_PROFESSIONALS_PATH = At;
            a.BILLING_APP_URL = "https://billing.datacamp.com";
            a.HIRING_PROCESS_URL = "https://cdn.datacamp.com/datacamp-recruitment-process.pdf";
            a.getSignInRedirectPath = function(t) {
                return (0, o.addRedirectParam)(E, t)
            };
            a.getSignUpRedirectPath = function(t) {
                return (0, o.addRedirectParam)(u, t)
            };
            a.getSignOutRedirectPath = function(t) {
                return (0, o.addRedirectParam)(S, t)
            }
        },
        52033: function(t, a, c) {
            "use strict";
            c(92222), c(82772), c(69600), c(24603), c(74916), c(39714), c(4723), c(15306), c(64765), c(23157), Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.prefixWithOrigin = a.optionallyAddRedirectParam = a.addRedirectParam = a.updateQueryStringParam = void 0;
            a.updateQueryStringParam = function(t, a) {
                var c = [window.location.protocol, "//", window.location.host, window.location.pathname].join(""),
                    n = document.location.search,
                    o = "".concat(t, "=").concat(a),
                    r = "?".concat(o);
                if (n) {
                    var e = new RegExp("([?&])".concat(t, "[^&]*"));
                    r = null !== n.match(e) ? n.replace(e, "$1".concat(o)) : "".concat(n, "&").concat(o)
                }
                window.history.replaceState({}, "", c + r)
            };
            var n = function(t, a) {
                if (-1 === ["/"].indexOf(a)) {
                    var c = a;
                    return "/" === a[0] || a.startsWith("https") || (c = "/".concat(a)), "".concat(t, "?redirect=").concat(encodeURIComponent(c))
                }
                return t
            };
            a.addRedirectParam = n;
            a.optionallyAddRedirectParam = function(t, a) {
                return a ? n(t, a) : t
            };
            a.prefixWithOrigin = function(t) {
                return "/" === t[0] ? "https://www.datacamp.com".concat(t) : "https://www.datacamp.com/".concat(t)
            }
        },
        21574: function(t, a, c) {
            "use strict";
            var n = c(19781),
                o = c(1702),
                r = c(46916),
                e = c(47293),
                s = c(81956),
                A = c(25181),
                T = c(55296),
                _ = c(47908),
                i = c(68361),
                P = Object.assign,
                u = Object.defineProperty,
                E = o([].concat);
            t.exports = !P || e((function() {
                if (n && 1 !== P({
                        b: 1
                    }, P(u({}, "a", {
                        enumerable: !0,
                        get: function() {
                            u(this, "b", {
                                value: 3,
                                enumerable: !1
                            })
                        }
                    }), {
                        b: 2
                    })).b) return !0;
                var t = {},
                    a = {},
                    c = Symbol(),
                    o = "abcdefghijklmnopqrst";
                return t[c] = 7, o.split("").forEach((function(t) {
                    a[t] = t
                })), 7 != P({}, t)[c] || s(P({}, a)).join("") != o
            })) ? function(t, a) {
                for (var c = _(t), o = arguments.length, e = 1, P = A.f, u = T.f; o > e;)
                    for (var S, R = i(arguments[e++]), I = P ? E(s(R), P(R)) : s(R), H = I.length, O = 0; H > O;) S = I[O++], n && !r(u, R, S) || (c[S] = R[S]);
                return c
            } : P
        },
        81150: function(t) {
            t.exports = Object.is || function(t, a) {
                return t === a ? 0 !== t || 1 / t === 1 / a : t != t && a != a
            }
        },
        69600: function(t, a, c) {
            "use strict";
            var n = c(82109),
                o = c(1702),
                r = c(68361),
                e = c(45656),
                s = c(9341),
                A = o([].join),
                T = r != Object,
                _ = s("join", ",");
            n({
                target: "Array",
                proto: !0,
                forced: T || !_
            }, {
                join: function(t) {
                    return A(e(this), void 0 === t ? "," : t)
                }
            })
        },
        19601: function(t, a, c) {
            var n = c(82109),
                o = c(21574);
            n({
                target: "Object",
                stat: !0,
                arity: 2,
                forced: Object.assign !== o
            }, {
                assign: o
            })
        },
        4723: function(t, a, c) {
            "use strict";
            var n = c(46916),
                o = c(27007),
                r = c(19670),
                e = c(17466),
                s = c(41340),
                A = c(84488),
                T = c(58173),
                _ = c(31530),
                i = c(97651);
            o("match", (function(t, a, c) {
                return [function(a) {
                    var c = A(this),
                        o = void 0 == a ? void 0 : T(a, t);
                    return o ? n(o, a, c) : new RegExp(a)[t](s(c))
                }, function(t) {
                    var n = r(this),
                        o = s(t),
                        A = c(a, n, o);
                    if (A.done) return A.value;
                    if (!n.global) return i(n, o);
                    var T = n.unicode;
                    n.lastIndex = 0;
                    for (var P, u = [], E = 0; null !== (P = i(n, o));) {
                        var S = s(P[0]);
                        u[E] = S, "" === S && (n.lastIndex = _(o, e(n.lastIndex), T)), E++
                    }
                    return 0 === E ? null : u
                }]
            }))
        },
        64765: function(t, a, c) {
            "use strict";
            var n = c(46916),
                o = c(27007),
                r = c(19670),
                e = c(84488),
                s = c(81150),
                A = c(41340),
                T = c(58173),
                _ = c(97651);
            o("search", (function(t, a, c) {
                return [function(a) {
                    var c = e(this),
                        o = void 0 == a ? void 0 : T(a, t);
                    return o ? n(o, a, c) : new RegExp(a)[t](A(c))
                }, function(t) {
                    var n = r(this),
                        o = A(t),
                        e = c(a, n, o);
                    if (e.done) return e.value;
                    var T = n.lastIndex;
                    s(T, 0) || (n.lastIndex = 0);
                    var i = _(n, o);
                    return s(n.lastIndex, T) || (n.lastIndex = T), null === i ? -1 : i.index
                }]
            }))
        }
    }
]);
//# sourceMappingURL=44948-28dc201127234b13.js.map