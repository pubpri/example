"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7388], {
        7388: function(e, r, t) {
            t.d(r, {
                bZ: function() {
                    return lr
                },
                bp: function() {
                    return ur
                },
                oM: function() {
                    return fr
                },
                qE: function() {
                    return tr
                },
                Ct: function() {
                    return ar
                },
                xu: function() {
                    return ge
                },
                zx: function() {
                    return xe
                },
                Zb: function() {
                    return ze
                },
                XZ: function() {
                    return Ue
                },
                x8: function() {
                    return nr
                },
                W2: function() {
                    return mr
                },
                iz: function() {
                    return sr
                },
                yi: function() {
                    return Qe
                },
                cx: function() {
                    return pr
                },
                gN: function() {
                    return Ze
                },
                kC: function() {
                    return he
                },
                rj: function() {
                    return we
                },
                X6: function() {
                    return _e
                },
                hU: function() {
                    return or
                },
                Ee: function() {
                    return Ee
                },
                II: function() {
                    return Le
                },
                __: function() {
                    return Ce
                },
                rU: function() {
                    return Re
                },
                j2: function() {
                    return yr
                },
                v0: function() {
                    return hr
                },
                OL: function() {
                    return gr
                },
                nv: function() {
                    return ke
                },
                Ex: function() {
                    return Je
                },
                Y8: function() {
                    return Ke
                },
                Ph: function() {
                    return Oe
                },
                iR: function() {
                    return $e
                },
                $j: function() {
                    return rr
                },
                rs: function() {
                    return Ve
                },
                xv: function() {
                    return Se
                },
                gx: function() {
                    return Pe
                }
            });
            var a = t(70477),
                o = t(33431),
                i = t(67866);
            var n = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|inert|itemProp|itemScope|itemType|itemID|itemRef|on|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,
                l = function(e) {
                    var r = {};
                    return function(t) {
                        return void 0 === r[t] && (r[t] = e(t)), r[t]
                    }
                }((function(e) {
                    return n.test(e) || 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && e.charCodeAt(2) < 91
                })),
                s = t(96086),
                d = t.n(s),
                c = function(e, r) {
                    var t = d()({}, e, r);
                    for (var a in e) {
                        var o;
                        e[a] && "object" === typeof r[a] && d()(t, ((o = {})[a] = d()(e[a], r[a]), o))
                    }
                    return t
                },
                p = {
                    breakpoints: [40, 52, 64].map((function(e) {
                        return e + "em"
                    }))
                },
                f = function(e) {
                    return "@media screen and (min-width: " + e + ")"
                },
                u = function(e, r) {
                    return m(r, e, e)
                },
                m = function(e, r, t, a, o) {
                    for (r = r && r.split ? r.split(".") : [r], a = 0; a < r.length; a++) e = e ? e[r[a]] : o;
                    return e === o ? t : e
                },
                g = function e(r) {
                    var t = {},
                        a = function(e) {
                            var a = {},
                                o = !1,
                                i = e.theme && e.theme.disableStyledSystemCache;
                            for (var n in e)
                                if (r[n]) {
                                    var l = r[n],
                                        s = e[n],
                                        u = m(e.theme, l.scale, l.defaults);
                                    if ("object" !== typeof s) d()(a, l(s, u, e));
                                    else {
                                        if (t.breakpoints = !i && t.breakpoints || m(e.theme, "breakpoints", p.breakpoints), Array.isArray(s)) {
                                            t.media = !i && t.media || [null].concat(t.breakpoints.map(f)), a = c(a, h(t.media, l, u, s, e));
                                            continue
                                        }
                                        null !== s && (a = c(a, b(t.breakpoints, l, u, s, e)), o = !0)
                                    }
                                }
                            return o && (a = function(e) {
                                var r = {};
                                return Object.keys(e).sort((function(e, r) {
                                    return e.localeCompare(r, void 0, {
                                        numeric: !0,
                                        sensitivity: "base"
                                    })
                                })).forEach((function(t) {
                                    r[t] = e[t]
                                })), r
                            }(a)), a
                        };
                    a.config = r, a.propNames = Object.keys(r), a.cache = t;
                    var o = Object.keys(r).filter((function(e) {
                        return "config" !== e
                    }));
                    return o.length > 1 && o.forEach((function(t) {
                        var o;
                        a[t] = e(((o = {})[t] = r[t], o))
                    })), a
                },
                h = function(e, r, t, a, o) {
                    var i = {};
                    return a.slice(0, e.length).forEach((function(a, n) {
                        var l, s = e[n],
                            c = r(a, t, o);
                        s ? d()(i, ((l = {})[s] = d()({}, i[s], c), l)) : d()(i, c)
                    })), i
                },
                b = function(e, r, t, a, o) {
                    var i = {};
                    for (var n in a) {
                        var l = e[n],
                            s = r(a[n], t, o);
                        if (l) {
                            var c, p = f(l);
                            d()(i, ((c = {})[p] = d()({}, i[p], s), c))
                        } else d()(i, s)
                    }
                    return i
                },
                y = function(e) {
                    var r = e.properties,
                        t = e.property,
                        a = e.scale,
                        o = e.transform,
                        i = void 0 === o ? u : o,
                        n = e.defaultScale;
                    r = r || [t];
                    var l = function(e, t, a) {
                        var o = {},
                            n = i(e, t, a);
                        if (null !== n) return r.forEach((function(e) {
                            o[e] = n
                        })), o
                    };
                    return l.scale = a, l.defaults = n, l
                },
                v = function(e) {
                    void 0 === e && (e = {});
                    var r = {};
                    return Object.keys(e).forEach((function(t) {
                        var a = e[t];
                        r[t] = !0 !== a ? "function" !== typeof a ? y(a) : a : y({
                            property: t,
                            scale: t
                        })
                    })), g(r)
                },
                w = function() {
                    for (var e = {}, r = arguments.length, t = new Array(r), a = 0; a < r; a++) t[a] = arguments[a];
                    t.forEach((function(r) {
                        r && r.config && d()(e, r.config)
                    }));
                    var o = g(e);
                    return o
                },
                x = v({
                    width: {
                        property: "width",
                        scale: "sizes",
                        transform: function(e, r) {
                            return m(r, e, ! function(e) {
                                return "number" === typeof e && !isNaN(e)
                            }(e) || e > 1 ? e : 100 * e + "%")
                        }
                    },
                    height: {
                        property: "height",
                        scale: "sizes"
                    },
                    minWidth: {
                        property: "minWidth",
                        scale: "sizes"
                    },
                    minHeight: {
                        property: "minHeight",
                        scale: "sizes"
                    },
                    maxWidth: {
                        property: "maxWidth",
                        scale: "sizes"
                    },
                    maxHeight: {
                        property: "maxHeight",
                        scale: "sizes"
                    },
                    size: {
                        properties: ["width", "height"],
                        scale: "sizes"
                    },
                    overflow: !0,
                    overflowX: !0,
                    overflowY: !0,
                    display: !0,
                    verticalAlign: !0
                }),
                R = x,
                k = {
                    color: {
                        property: "color",
                        scale: "colors"
                    },
                    backgroundColor: {
                        property: "backgroundColor",
                        scale: "colors"
                    },
                    opacity: !0
                };
            k.bg = k.backgroundColor;
            var S = v(k),
                _ = S,
                E = v({
                    fontFamily: {
                        property: "fontFamily",
                        scale: "fonts"
                    },
                    fontSize: {
                        property: "fontSize",
                        scale: "fontSizes",
                        defaultScale: [12, 14, 16, 20, 24, 32, 48, 64, 72]
                    },
                    fontWeight: {
                        property: "fontWeight",
                        scale: "fontWeights"
                    },
                    lineHeight: {
                        property: "lineHeight",
                        scale: "lineHeights"
                    },
                    letterSpacing: {
                        property: "letterSpacing",
                        scale: "letterSpacings"
                    },
                    textAlign: !0,
                    fontStyle: !0
                }),
                z = E,
                C = v({
                    alignItems: !0,
                    alignContent: !0,
                    justifyItems: !0,
                    justifyContent: !0,
                    flexWrap: !0,
                    flexDirection: !0,
                    flex: !0,
                    flexGrow: !0,
                    flexShrink: !0,
                    flexBasis: !0,
                    justifySelf: !0,
                    alignSelf: !0,
                    order: !0
                }),
                T = C,
                W = {
                    space: [0, 4, 8, 16, 32, 64, 128, 256, 512]
                },
                L = v({
                    gridGap: {
                        property: "gridGap",
                        scale: "space",
                        defaultScale: W.space
                    },
                    gridColumnGap: {
                        property: "gridColumnGap",
                        scale: "space",
                        defaultScale: W.space
                    },
                    gridRowGap: {
                        property: "gridRowGap",
                        scale: "space",
                        defaultScale: W.space
                    },
                    gridColumn: !0,
                    gridRow: !0,
                    gridAutoFlow: !0,
                    gridAutoColumns: !0,
                    gridAutoRows: !0,
                    gridTemplateColumns: !0,
                    gridTemplateRows: !0,
                    gridTemplateAreas: !0,
                    gridArea: !0
                }),
                B = L,
                A = {
                    border: {
                        property: "border",
                        scale: "borders"
                    },
                    borderWidth: {
                        property: "borderWidth",
                        scale: "borderWidths"
                    },
                    borderStyle: {
                        property: "borderStyle",
                        scale: "borderStyles"
                    },
                    borderColor: {
                        property: "borderColor",
                        scale: "colors"
                    },
                    borderRadius: {
                        property: "borderRadius",
                        scale: "radii"
                    },
                    borderTop: {
                        property: "borderTop",
                        scale: "borders"
                    },
                    borderTopLeftRadius: {
                        property: "borderTopLeftRadius",
                        scale: "radii"
                    },
                    borderTopRightRadius: {
                        property: "borderTopRightRadius",
                        scale: "radii"
                    },
                    borderRight: {
                        property: "borderRight",
                        scale: "borders"
                    },
                    borderBottom: {
                        property: "borderBottom",
                        scale: "borders"
                    },
                    borderBottomLeftRadius: {
                        property: "borderBottomLeftRadius",
                        scale: "radii"
                    },
                    borderBottomRightRadius: {
                        property: "borderBottomRightRadius",
                        scale: "radii"
                    },
                    borderLeft: {
                        property: "borderLeft",
                        scale: "borders"
                    },
                    borderX: {
                        properties: ["borderLeft", "borderRight"],
                        scale: "borders"
                    },
                    borderY: {
                        properties: ["borderTop", "borderBottom"],
                        scale: "borders"
                    },
                    borderTopWidth: {
                        property: "borderTopWidth",
                        scale: "borderWidths"
                    },
                    borderTopColor: {
                        property: "borderTopColor",
                        scale: "colors"
                    },
                    borderTopStyle: {
                        property: "borderTopStyle",
                        scale: "borderStyles"
                    }
                };
            A.borderTopLeftRadius = {
                property: "borderTopLeftRadius",
                scale: "radii"
            }, A.borderTopRightRadius = {
                property: "borderTopRightRadius",
                scale: "radii"
            }, A.borderBottomWidth = {
                property: "borderBottomWidth",
                scale: "borderWidths"
            }, A.borderBottomColor = {
                property: "borderBottomColor",
                scale: "colors"
            }, A.borderBottomStyle = {
                property: "borderBottomStyle",
                scale: "borderStyles"
            }, A.borderBottomLeftRadius = {
                property: "borderBottomLeftRadius",
                scale: "radii"
            }, A.borderBottomRightRadius = {
                property: "borderBottomRightRadius",
                scale: "radii"
            }, A.borderLeftWidth = {
                property: "borderLeftWidth",
                scale: "borderWidths"
            }, A.borderLeftColor = {
                property: "borderLeftColor",
                scale: "colors"
            }, A.borderLeftStyle = {
                property: "borderLeftStyle",
                scale: "borderStyles"
            }, A.borderRightWidth = {
                property: "borderRightWidth",
                scale: "borderWidths"
            }, A.borderRightColor = {
                property: "borderRightColor",
                scale: "colors"
            }, A.borderRightStyle = {
                property: "borderRightStyle",
                scale: "borderStyles"
            };
            var H = v(A),
                I = H,
                j = {
                    background: !0,
                    backgroundImage: !0,
                    backgroundSize: !0,
                    backgroundPosition: !0,
                    backgroundRepeat: !0
                };
            j.bgImage = j.backgroundImage, j.bgSize = j.backgroundSize, j.bgPosition = j.backgroundPosition, j.bgRepeat = j.backgroundRepeat;
            var M = v(j),
                O = M,
                P = {
                    space: [0, 4, 8, 16, 32, 64, 128, 256, 512]
                },
                F = v({
                    position: !0,
                    zIndex: {
                        property: "zIndex",
                        scale: "zIndices"
                    },
                    top: {
                        property: "top",
                        scale: "space",
                        defaultScale: P.space
                    },
                    right: {
                        property: "right",
                        scale: "space",
                        defaultScale: P.space
                    },
                    bottom: {
                        property: "bottom",
                        scale: "space",
                        defaultScale: P.space
                    },
                    left: {
                        property: "left",
                        scale: "space",
                        defaultScale: P.space
                    }
                }),
                N = F,
                X = {
                    space: [0, 4, 8, 16, 32, 64, 128, 256, 512]
                },
                K = function(e) {
                    return "number" === typeof e && !isNaN(e)
                },
                G = function(e, r) {
                    if (!K(e)) return m(r, e, e);
                    var t = e < 0,
                        a = Math.abs(e),
                        o = m(r, a, a);
                    return K(o) ? o * (t ? -1 : 1) : t ? "-" + o : o
                },
                Y = {};
            Y.margin = {
                margin: {
                    property: "margin",
                    scale: "space",
                    transform: G,
                    defaultScale: X.space
                },
                marginTop: {
                    property: "marginTop",
                    scale: "space",
                    transform: G,
                    defaultScale: X.space
                },
                marginRight: {
                    property: "marginRight",
                    scale: "space",
                    transform: G,
                    defaultScale: X.space
                },
                marginBottom: {
                    property: "marginBottom",
                    scale: "space",
                    transform: G,
                    defaultScale: X.space
                },
                marginLeft: {
                    property: "marginLeft",
                    scale: "space",
                    transform: G,
                    defaultScale: X.space
                },
                marginX: {
                    properties: ["marginLeft", "marginRight"],
                    scale: "space",
                    transform: G,
                    defaultScale: X.space
                },
                marginY: {
                    properties: ["marginTop", "marginBottom"],
                    scale: "space",
                    transform: G,
                    defaultScale: X.space
                }
            }, Y.margin.m = Y.margin.margin, Y.margin.mt = Y.margin.marginTop, Y.margin.mr = Y.margin.marginRight, Y.margin.mb = Y.margin.marginBottom, Y.margin.ml = Y.margin.marginLeft, Y.margin.mx = Y.margin.marginX, Y.margin.my = Y.margin.marginY, Y.padding = {
                padding: {
                    property: "padding",
                    scale: "space",
                    defaultScale: X.space
                },
                paddingTop: {
                    property: "paddingTop",
                    scale: "space",
                    defaultScale: X.space
                },
                paddingRight: {
                    property: "paddingRight",
                    scale: "space",
                    defaultScale: X.space
                },
                paddingBottom: {
                    property: "paddingBottom",
                    scale: "space",
                    defaultScale: X.space
                },
                paddingLeft: {
                    property: "paddingLeft",
                    scale: "space",
                    defaultScale: X.space
                },
                paddingX: {
                    properties: ["paddingLeft", "paddingRight"],
                    scale: "space",
                    defaultScale: X.space
                },
                paddingY: {
                    properties: ["paddingTop", "paddingBottom"],
                    scale: "space",
                    defaultScale: X.space
                }
            }, Y.padding.p = Y.padding.padding, Y.padding.pt = Y.padding.paddingTop, Y.padding.pr = Y.padding.paddingRight, Y.padding.pb = Y.padding.paddingBottom, Y.padding.pl = Y.padding.paddingLeft, Y.padding.px = Y.padding.paddingX, Y.padding.py = Y.padding.paddingY;
            var D = w(v(Y.margin), v(Y.padding)),
                U = D,
                V = v({
                    boxShadow: {
                        property: "boxShadow",
                        scale: "shadows"
                    },
                    textShadow: {
                        property: "textShadow",
                        scale: "shadows"
                    }
                });

            function q() {
                return q = Object.assign || function(e) {
                    for (var r = 1; r < arguments.length; r++) {
                        var t = arguments[r];
                        for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }, q.apply(this, arguments)
            }
            var $ = function(e, r, t, a, o) {
                    for (r = r && r.split ? r.split(".") : [r], a = 0; a < r.length; a++) e = e ? e[r[a]] : o;
                    return e === o ? t : e
                },
                Z = [40, 52, 64].map((function(e) {
                    return e + "em"
                })),
                J = {
                    space: [0, 4, 8, 16, 32, 64, 128, 256, 512],
                    fontSizes: [12, 14, 16, 20, 24, 32, 48, 64, 72]
                },
                Q = {
                    bg: "backgroundColor",
                    m: "margin",
                    mt: "marginTop",
                    mr: "marginRight",
                    mb: "marginBottom",
                    ml: "marginLeft",
                    mx: "marginX",
                    my: "marginY",
                    p: "padding",
                    pt: "paddingTop",
                    pr: "paddingRight",
                    pb: "paddingBottom",
                    pl: "paddingLeft",
                    px: "paddingX",
                    py: "paddingY"
                },
                ee = {
                    marginX: ["marginLeft", "marginRight"],
                    marginY: ["marginTop", "marginBottom"],
                    paddingX: ["paddingLeft", "paddingRight"],
                    paddingY: ["paddingTop", "paddingBottom"],
                    size: ["width", "height"]
                },
                re = {
                    color: "colors",
                    backgroundColor: "colors",
                    borderColor: "colors",
                    margin: "space",
                    marginTop: "space",
                    marginRight: "space",
                    marginBottom: "space",
                    marginLeft: "space",
                    marginX: "space",
                    marginY: "space",
                    padding: "space",
                    paddingTop: "space",
                    paddingRight: "space",
                    paddingBottom: "space",
                    paddingLeft: "space",
                    paddingX: "space",
                    paddingY: "space",
                    top: "space",
                    right: "space",
                    bottom: "space",
                    left: "space",
                    gridGap: "space",
                    gridColumnGap: "space",
                    gridRowGap: "space",
                    gap: "space",
                    columnGap: "space",
                    rowGap: "space",
                    fontFamily: "fonts",
                    fontSize: "fontSizes",
                    fontWeight: "fontWeights",
                    lineHeight: "lineHeights",
                    letterSpacing: "letterSpacings",
                    border: "borders",
                    borderTop: "borders",
                    borderRight: "borders",
                    borderBottom: "borders",
                    borderLeft: "borders",
                    borderWidth: "borderWidths",
                    borderStyle: "borderStyles",
                    borderRadius: "radii",
                    borderTopRightRadius: "radii",
                    borderTopLeftRadius: "radii",
                    borderBottomRightRadius: "radii",
                    borderBottomLeftRadius: "radii",
                    borderTopWidth: "borderWidths",
                    borderTopColor: "colors",
                    borderTopStyle: "borderStyles",
                    borderBottomWidth: "borderWidths",
                    borderBottomColor: "colors",
                    borderBottomStyle: "borderStyles",
                    borderLeftWidth: "borderWidths",
                    borderLeftColor: "colors",
                    borderLeftStyle: "borderStyles",
                    borderRightWidth: "borderWidths",
                    borderRightColor: "colors",
                    borderRightStyle: "borderStyles",
                    outlineColor: "colors",
                    boxShadow: "shadows",
                    textShadow: "shadows",
                    zIndex: "zIndices",
                    width: "sizes",
                    minWidth: "sizes",
                    maxWidth: "sizes",
                    height: "sizes",
                    minHeight: "sizes",
                    maxHeight: "sizes",
                    flexBasis: "sizes",
                    size: "sizes",
                    fill: "colors",
                    stroke: "colors"
                },
                te = function(e, r) {
                    if ("number" !== typeof r || r >= 0) return $(e, r, r);
                    var t = Math.abs(r),
                        a = $(e, t, t);
                    return "string" === typeof a ? "-" + a : -1 * a
                },
                ae = ["margin", "marginTop", "marginRight", "marginBottom", "marginLeft", "marginX", "marginY", "top", "bottom", "left", "right"].reduce((function(e, r) {
                    var t;
                    return q({}, e, ((t = {})[r] = te, t))
                }), {}),
                oe = function e(r) {
                    return function(t) {
                        void 0 === t && (t = {});
                        var a = q({}, J, {}, t.theme || t),
                            o = {},
                            i = function(e) {
                                return function(r) {
                                    var t = {},
                                        a = $(r, "breakpoints", Z),
                                        o = [null].concat(a.map((function(e) {
                                            return "@media screen and (min-width: " + e + ")"
                                        })));
                                    for (var i in e) {
                                        var n = "function" === typeof e[i] ? e[i](r) : e[i];
                                        if (null != n)
                                            if (Array.isArray(n))
                                                for (var l = 0; l < n.slice(0, o.length).length; l++) {
                                                    var s = o[l];
                                                    s ? (t[s] = t[s] || {}, null != n[l] && (t[s][i] = n[l])) : t[i] = n[l]
                                                } else t[i] = n
                                    }
                                    return t
                                }
                            }("function" === typeof r ? r(a) : r)(a);
                        for (var n in i) {
                            var l = i[n],
                                s = "function" === typeof l ? l(a) : l;
                            if ("variant" !== n)
                                if (s && "object" === typeof s) o[n] = e(s)(a);
                                else {
                                    var d = $(Q, n, n),
                                        c = $(re, d),
                                        p = $(a, c, $(a, d, {})),
                                        f = $(ae, d, $)(p, s, s);
                                    if (ee[d])
                                        for (var u = ee[d], m = 0; m < u.length; m++) o[u[m]] = f;
                                    else o[d] = f
                                }
                            else o = q({}, o, {}, e($(a, s))(a))
                        }
                        return o
                    }
                },
                ie = function(e) {
                    var r, t, a = e.scale,
                        o = e.prop,
                        i = void 0 === o ? "variant" : o,
                        n = e.variants,
                        l = void 0 === n ? {} : n,
                        s = e.key;
                    t = Object.keys(l).length ? function(e, r, t) {
                        return oe(m(r, e, null))(t.theme)
                    } : function(e, r) {
                        return m(r, e, null)
                    }, t.scale = a || s, t.defaults = l;
                    var d = ((r = {})[i] = t, r);
                    return g(d)
                },
                ne = ie({
                    key: "buttons"
                }),
                le = ie({
                    key: "textStyles",
                    prop: "textStyle"
                }),
                se = ie({
                    key: "colorStyles",
                    prop: "colors"
                }),
                de = (R.width, R.height, R.minWidth, R.minHeight, R.maxWidth, R.maxHeight, R.size, R.verticalAlign, R.display, R.overflow, R.overflowX, R.overflowY, _.opacity, z.fontSize, z.fontFamily, z.fontWeight, z.lineHeight, z.textAlign, z.fontStyle, z.letterSpacing, T.alignItems, T.alignContent, T.justifyItems, T.justifyContent, T.flexWrap, T.flexDirection, T.flex, T.flexGrow, T.flexShrink, T.flexBasis, T.justifySelf, T.alignSelf, T.order, B.gridGap, B.gridColumnGap, B.gridRowGap, B.gridColumn, B.gridRow, B.gridAutoFlow, B.gridAutoColumns, B.gridAutoRows, B.gridTemplateColumns, B.gridTemplateRows, B.gridTemplateAreas, B.gridArea, I.borderWidth, I.borderStyle, I.borderColor, I.borderTop, I.borderRight, I.borderBottom, I.borderLeft, I.borderRadius, O.backgroundImage, O.backgroundSize, O.backgroundPosition, O.backgroundRepeat, N.zIndex, N.top, N.right, N.bottom, N.left, function(e) {
                    var r = new RegExp("^(" + e.join("|") + ")$");
                    return (0, i.Z)((function(e) {
                        return l(e) && !r.test(e)
                    }))
                }),
                ce = (de(w(D, E, S, x, C, H, M, F, L, V, ne, le, se).propNames), t(11720)),
                pe = t(70917);
            const fe = [...U.propNames, ..._.propNames],
                ue = e => fe.includes(e),
                me = de(fe),
                ge = (0, a.default)("div", {
                    shouldForwardProp: me
                })({
                    boxSizing: "border-box",
                    margin: 0,
                    minWidth: 0
                }, (e => (0, o.iv)(e.__css)(e.theme)), (({
                    theme: e,
                    variant: r,
                    __themeKey: t = "variants"
                }) => (0, o.iv)((0, o.U2)(e, t + "." + r, (0, o.U2)(e, r)))), U, _, (e => (0, o.iv)(e.sx)(e.theme)), (e => e.css));
            ge.displayName = "Box";
            const he = (0, a.default)(ge)({
                display: "flex"
            });

            function be() {
                return be = Object.assign || function(e) {
                    for (var r = 1; r < arguments.length; r++) {
                        var t = arguments[r];
                        for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }, be.apply(this, arguments)
            }
            he.displayName = "Flex";
            const ye = (e, r) => {
                    return Array.isArray(e) ? e.map((e => ye(e, r))) : !!e && `repeat(auto-${r}, minmax(${t=e,"number"===typeof t?t+"px":t}, 1fr))`;
                    var t
                },
                ve = e => Array.isArray(e) ? e.map(ve) : !!e && ("number" === typeof e ? `repeat(${e}, 1fr)` : e),
                we = ce.default.forwardRef((function({
                    width: e,
                    columns: r,
                    gap: t = 3,
                    repeat: a = "fit",
                    ...o
                }, i) {
                    const n = e ? ye(e, a) : ve(r);
                    return ce.default.createElement(ge, be({
                        ref: i
                    }, o, {
                        __themeKey: "grids",
                        __css: {
                            display: "grid",
                            gridGap: t,
                            gridTemplateColumns: n
                        }
                    }))
                })),
                xe = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "button",
                        variant: "primary"
                    }, e, {
                        __themeKey: "buttons",
                        __css: {
                            appearance: "none",
                            display: e.hidden ? void 0 : "inline-block",
                            textAlign: "center",
                            lineHeight: "inherit",
                            textDecoration: "none",
                            fontSize: "inherit",
                            px: 3,
                            py: 2,
                            color: "white",
                            bg: "primary",
                            border: 0,
                            borderRadius: 4
                        }
                    }))
                })),
                Re = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "a",
                        variant: "styles.a"
                    }, e, {
                        __themeKey: "links"
                    }))
                })),
                ke = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "p",
                        variant: "paragraph",
                        __themeKey: "text",
                        __css: {
                            fontFamily: "body",
                            fontWeight: "body",
                            lineHeight: "body"
                        }
                    }, e))
                })),
                Se = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        as: "span",
                        ref: r,
                        variant: "default"
                    }, e, {
                        __themeKey: "text"
                    }))
                })),
                _e = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "h2",
                        variant: "heading"
                    }, e, {
                        __themeKey: "text",
                        __css: {
                            fontFamily: "heading",
                            fontWeight: "heading",
                            lineHeight: "heading"
                        }
                    }))
                })),
                Ee = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "img"
                    }, e, {
                        __themeKey: "images",
                        __css: {
                            maxWidth: "100%",
                            height: "auto",
                            ...e.__css
                        }
                    }))
                })),
                ze = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        variant: "primary"
                    }, e, {
                        __themeKey: "cards"
                    }))
                })),
                Ce = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "label",
                        variant: "label"
                    }, e, {
                        __themeKey: "forms",
                        __css: {
                            width: "100%",
                            display: "flex"
                        }
                    }))
                })),
                Te = {
                    boxShadow: "inset 0 0 0 1000px var(--theme-ui-input-autofill-bg)",
                    fontSize: "inherit",
                    ":first-line": {
                        fontSize: "1rem"
                    }
                },
                We = {
                    display: "block",
                    width: "100%",
                    p: 2,
                    appearance: "none",
                    fontSize: "inherit",
                    lineHeight: "inherit",
                    border: "1px solid",
                    borderRadius: 4,
                    color: "inherit",
                    bg: "transparent",
                    ":autofill, :autofill:hover, :autofill:focus": Te,
                    ":-webkit-autofill, :-webkit-autofill:hover, :-webkit-autofill:focus": Te
                },
                Le = ce.default.forwardRef((function({
                    sx: e,
                    autofillBackgroundColor: r = "background",
                    ...t
                }, a) {
                    return ce.default.createElement(ge, be({
                        ref: a,
                        as: "input",
                        variant: "input",
                        sx: {
                            "--theme-ui-input-autofill-bg": e => (0, o.U2)(e.colors, r, null),
                            ...e
                        }
                    }, t, {
                        __themeKey: "forms",
                        __css: We
                    }))
                })),
                Be = ({
                    size: e = 24,
                    ...r
                }) => ce.default.createElement(ge, be({
                    as: "svg",
                    xmlns: "http://www.w3.org/2000/svg",
                    width: e + "",
                    height: e + "",
                    viewBox: "0 0 24 24",
                    fill: "currentcolor"
                }, r));
            Be.displayName = "SVG";
            const Ae = e => r => {
                    const t = {};
                    for (const a in r) e(a || "") && (t[a] = r[a]);
                    return t
                },
                He = /^m[trblxy]?$/,
                Ie = Ae((e => He.test(e))),
                je = Ae((e => !He.test(e))),
                Me = e => ce.default.createElement(Be, e, ce.default.createElement("path", {
                    d: "M7 10l5 5 5-5z"
                })),
                Oe = ce.default.forwardRef((function({
                    arrow: e,
                    ...r
                }, t) {
                    return ce.default.createElement(ge, be({}, Ie(r), {
                        sx: {
                            display: "flex"
                        }
                    }), ce.default.createElement(ge, be({
                        ref: t,
                        as: "select",
                        variant: "select"
                    }, je(r), {
                        __themeKey: "forms",
                        __css: {
                            display: "block",
                            width: "100%",
                            p: 2,
                            appearance: "none",
                            fontSize: "inherit",
                            lineHeight: "inherit",
                            border: "1px solid",
                            borderRadius: 4,
                            color: "inherit",
                            backgroundColor: e => (0, o.U2)(e, "colors.background", null)
                        }
                    })), e || ce.default.createElement(Me, {
                        sx: {
                            ml: -28,
                            alignSelf: "center",
                            pointerEvents: "none"
                        }
                    }))
                })),
                Pe = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "textarea",
                        variant: "textarea"
                    }, e, {
                        __themeKey: "forms",
                        __css: {
                            display: "block",
                            width: "100%",
                            p: 2,
                            appearance: "none",
                            fontSize: "inherit",
                            lineHeight: "inherit",
                            border: "1px solid",
                            borderRadius: 4,
                            color: "inherit",
                            bg: "transparent"
                        }
                    }))
                })),
                Fe = e => ce.default.createElement(Be, e, ce.default.createElement("path", {
                    d: "M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zm0-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"
                })),
                Ne = e => ce.default.createElement(Be, e, ce.default.createElement("path", {
                    d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"
                })),
                Xe = e => ce.default.createElement(ce.default.Fragment, null, ce.default.createElement(Fe, be({}, e, {
                    __css: {
                        display: "none",
                        "input:checked ~ &": {
                            display: "block"
                        }
                    }
                })), ce.default.createElement(Ne, be({}, e, {
                    __css: {
                        display: "block",
                        "input:checked ~ &": {
                            display: "none"
                        }
                    }
                }))),
                Ke = ce.default.forwardRef((function({
                    className: e,
                    sx: r,
                    variant: t = "radio",
                    ...a
                }, o) {
                    return ce.default.createElement(ge, {
                        sx: {
                            minWidth: "min-content"
                        }
                    }, ce.default.createElement(ge, be({
                        ref: o,
                        as: "input",
                        type: "radio"
                    }, a, {
                        sx: {
                            position: "absolute",
                            opacity: 0,
                            zIndex: -1,
                            width: 1,
                            height: 1,
                            overflow: "hidden"
                        }
                    })), ce.default.createElement(ge, {
                        as: Xe,
                        "aria-hidden": "true",
                        __themeKey: "forms",
                        variant: t,
                        className: e,
                        sx: r,
                        __css: {
                            mr: 2,
                            borderRadius: 9999,
                            color: "gray",
                            flexShrink: 0,
                            "input:checked ~ &": {
                                color: "primary"
                            },
                            "input:focus ~ &": {
                                bg: "highlight"
                            }
                        }
                    }))
                })),
                Ge = e => ce.default.createElement(Be, e, ce.default.createElement("path", {
                    d: "M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
                })),
                Ye = e => ce.default.createElement(Be, e, ce.default.createElement("path", {
                    d: "M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"
                })),
                De = e => ce.default.createElement(ce.default.Fragment, null, ce.default.createElement(Ge, be({}, e, {
                    __css: {
                        display: "none",
                        "input:checked ~ &": {
                            display: "block"
                        }
                    }
                })), ce.default.createElement(Ye, be({}, e, {
                    __css: {
                        display: "block",
                        "input:checked ~ &": {
                            display: "none"
                        }
                    }
                }))),
                Ue = ce.default.forwardRef((function({
                    className: e,
                    sx: r,
                    variant: t = "checkbox",
                    children: a,
                    ...o
                }, i) {
                    return ce.default.createElement(ge, {
                        sx: {
                            minWidth: "min-content"
                        }
                    }, ce.default.createElement(ge, be({
                        ref: i,
                        as: "input",
                        type: "checkbox"
                    }, o, {
                        sx: {
                            position: "absolute",
                            opacity: 0,
                            zIndex: -1,
                            width: 1,
                            height: 1,
                            overflow: "hidden"
                        }
                    })), ce.default.createElement(ge, {
                        as: De,
                        "aria-hidden": "true",
                        __themeKey: "forms",
                        variant: t,
                        className: e,
                        sx: r,
                        __css: {
                            mr: 2,
                            borderRadius: 4,
                            color: "gray",
                            flexShrink: 0,
                            "input:checked ~ &": {
                                color: "primary"
                            },
                            "input:focus ~ &": {
                                color: "primary",
                                bg: "highlight"
                            }
                        }
                    }), a)
                })),
                Ve = ce.default.forwardRef((function({
                    className: e,
                    label: r,
                    sx: t,
                    variant: a = "switch",
                    ...o
                }, i) {
                    return ce.default.createElement(Ce, {
                        sx: {
                            cursor: "pointer"
                        }
                    }, ce.default.createElement(ge, be({
                        ref: i,
                        as: "input",
                        type: "checkbox",
                        __themeKey: "forms",
                        "aria-label": r
                    }, o, {
                        sx: {
                            position: "absolute",
                            opacity: 0,
                            zIndex: -1,
                            width: 1,
                            height: 1,
                            overflow: "hidden"
                        }
                    })), ce.default.createElement(ge, {
                        css: {
                            padding: 2
                        },
                        __themeKey: "forms",
                        variant: a,
                        className: e,
                        sx: t,
                        __css: {
                            position: "relative",
                            bg: "gray",
                            borderRadius: 18,
                            height: 22,
                            width: 40,
                            mr: 2,
                            "input:disabled ~ &": {
                                opacity: .5,
                                cursor: "not-allowed"
                            },
                            "& > div": {
                                display: "flex",
                                alignItems: "center",
                                borderRadius: "50%",
                                height: 18,
                                width: 18,
                                bg: "white",
                                boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
                                position: "relative",
                                transform: "translateX(0%)",
                                transition: "transform 240ms cubic-bezier(0.165, 0.840, 0.440, 1.000)"
                            },
                            "input:checked ~ &": {
                                bg: "primary",
                                "> div": {
                                    transform: "translateX(100%)"
                                }
                            }
                        }
                    }, ce.default.createElement(ge, null)), ce.default.createElement("span", null, r))
                })),
                qe = {
                    appearance: "none",
                    width: 16,
                    height: 16,
                    bg: "currentcolor",
                    border: 0,
                    borderRadius: 9999,
                    variant: "forms.slider.thumb"
                },
                $e = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "input",
                        type: "range",
                        variant: "slider"
                    }, e, {
                        __themeKey: "forms",
                        __css: {
                            display: "block",
                            width: "100%",
                            height: 4,
                            my: 2,
                            cursor: "pointer",
                            appearance: "none",
                            borderRadius: 9999,
                            color: "inherit",
                            bg: "gray",
                            ":focus": {
                                outline: "none",
                                color: "primary"
                            },
                            "&::-webkit-slider-thumb": qe,
                            "&::-moz-range-thumb": qe,
                            "&::-ms-thumb": qe
                        }
                    }))
                })),
                Ze = ce.default.forwardRef((function({
                    as: e = Le,
                    label: r,
                    id: t,
                    name: a,
                    ...o
                }, i) {
                    const n = t || a;
                    return ce.default.createElement(ge, Ie(o), ce.default.createElement(Ce, {
                        htmlFor: n
                    }, r), ce.default.createElement(e, be({
                        ref: i,
                        id: n,
                        name: a
                    }, je(o))))
                })),
                Je = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "progress",
                        variant: "styles.progress"
                    }, e, {
                        __css: {
                            display: "block",
                            width: "100%",
                            height: "4px",
                            margin: 0,
                            padding: 0,
                            overflow: "hidden",
                            appearance: "none",
                            color: "primary",
                            bg: "gray",
                            borderRadius: 9999,
                            border: "none",
                            "&::-webkit-progress-bar": {
                                bg: "transparent"
                            },
                            "&::-webkit-progress-value": {
                                bg: "currentcolor"
                            },
                            "&::-moz-progress-bar": {
                                bg: "currentcolor"
                            }
                        }
                    }))
                })),
                Qe = ce.default.forwardRef((function({
                    size: e = 128,
                    strokeWidth: r = 2,
                    value: t = 0,
                    min: a = 0,
                    max: o = 1,
                    title: i,
                    ...n
                }, l) {
                    const s = 16 - r,
                        d = 2 * s * Math.PI,
                        c = d - (t - a) / (o - a) * d;
                    return ce.default.createElement(ge, be({
                        ref: l,
                        as: "svg",
                        viewBox: "0 0 32 32",
                        width: e,
                        height: e,
                        strokeWidth: r,
                        fill: "none",
                        stroke: "currentcolor",
                        role: "img",
                        "aria-valuenow": t,
                        "aria-valuemin": a,
                        "aria-valuemax": o
                    }, n, {
                        __css: {
                            color: "primary"
                        }
                    }), i && ce.default.createElement("title", null, i), ce.default.createElement("circle", {
                        cx: 16,
                        cy: 16,
                        r: s,
                        opacity: 1 / 8
                    }), ce.default.createElement("circle", {
                        cx: 16,
                        cy: 16,
                        r: s,
                        strokeDasharray: d,
                        strokeDashoffset: c,
                        transform: "rotate(-90 16 16)"
                    }))
                })),
                er = (0, pe.keyframes)({
                    from: {
                        transform: "rotate(0deg)"
                    },
                    to: {
                        transform: "rotate(360deg)"
                    }
                }),
                rr = ce.default.forwardRef((function({
                    size: e = 48,
                    strokeWidth: r = 4,
                    max: t = 1,
                    title: a = "Loading...",
                    duration: o = 500,
                    ...i
                }, n) {
                    const l = 16 - r,
                        s = 2 * l * Math.PI,
                        d = s - 1 / 4 * s;
                    return ce.default.createElement(ge, be({
                        ref: n,
                        as: "svg",
                        viewBox: "0 0 32 32",
                        width: e,
                        height: e,
                        strokeWidth: r,
                        fill: "none",
                        stroke: "currentcolor",
                        role: "img"
                    }, i, {
                        __css: {
                            color: "primary",
                            overflow: "visible"
                        }
                    }), ce.default.createElement("title", null, a), ce.default.createElement("circle", {
                        cx: 16,
                        cy: 16,
                        r: l,
                        opacity: 1 / 8
                    }), ce.default.createElement(ge, {
                        as: "circle",
                        cx: 16,
                        cy: 16,
                        r: l,
                        strokeDasharray: s,
                        strokeDashoffset: d,
                        __css: {
                            transformOrigin: "50% 50%",
                            animationName: er.toString(),
                            animationTimingFunction: "linear",
                            animationDuration: o + "ms",
                            animationIterationCount: "infinite"
                        }
                    }))
                })),
                tr = ce.default.forwardRef((function({
                    size: e = 48,
                    ...r
                }, t) {
                    return ce.default.createElement(Ee, be({
                        ref: t,
                        width: e,
                        height: e,
                        variant: "avatar"
                    }, r, {
                        __css: {
                            borderRadius: 9999
                        }
                    }))
                })),
                ar = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        variant: "primary"
                    }, e, {
                        __themeKey: "badges",
                        __css: {
                            display: "inline-block",
                            verticalAlign: "baseline",
                            fontSize: 0,
                            fontWeight: "bold",
                            whiteSpace: "nowrap",
                            px: 1,
                            borderRadius: 2,
                            color: "white",
                            bg: "primary"
                        }
                    }))
                })),
                or = ce.default.forwardRef((function({
                    size: e = 32,
                    ...r
                }, t) {
                    var a;
                    return ce.default.createElement(ge, be({
                        ref: t,
                        as: "button",
                        variant: "icon"
                    }, r, {
                        __themeKey: "buttons",
                        __css: {
                            label: (null == (a = r.__css) ? void 0 : a.label) || "IconButton",
                            appearance: "none",
                            display: "inline-flex",
                            alignItems: "center",
                            justifyContent: "center",
                            padding: 1,
                            width: e,
                            height: e,
                            color: "inherit",
                            bg: "transparent",
                            border: "none",
                            borderRadius: 4
                        }
                    }))
                })),
                ir = ce.default.createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "24",
                    height: "24",
                    fill: "currentcolor",
                    viewBox: "0 0 24 24"
                }, ce.default.createElement("path", {
                    d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
                })),
                nr = ce.default.forwardRef((function({
                    size: e = 32,
                    ...r
                }, t) {
                    return ce.default.createElement(or, be({
                        ref: t,
                        size: e,
                        title: "Close",
                        "aria-label": "Close",
                        variant: "close"
                    }, r, {
                        children: ir
                    }))
                })),
                lr = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        variant: "primary"
                    }, e, {
                        __themeKey: "alerts",
                        __css: {
                            display: "flex",
                            alignItems: "center",
                            px: 3,
                            py: 2,
                            fontWeight: "bold",
                            color: "white",
                            bg: "primary",
                            borderRadius: 4
                        }
                    }))
                })),
                sr = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        as: "hr",
                        variant: "styles.hr"
                    }, e, {
                        __css: {
                            color: "gray",
                            m: 0,
                            my: 2,
                            border: 0,
                            borderBottom: "1px solid"
                        }
                    }))
                })),
                dr = Ae(ue),
                cr = Ae((e => !ue(e))),
                pr = ce.default.forwardRef((function({
                    variant: e,
                    sx: r,
                    ratio: t = 16 / 9,
                    src: a,
                    frameBorder: o = 0,
                    allowFullScreen: i = !0,
                    width: n = 560,
                    height: l = 315,
                    allow: s,
                    ...d
                }, c) {
                    return ce.default.createElement(ge, be({
                        variant: e,
                        sx: r,
                        __css: {
                            width: "100%",
                            height: 0,
                            paddingBottom: 100 / t + "%",
                            position: "relative",
                            overflow: "hidden"
                        }
                    }, dr(d)), ce.default.createElement(ge, be({
                        ref: c,
                        as: "iframe",
                        src: a,
                        width: n,
                        height: l,
                        frameBorder: o,
                        allowFullScreen: i,
                        allow: s
                    }, cr(d), {
                        __css: {
                            position: "absolute",
                            width: "100%",
                            height: "100%",
                            top: 0,
                            bottom: 0,
                            left: 0,
                            border: 0
                        }
                    })))
                })),
                fr = ce.default.forwardRef((function({
                    ratio: e = 4 / 3,
                    children: r,
                    ...t
                }, a) {
                    return ce.default.createElement(ge, {
                        ref: a,
                        sx: {
                            position: "relative",
                            overflow: "hidden"
                        }
                    }, ce.default.createElement(ge, {
                        sx: {
                            width: "100%",
                            height: 0,
                            paddingBottom: 100 / e + "%"
                        }
                    }), ce.default.createElement(ge, be({}, t, {
                        __css: {
                            position: "absolute",
                            top: 0,
                            right: 0,
                            bottom: 0,
                            left: 0
                        }
                    }), r))
                })),
                ur = ce.default.forwardRef((function({
                    ratio: e,
                    ...r
                }, t) {
                    return ce.default.createElement(fr, {
                        ratio: e
                    }, ce.default.createElement(Ee, be({
                        ref: t
                    }, r, {
                        __css: {
                            objectFit: "cover"
                        }
                    })))
                })),
                mr = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r,
                        variant: "container"
                    }, e, {
                        __themeKey: "layout",
                        __css: {
                            width: "100%",
                            maxWidth: "container",
                            mx: "auto"
                        }
                    }))
                })),
                gr = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(Re, be({
                        ref: r,
                        variant: "nav"
                    }, e, {
                        __css: {
                            color: "inherit",
                            textDecoration: "none",
                            fontWeight: "bold",
                            display: "inline-block",
                            "&:hover, &:focus, &.active": {
                                color: "primary"
                            }
                        }
                    }))
                })),
                hr = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(ge, be({
                        ref: r
                    }, e, {
                        __themeKey: "messages",
                        __css: {
                            padding: 3,
                            paddingLeft: e => e.space[3] - e.space[1],
                            borderLeftWidth: e => e.space[1],
                            borderLeftStyle: "solid",
                            borderLeftColor: "primary",
                            borderRadius: 4,
                            bg: "highlight"
                        }
                    }))
                })),
                br = ({
                    size: e = 24
                }) => ce.default.createElement(ge, {
                    as: "svg",
                    xmlns: "http://www.w3.org/2000/svg",
                    width: e,
                    height: e,
                    fill: "currentcolor",
                    viewBox: "0 0 24 24",
                    sx: {
                        display: "block",
                        margin: 0
                    }
                }, ce.default.createElement("path", {
                    d: "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"
                })),
                yr = ce.default.forwardRef((function(e, r) {
                    return ce.default.createElement(or, be({
                        ref: r,
                        title: "Menu",
                        "aria-label": "Toggle Menu",
                        variant: "menu"
                    }, e), ce.default.createElement(br, null))
                }))
        },
        96086: function(e) {
            var r = Object.assign.bind(Object);
            e.exports = r, e.exports.default = e.exports
        }
    }
]);
//# sourceMappingURL=7388-8b362cd4ecc7e33a.js.map