"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [50547], {
        39280: function(l, e, n) {
            function t(l) {
                return t = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(l) {
                    return typeof l
                } : function(l) {
                    return l && "function" === typeof Symbol && l.constructor === Symbol && l !== Symbol.prototype ? "symbol" : typeof l
                }, t(l)
            }
            n(19601), Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = function(l) {
                if (l && l.__esModule) return l;
                if (null === l || "object" !== t(l) && "function" !== typeof l) return {
                    default: l
                };
                var e = a();
                if (e && e.has(l)) return e.get(l);
                var n = {},
                    r = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var i in l)
                    if (Object.prototype.hasOwnProperty.call(l, i)) {
                        var u = r ? Object.getOwnPropertyDescriptor(l, i) : null;
                        u && (u.get || u.set) ? Object.defineProperty(n, i, u) : n[i] = l[i]
                    }
                n.default = l, e && e.set(l, n);
                return n
            }(n(11720));

            function a() {
                if ("function" !== typeof WeakMap) return null;
                var l = new WeakMap;
                return a = function() {
                    return l
                }, l
            }

            function i() {
                return i = Object.assign || function(l) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (l[t] = n[t])
                    }
                    return l
                }, i.apply(this, arguments)
            }
            var u = function(l) {
                return r.createElement("svg", i({
                    height: 310,
                    width: 1195
                }, l), r.createElement("mask", {
                    id: "christopher-bottom_svg__a",
                    fill: "#fff"
                }, r.createElement("path", {
                    className: "christopher-bottom_svg__p1",
                    d: "M0 0h1195v310H0z",
                    fillRule: "evenodd"
                })), r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd",
                    mask: "url(#christopher-bottom_svg__a)"
                }, r.createElement("path", {
                    className: "christopher-bottom_svg__p2",
                    d: "M802.193 453.363l359.4-207.5 19.5 33.774-359.4 207.5z",
                    fill: "#fcce0d"
                }), r.createElement("path", {
                    className: "christopher-bottom_svg__p3",
                    d: "M515.277 346.302l462.458-267 54.5 94.396-462.458 267z",
                    fill: "#7933ff"
                }), r.createElement("path", {
                    className: "christopher-bottom_svg__p4",
                    d: "M667.947 331.802l471.118-272 54.5 94.396-471.118 272z",
                    fill: "#06bdfc"
                }), r.createElement("path", {
                    className: "christopher-bottom_svg__p5",
                    d: "M667.716 331.331l342.08-197.5 23 39.838-342.08 197.5z",
                    fill: "#05172c"
                }), r.createElement("g", null, r.createElement("path", {
                    className: "christopher-bottom_svg__p6",
                    d: "M186.682 320.578l520.481-300.5 43.5 75.344-520.481 300.5z",
                    fill: "#06bdfc"
                }), r.createElement("path", {
                    className: "christopher-bottom_svg__p7",
                    d: "M227.489 352.531l368.927-213 39 67.55-368.927 213z",
                    fill: "#ff6ea9"
                }), r.createElement("path", {
                    d: "M227.489 352.531l368.927-213 19.5 33.775-368.927 213z",
                    fill: "#05172c"
                }), r.createElement("path", {
                    className: "christopher-bottom_svg__p8",
                    d: "M33.613 316.113L576.61 2.613l19.5 33.774-542.998 313.5z",
                    fill: "#fcce0d"
                }))))
            };
            e.default = u
        },
        42682: function(l, e, n) {
            function t(l) {
                return t = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(l) {
                    return typeof l
                } : function(l) {
                    return l && "function" === typeof Symbol && l.constructor === Symbol && l !== Symbol.prototype ? "symbol" : typeof l
                }, t(l)
            }
            n(19601), Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = function(l) {
                if (l && l.__esModule) return l;
                if (null === l || "object" !== t(l) && "function" !== typeof l) return {
                    default: l
                };
                var e = a();
                if (e && e.has(l)) return e.get(l);
                var n = {},
                    r = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var i in l)
                    if (Object.prototype.hasOwnProperty.call(l, i)) {
                        var u = r ? Object.getOwnPropertyDescriptor(l, i) : null;
                        u && (u.get || u.set) ? Object.defineProperty(n, i, u) : n[i] = l[i]
                    }
                n.default = l, e && e.set(l, n);
                return n
            }(n(11720));

            function a() {
                if ("function" !== typeof WeakMap) return null;
                var l = new WeakMap;
                return a = function() {
                    return l
                }, l
            }

            function i() {
                return i = Object.assign || function(l) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (l[t] = n[t])
                    }
                    return l
                }, i.apply(this, arguments)
            }
            var u = function(l) {
                return r.createElement("svg", i({
                    height: 110,
                    width: 164
                }, l), r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd",
                    transform: "rotate(180 82 55)"
                }, r.createElement("circle", {
                    className: "christopher-top_svg__c1",
                    cx: 109.026,
                    cy: 54.594,
                    fill: "#7933ff",
                    r: 54.594
                }), r.createElement("circle", {
                    className: "christopher-top_svg__c2",
                    cx: 54.594,
                    cy: 54.594,
                    fill: "#fcce0d",
                    r: 54.594
                }), r.createElement("path", {
                    d: "M81.811 7.258c16.362 9.428 27.377 27.096 27.377 47.336S98.173 92.502 81.811 101.93c-16.364-9.427-27.379-27.095-27.379-47.336 0-20.201 10.972-37.84 27.282-47.282z",
                    fill: "#05172c"
                })))
            };
            e.default = u
        },
        58423: function(l, e, n) {
            e.Z = void 0;
            var t = o(n(11720)),
                r = n(18733),
                a = o(n(39280)),
                i = o(n(42682)),
                u = o(n(52449));

            function o(l) {
                return l && l.__esModule ? l : {
                    default: l
                }
            }
            var c = function(l) {
                var e = l.children,
                    n = l.className,
                    o = l.formCta,
                    c = l.registeredUsers;
                return (0, r.jsx)(r.Box, {
                    as: "section",
                    className: n,
                    sx: {
                        bg: "navy.200",
                        pb: [260, null, null, 340, null, 90],
                        position: "relative",
                        pt: [64, null, null, null, null, 140]
                    }
                }, (0, r.jsx)(r.Container, {
                    sx: {
                        alignItems: ["center", null, null, null, null, "flex-start"],
                        display: "flex",
                        flexDirection: ["column", null, null, null, null, "row"],
                        justifyContent: [null, null, null, null, null, "space-between"],
                        position: "relative",
                        zIndex: 10
                    }
                }, (0, r.jsx)(r.Text, {
                    as: "h2",
                    sx: {
                        "> span": {
                            display: ["block", null, null, null, null, "inline"]
                        },
                        color: "white",
                        maxWidth: 570,
                        mb: 32,
                        textAlign: ["center", null, null, null, null, "left"]
                    },
                    variant: "h50"
                }, e || (0, r.jsx)(t.default.Fragment, null, "Join more than", " ", (0, r.jsx)("span", {
                    sx: {
                        color: "green.200"
                    }
                }, Math.floor(c / 1e6), " million learners"), " ", "worldwide")), (0, r.jsx)(u.default, {
                    formCta: o
                })), (0, r.jsx)(r.Flex, {
                    "aria-hidden": "true",
                    sx: {
                        bottom: 0,
                        height: 310,
                        justifyContent: "flex-end",
                        left: 0,
                        overflow: "hidden",
                        position: "absolute",
                        pr: [null, null, null, "50%"],
                        right: 0
                    }
                }, (0, r.jsx)(a.default, {
                    "aria-hidden": "true",
                    sx: {
                        flexShrink: 0
                    }
                })), (0, r.jsx)(r.Flex, {
                    "aria-hidden": "true",
                    sx: {
                        display: ["none", null, null, null, null, "flex"],
                        height: 110,
                        justifyContent: "center",
                        left: 0,
                        overflow: "hidden",
                        position: "absolute",
                        right: 0,
                        top: -55
                    }
                }, (0, r.jsx)(i.default, {
                    "aria-hidden": "true",
                    sx: {
                        flexShrink: 0,
                        mr: 1170
                    }
                })))
            };
            e.Z = c
        },
        22163: function(l, e, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(l) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (l[t] = n[t])
                    }
                    return l
                }, a.apply(this, arguments)
            }
            e.Z = function(l) {
                return r.createElement("svg", a({
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 90 12"
                }, l), t || (t = r.createElement("path", {
                    fill: "currentColor",
                    d: "M40.48.82c.52 0 1 .24 1.29.65l6.7 10.21h-2.5l-1.18-1.9h-5.73l-1.25-1.9h5.66L40.48 3.2l-5.5 8.5h-2.5l6.69-10.2a1.59 1.59 0 0 1 1.31-.67zm23.3.1v8.86h9.9l-1.26 1.9h-9.68c-.3 0-.57-.11-.77-.3a1 1 0 0 1-.3-.73V.92h2.11zm-35.1 0a3.69 3.69 0 0 1 3.74 3.65c0 2-1.68 3.63-3.74 3.63h-.96l4.26 3.48H28.9L22.56 6.3h5.98c.99 0 1.78-.77 1.78-1.74 0-.96-.8-1.74-1.78-1.74h-7.02v8.86H19.4V.93h9.28zm-15.92 0a5.45 5.45 0 0 1 5.51 5.39 5.44 5.44 0 0 1-5.51 5.37H6.35C3.3 11.68.83 9.28.83 6.31S3.3.92 6.35.92h6.4zm47.76 0-1.24 1.9h-6.24a3.53 3.53 0 0 0-3.57 3.49c0 1.92 1.6 3.47 3.57 3.47h7.65l-1.25 1.9H52.9c-3.04 0-5.52-2.4-5.52-5.37S49.86.93 52.9.93h7.62zm25.81 0-1.26 1.9h-6.22a3.56 3.56 0 0 0-3.44 2.53h10.32l-1.25 1.9h-9.07a3.55 3.55 0 0 0 3.44 2.53h7.65l-1.25 1.9H78.7c-3.05 0-5.52-2.4-5.52-5.37S75.66.93 78.7.93h7.62zm-73.72 1.9H6.5a3.53 3.53 0 0 0-3.57 3.49c0 1.92 1.6 3.47 3.57 3.47h6.13a3.52 3.52 0 0 0 3.57-3.47c0-1.93-1.6-3.49-3.57-3.49zm75.8-2c.71 0 1.28.57 1.28 1.28a1.28 1.28 0 0 1-2.55 0c0-.7.57-1.28 1.27-1.28zm0 .27a1 1 0 0 0-1 1 1 1 0 0 0 1 1 1 1 0 0 0 1.01-1 1 1 0 0 0-1-1zm-.12.25c.2 0 .29 0 .38.04.25.09.28.31.28.4 0 .02 0 .07-.02.12a.37.37 0 0 1-.17.24l-.07.04.33.59h-.32l-.29-.54h-.2v.54h-.28V1.34h.36zm.1.23h-.18V2h.18c.1 0 .19 0 .24-.09a.2.2 0 0 0 .04-.13.2.2 0 0 0-.11-.17.44.44 0 0 0-.18-.03z"
                })))
            }
        },
        4936: function(l, e, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(l) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (l[t] = n[t])
                    }
                    return l
                }, a.apply(this, arguments)
            }
            e.Z = function(l) {
                return r.createElement("svg", a({
                    height: 121,
                    width: 1270,
                    xmlns: "http://www.w3.org/2000/svg"
                }, l), t || (t = r.createElement("g", {
                    fill: "none"
                }, r.createElement("path", {
                    className: "horatio-left_svg__p1",
                    d: "M0 0v85h1067V0z",
                    fill: "#06bdfc"
                }), r.createElement("path", {
                    className: "horatio-left_svg__p2",
                    d: "M1067 85.07v35h203v-35z",
                    fill: "#7933ff"
                }))))
            }
        },
        95711: function(l, e, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(l) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (l[t] = n[t])
                    }
                    return l
                }, a.apply(this, arguments)
            }
            e.Z = function(l) {
                return r.createElement("svg", a({
                    height: 140,
                    width: 2031,
                    xmlns: "http://www.w3.org/2000/svg"
                }, l), t || (t = r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, r.createElement("path", {
                    className: "horatio-right_svg__p5",
                    d: "M0 70v35h331V70z",
                    fill: "#fffbf3"
                }), r.createElement("path", {
                    className: "horatio-right_svg__p4",
                    d: "M190.74 0v70h343V0z",
                    fill: "#213147"
                }), r.createElement("path", {
                    className: "horatio-right_svg__p1",
                    d: "M533.74 0v70h1497V0z",
                    fill: "#974dff"
                }), r.createElement("path", {
                    className: "horatio-right_svg__p3",
                    d: "M331 35v105h1700V35z",
                    fill: "#06bdfc"
                }), r.createElement("path", {
                    className: "horatio-right_svg__p2",
                    d: "M331 35v35h203V35z",
                    fill: "#60e7ff"
                }))))
            }
        },
        34152: function(l, e, n) {
            var t, r = n(11720);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(l) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (l[t] = n[t])
                    }
                    return l
                }, a.apply(this, arguments)
            }
            e.Z = function(l) {
                return r.createElement("svg", a({
                    height: 105,
                    width: 1200,
                    xmlns: "http://www.w3.org/2000/svg"
                }, l), t || (t = r.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, r.createElement("path", {
                    className: "sm-beach_svg__p1",
                    d: "M0 0v70h731V0z",
                    fill: "#06bdfc"
                }), r.createElement("path", {
                    className: "sm-beach_svg__p2",
                    d: "M526 35v70h674V35z",
                    fill: "#ff6ea9"
                }), r.createElement("path", {
                    d: "M526 35v35h205V35z",
                    fill: "#051a2e"
                }))))
            }
        },
        67979: function(l, e, n) {
            var t = n(44103),
                r = n(21217),
                a = n(22429),
                i = n(25675),
                u = n.n(i),
                o = (n(11720), n(7388));
            e.Z = function() {
                return (0, t.tZ)(o.xu, {
                    sx: {
                        bg: "beige.100",
                        position: "relative"
                    },
                    children: (0, t.BX)(o.W2, {
                        sx: {
                            alignItems: [null, null, null, null, null, "center"],
                            display: [null, null, null, null, null, "flex"],
                            justifyContent: [null, null, null, null, null, "space-between"],
                            maxWidth: [550, null, null, null, null, 1172],
                            pb: [64, null, null, null, null, 90],
                            position: "relative",
                            pt: [64, null, null, null, null, 72],
                            zIndex: 10
                        },
                        children: [(0, t.BX)(o.xu, {
                            sx: {
                                pt: [48, null, null, null, 0],
                                textAlign: [null, null, null, null, "left"],
                                width: ["100%", null, null, null, null, "45%"]
                            },
                            children: [(0, t.tZ)(o.xv, {
                                as: "p",
                                sx: {
                                    color: "pink.200",
                                    mb: 12
                                },
                                variant: "c14",
                                children: "Certification"
                            }), (0, t.tZ)(o.xv, {
                                as: "h2",
                                sx: {
                                    mb: 8
                                },
                                variant: "h40",
                                children: "Land your dream job in data science"
                            }), (0, t.tZ)(o.xv, {
                                as: "p",
                                sx: {
                                    mb: 16
                                },
                                variant: "t18",
                                children: "From a certification in data science to personalized resume reviews and interview prep\u2014we've got you covered."
                            }), (0, t.tZ)(a.default, {
                                href: r.certification.CERTIFICATION_LANDING_PATH,
                                type: "link",
                                children: "Learn More"
                            })]
                        }), (0, t.tZ)(o.kC, {
                            sx: {
                                alignItems: "flex-start",
                                flexShrink: 0,
                                img: {
                                    height: "auto",
                                    maxWidth: "100%"
                                },
                                justifyContent: ["center", null, null, null, "flex-end"],
                                mt: [16, null, null, null, 0],
                                mx: ["auto", null, null, null, 0]
                            },
                            children: (0, t.tZ)(u(), {
                                alt: "Screenshot of data scientist and hiring manager",
                                height: 464,
                                src: "/Marketing/Certification/certification_light.png",
                                width: 616
                            })
                        })]
                    })
                })
            }
        },
        51707: function(l, e, n) {
            var t = n(44103),
                r = n(52449),
                a = n(87591),
                i = (n(11720), n(7388)),
                u = n(4936),
                o = n(95711),
                c = n(34152),
                s = n(26303);
            e.Z = function(l) {
                var e = l.children,
                    n = l.className,
                    f = l.formCta,
                    h = l.formIdPrefix,
                    p = l.formRedirectPath,
                    d = l.formTitleElement;
                return (0, t.BX)(i.xu, {
                    as: "header",
                    className: n,
                    sx: {
                        bg: "navy.200",
                        pb: [96, null, null, null, 170],
                        position: "relative",
                        pt: [64]
                    },
                    children: [(0, t.BX)(i.W2, {
                        children: [(0, t.BX)(i.kC, {
                            sx: {
                                alignItems: ["center"],
                                flexDirection: ["column", null, null, null, "row"],
                                justifyContent: [null, null, null, "space-between"]
                            },
                            children: [e, (0, t.tZ)(r.default, {
                                formCta: f,
                                idPrefix: h,
                                redirectPath: p,
                                title: d
                            })]
                        }), (0, t.tZ)(i.kC, {
                            sx: {
                                "> *": {
                                    m: 8
                                },
                                alignItems: "center",
                                color: "rgba(255, 255, 255, 0.8)",
                                flexWrap: "wrap",
                                justifyContent: ["center", null, null, null, null, "space-between"],
                                maxWidth: [520, null, null, null, null, "100%"],
                                mx: ["auto", null, null, null, null, -8],
                                pt: 56
                            },
                            children: (0, t.tZ)(s.Z, {})
                        })]
                    }), (0, t.BX)(a.default, {
                        className: "ie-vsWrapper",
                        sx: {
                            alignItems: "flex-end",
                            bottom: [-70, null, null, null, -36],
                            justifyContent: "center"
                        },
                        children: [(0, t.tZ)(c.Z, {
                            "aria-hidden": "true",
                            sx: {
                                ".sm-beach_svg__p2": {
                                    fill: "purple.200"
                                },
                                display: [null, null, null, null, "none"],
                                flexShrink: 0
                            }
                        }), (0, t.tZ)(u.Z, {
                            "aria-hidden": "true",
                            sx: {
                                display: ["none", null, null, null, "block"],
                                flexShrink: 0
                            }
                        }), (0, t.tZ)(o.Z, {
                            "aria-hidden": "true",
                            sx: {
                                display: ["none", null, null, null, "block"],
                                flexShrink: 0,
                                transform: "translate(390px, 0)"
                            }
                        })]
                    })]
                })
            }
        },
        53166: function(l, e, n) {
            var t = n(44103),
                r = n(25675),
                a = n.n(r),
                i = (n(11720), n(7388)),
                u = n(8683),
                o = n(66674),
                c = n(42725);
            e.Z = function(l) {
                var e = l.inverted;
                return (0, t.BX)(u.Z, {
                    inverted: e,
                    sx: {
                        "> *": {
                            width: [null, null, null, null, "50%"]
                        },
                        alignItems: [null, null, null, null, "center"],
                        display: [null, null, null, null, "flex"],
                        mt: [80, null, null, null, 70]
                    },
                    children: [(0, t.tZ)(o.Z, {
                        children: (0, t.tZ)(c.Z, {
                            captions: ["No installation required", "\u2014 run code from your browser"],
                            colors: ["blue.200", "white"]
                        })
                    }), (0, t.tZ)(i.kC, {
                        sx: {
                            alignItems: "flex-start",
                            flexShrink: 0,
                            img: {
                                aspectRatio: "".concat(1022 / 580),
                                height: "auto",
                                maxWidth: ["100%", null, null, 511]
                            },
                            justifyContent: ["center", null, null, null, "flex-end"],
                            mt: [16, null, null, null, 0],
                            mx: ["auto", null, null, null, 0],
                            pr: [null, null, null, null, 40]
                        },
                        children: (0, t.tZ)(a(), {
                            alt: "Screenshot of Campus exercise",
                            height: 292,
                            src: "/Marketing/Screenshots/screenshot-campus-encoding-time.png",
                            width: 511
                        })
                    })]
                })
            }
        },
        8683: function(l, e, n) {
            var t = n(44103);
            n(11720);
            e.Z = function(l) {
                var e = l.children,
                    n = l.className,
                    r = l.inverted;
                return (0, t.tZ)("figure", {
                    className: n,
                    sx: {
                        flexDirection: r ? "row-reverse" : "row"
                    },
                    children: e
                })
            }
        },
        66674: function(l, e, n) {
            var t = n(44103);
            n(11720);
            e.Z = function(l) {
                var e = l.children;
                return (0, t.tZ)("figcaption", {
                    sx: {
                        maxWidth: [539, null, null, null, "auto"],
                        mx: ["auto", null, null, null, 0],
                        order: [null, null, null, null, 1],
                        pl: [null, null, null, null, 40],
                        textAlign: ["center", null, null, null, "left"]
                    },
                    children: e
                })
            }
        },
        42725: function(l, e, n) {
            var t = n(44103),
                r = (n(11720), n(7388));
            e.Z = function(l) {
                var e = l.captions,
                    n = l.children,
                    a = l.className,
                    i = l.colors;
                return (0, t.BX)(r.xv, {
                    as: "p",
                    className: a,
                    variant: "h32",
                    children: [(0, t.tZ)("span", {
                        sx: {
                            color: i ? i[0] : "white"
                        },
                        children: e ? e[0] : ""
                    }), (0, t.BX)("span", {
                        sx: {
                            color: i ? i[1] : "white"
                        },
                        children: [" ", e ? e[1] : ""]
                    }), n]
                })
            }
        },
        2294: function(l, e, n) {
            var t = n(44103),
                r = n(25675),
                a = n.n(r),
                i = (n(11720), n(7388)),
                u = n(8683),
                o = n(66674),
                c = n(42725);
            e.Z = function(l) {
                var e = l.highlightColor;
                return (0, t.BX)(u.Z, {
                    sx: {
                        "> *": {
                            width: [null, null, null, null, "50%"]
                        },
                        alignItems: [null, null, null, null, "center"],
                        display: [null, null, null, null, "flex"],
                        mt: [80, null, null, null, 144]
                    },
                    children: [(0, t.tZ)(o.Z, {
                        children: (0, t.tZ)(c.Z, {
                            captions: ["Interactive exercises", "short videos"],
                            colors: [e || "yellow.200", e || "yellow.200"],
                            sx: {
                                maxWidth: 372,
                                mx: ["auto", null, null, null, 0]
                            }
                        })
                    }), (0, t.tZ)(i.kC, {
                        sx: {
                            alignItems: "flex-start",
                            flexShrink: 0,
                            img: {
                                aspectRatio: "".concat(948 / 688),
                                height: "auto",
                                maxWidth: ["100%", null, null, 473]
                            },
                            justifyContent: ["center", null, null, null, "flex-end"],
                            mt: [16, null, null, null, 0],
                            mx: ["auto", null, null, null, 0],
                            pr: [null, null, null, null, 40]
                        },
                        children: (0, t.tZ)(a(), {
                            alt: "Screenshot of campus exercise with photo of Richie Cotton",
                            height: 344,
                            src: "/Marketing/Illustrations/hands-on-learning-experience.png",
                            width: 473
                        })
                    })]
                })
            }
        }
    }
]);
//# sourceMappingURL=50547-0b055ee056101cee.js.map