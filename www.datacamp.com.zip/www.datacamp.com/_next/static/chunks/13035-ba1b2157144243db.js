"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [13035], {
        33650: function(e, t, r) {
            function o(e) {
                return o = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, o(e)
            }
            r(19601), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== o(e) && "function" !== typeof e) return {
                    default: e
                };
                var t = a();
                if (t && t.has(e)) return t.get(e);
                var r = {},
                    n = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var i in e)
                    if (Object.prototype.hasOwnProperty.call(e, i)) {
                        var l = n ? Object.getOwnPropertyDescriptor(e, i) : null;
                        l && (l.get || l.set) ? Object.defineProperty(r, i, l) : r[i] = e[i]
                    }
                r.default = e, t && t.set(e, r);
                return r
            }(r(11720));

            function a() {
                if ("function" !== typeof WeakMap) return null;
                var e = new WeakMap;
                return a = function() {
                    return e
                }, e
            }

            function i() {
                return i = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (e[o] = r[o])
                    }
                    return e
                }, i.apply(this, arguments)
            }
            var l = function(e) {
                return n.createElement("svg", i({
                    viewBox: "0 0 743 458"
                }, e), n.createElement("path", {
                    d: "M732.359 251.649l-.405.36-234.33 205.431-39.553-45.117 174.926-153.354-632.14.149-.02-60 631.329-.149L458.022 45.633l39.65-45.03 234.331 206.332c13.45 11.843 13.562 32.719.356 44.714z",
                    fill: "currentColor"
                }))
            };
            t.default = l
        },
        70883: function(e, t, r) {
            function o(e) {
                return o = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, o(e)
            }
            r(19601), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== o(e) && "function" !== typeof e) return {
                    default: e
                };
                var t = a();
                if (t && t.has(e)) return t.get(e);
                var r = {},
                    n = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var i in e)
                    if (Object.prototype.hasOwnProperty.call(e, i)) {
                        var l = n ? Object.getOwnPropertyDescriptor(e, i) : null;
                        l && (l.get || l.set) ? Object.defineProperty(r, i, l) : r[i] = e[i]
                    }
                r.default = e, t && t.set(e, r);
                return r
            }(r(11720));

            function a() {
                if ("function" !== typeof WeakMap) return null;
                var e = new WeakMap;
                return a = function() {
                    return e
                }, e
            }

            function i() {
                return i = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (e[o] = r[o])
                    }
                    return e
                }, i.apply(this, arguments)
            }
            var l = function(e) {
                return n.createElement("svg", i({
                    height: 164,
                    width: 110
                }, e), n.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd",
                    transform: "rotate(90 55 55)"
                }, n.createElement("circle", {
                    className: "broome_svg__c2",
                    cx: 109.026,
                    cy: 54.594,
                    fill: "#974dff",
                    r: 54.594
                }), n.createElement("circle", {
                    className: "broome_svg__c1",
                    cx: 54.594,
                    cy: 54.594,
                    fill: "#ff6ea9",
                    r: 54.594
                }), n.createElement("path", {
                    d: "M81.811 7.258c16.362 9.428 27.377 27.096 27.377 47.336S98.173 92.502 81.811 101.93c-16.364-9.427-27.379-27.095-27.379-47.336 0-20.201 10.972-37.84 27.282-47.282z",
                    fill: "#05172c"
                })))
            };
            t.default = l
        },
        5840: function(e, t, r) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = i(r(11720)),
                n = i(r(86529)),
                a = r(72291);

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var l = function(e) {
                var t = e.additionalTransform,
                    r = e.autoPlay,
                    i = e.children,
                    l = e.customButtonGroup,
                    s = e.deviceType,
                    u = e.isInfinite,
                    c = e.isOverflowVisible,
                    f = e.responsive,
                    d = e.shouldResetAutoplay,
                    p = e.ssr,
                    b = void 0 === p || p,
                    v = e.transitionDuration;
                return o.default.createElement(a.EmoWrapper, {
                    isOverflowVisible: c
                }, o.default.createElement(n.default, {
                    additionalTransfrom: t,
                    arrows: !1,
                    autoPlay: r || !1,
                    containerClass: "carousel-container",
                    customButtonGroup: l,
                    deviceType: s,
                    draggable: !0,
                    infinite: u || !1,
                    partialVisible: !0,
                    renderButtonGroupOutside: !0,
                    responsive: f,
                    shouldResetAutoplay: d || !1,
                    showDots: !1,
                    ssr: b,
                    swipeable: !0,
                    transitionDuration: v || 50
                }, i))
            };
            t.default = l
        },
        72291: function(e, t, r) {
            var o;

            function n() {
                var e = function(e, t) {
                    t || (t = e.slice(0));
                    return Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(t)
                        }
                    }))
                }(["\n  .carousel-container {\n    ", "\n  }\n"]);
                return n = function() {
                    return e
                }, e
            }
            r(47042), r(43371), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.EmoWrapper = void 0;
            var a = ((o = r(70477)) && o.__esModule ? o : {
                default: o
            }).default.div(n(), (function(e) {
                return e.isOverflowVisible && "\n      overflow: visible;\n      "
            }));
            t.EmoWrapper = a
        },
        20551: function(e, t, r) {
            r(82526), r(57327), r(89554), r(68309), r(38880), r(49337), r(47941), r(54747), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o, n = r(18733),
                a = (o = r(33650)) && o.__esModule ? o : {
                    default: o
                };

            function i(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, o)
                }
                return r
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(r), !0).forEach((function(t) {
                        s(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : i(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function s(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var u = function(e) {
                    var t = e.accentColor,
                        r = e.className,
                        o = e.isLink,
                        i = e.name,
                        s = e.photoPath,
                        u = e.quote,
                        c = e.subtext;
                    return (0, n.jsx)(n.Flex, {
                        className: r,
                        sx: {
                            flex: 1,
                            height: "100%",
                            mx: 12,
                            position: "relative"
                        }
                    }, (0, n.jsx)(n.Flex, {
                        sx: {
                            "&:before": {
                                backgroundColor: "navy.200",
                                backgroundImage: "string" === typeof s ? "url('https://res.cloudinary.com/dyd911kmh/image/upload/w_188/v1600538292/Marketing/".concat(s, ".jpg')") : "url(".concat(null === s || void 0 === s ? void 0 : s.url, ")"),
                                backgroundSize: "cover",
                                borderRadius: "circle",
                                content: '""',
                                height: 94,
                                left: 24,
                                position: "absolute",
                                top: 0,
                                width: 94,
                                zIndex: 5
                            }
                        }
                    }, (0, n.jsx)(n.Card, {
                        className: "ie-accentTop",
                        sx: l(l({
                            "& > *": {
                                color: "text",
                                position: "relative",
                                zIndex: 2
                            },
                            "&::after": {
                                bg: t || "yellow.200",
                                bottom: 0,
                                content: '""',
                                left: 0,
                                position: "absolute",
                                right: 0,
                                top: 0,
                                transform: "translateY(calc(12px - 100%))",
                                transition: "transform 0.3s cubic-bezier(0.85, 0, 0.15, 1)",
                                zIndex: 1
                            }
                        }, o && {
                            "&:active, &:focus, &:hover": {
                                "&:after": {
                                    transform: "translateY(0)"
                                }
                            }
                        }), {}, {
                            bg: "white",
                            borderRadius: "rounded",
                            boxShadow: "default",
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "space-between",
                            marginTop: 47,
                            overflow: "hidden",
                            p: 24,
                            paddingTop: 71,
                            position: "relative",
                            textDecoration: "none"
                        }),
                        variant: "accentTop"
                    }, (0, n.jsx)(n.Flex, {
                        sx: {
                            flexDirection: "column",
                            flexGrow: 1,
                            justifyContent: "space-between"
                        }
                    }, (0, n.jsx)(n.Text, {
                        as: "p",
                        dangerouslySetInnerHTML: {
                            __html: u
                        },
                        sx: {
                            mb: 24
                        },
                        variant: "h24"
                    }), (0, n.jsx)(n.Text, {
                        as: "p",
                        variant: "t16"
                    }, c)), o && (0, n.jsx)(n.Flex, {
                        sx: {
                            flexShrink: 0
                        }
                    }, (0, n.jsx)(n.Text, {
                        as: "p",
                        sx: {
                            fontWeight: "bold",
                            mt: 24
                        },
                        variant: "t16"
                    }, "Read ", i, "\u2019s Story ", (0, n.jsx)(a.default, {
                        sx: {
                            ml: 4
                        },
                        width: "18"
                    }))))))
                },
                c = function(e) {
                    return e.isLink ? (0, n.jsx)("a", {
                        href: e.href,
                        rel: "noopener",
                        sx: {
                            textDecoration: "none"
                        },
                        target: e.newTab ? "_blank" : "_self"
                    }, (0, n.jsx)(u, e)) : (0, n.jsx)(u, e)
                };
            t.default = c
        },
        9167: function(e, t) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = [{
                name: "Gabriel Lages",
                photoPath: "Quotes/gabriel",
                quote: '"As a manager, DataCamp helps me show my team new packages and new ways to solve problems."',
                slug: "/stories/gabriel",
                subtext: "Gabriel Lages, Business Intelligence and Analytics Manager, Hotmart"
            }, {
                name: "Rachel Alt-Simmons",
                photoPath: "Quotes/rachel",
                quote: '"We think of it as everyone\'s responsibility in the organization to be more data-driven. After all, every single one of us is probably touching data in some way, regardless of your role."',
                subtext: "Rachel Alt-Simmons, Head Of Strategic Design, Data, Pricing And Analytics, AXA XL"
            }, {
                name: "Ofentswe Lebogo",
                photoPath: "Quotes/ofentswe",
                quote: '"On DataCamp, you learn from the experts. As you are taking courses, you are really learning from the best instructors in the world."',
                subtext: "Ofentswe Lebogo, Data Scientist, Council for Scientific and Industrial Research (CSIR)"
            }, {
                name: "Devon Edwards Joseph",
                photoPath: "Quotes/devon",
                quote: "\"I've used other sites\u2014Coursera, Udacity, things like that\u2014but DataCamp's been the one that I've stuck with.\"",
                subtext: "Devon Edwards Joseph, Data Engineer, Lloyd's Banking Group"
            }, {
                name: "Sarah Schlobohm",
                photoPath: "Quotes/sarah",
                quote: '"We\u2019ve trialed a number of other online learning solutions, but only DataCamp provides the interactive  experience that reinforces learning."',
                subtext: "Sarah Schlobohm, Senior Analytics Manager, Global Risk Analytics, HSBC"
            }, {
                name: "Harshvardhan Dhapola",
                photoPath: "Quotes/harshvardhan",
                quote: '"DataCamp is a lot better than other online learning platforms I\'ve tried. It takes less time, it is more efficient, and you get hands-on practice."',
                subtext: "Harshvardhan Dhapola"
            }];
            t.default = r
        },
        13035: function(e, t, r) {
            r(21249), r(68309), r(19601), Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = c(r(75520)),
                n = c(r(65949)),
                a = r(18733),
                i = c(r(70883)),
                l = c(r(5840)),
                s = c(r(20551)),
                u = c(r(9167));

            function c(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function f() {
                return f = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (e[o] = r[o])
                    }
                    return e
                }, f.apply(this, arguments)
            }
            var d = {
                    desktop: {
                        breakpoint: {
                            max: 3e3,
                            min: 1200
                        },
                        items: 3,
                        slidesToSlide: 1
                    },
                    mobile: {
                        breakpoint: {
                            max: 600,
                            min: 0
                        },
                        items: 1,
                        partialVisibilityGutter: 30,
                        slidesToSlide: 1
                    },
                    smallDesktop: {
                        breakpoint: {
                            max: 1200,
                            min: 768
                        },
                        items: 2,
                        partialVisibilityGutter: 30,
                        slidesToSlide: 1
                    },
                    tablet: {
                        breakpoint: {
                            max: 768,
                            min: 600
                        },
                        items: 1,
                        partialVisibilityGutter: 200,
                        slidesToSlide: 1
                    }
                },
                p = function(e) {
                    var t = e.next,
                        r = e.previous;
                    return (0, a.jsx)(a.Flex, {
                        sx: {
                            display: "flex",
                            justifyContent: "flex-end",
                            mt: 32
                        }
                    }, (0, a.jsx)(a.Button, {
                        "aria-label": "Previous testimonial",
                        onClick: function() {
                            return r()
                        },
                        sx: {
                            color: "purple.200"
                        },
                        variant: "carousel"
                    }, (0, a.jsx)(o.default, {
                        "aria-hidden": !0,
                        size: 24,
                        title: ""
                    })), (0, a.jsx)(a.Button, {
                        "aria-label": "Next testimonial",
                        onClick: function() {
                            return t()
                        },
                        sx: {
                            color: "purple.200",
                            ml: 16
                        },
                        variant: "carousel"
                    }, (0, a.jsx)(n.default, {
                        "aria-hidden": !0,
                        size: 24,
                        title: ""
                    })))
                },
                b = ["yellow.200", "green.200", "pink.200"],
                v = function(e) {
                    var t = e.clickable,
                        r = e.quotes,
                        o = void 0 === r ? u.default : r,
                        n = e.title;
                    return (0, a.jsx)(a.Box, {
                        as: "section",
                        sx: {
                            position: "relative"
                        }
                    }, (0, a.jsx)(a.Box, {
                        sx: {
                            bg: "purple.200",
                            overflowX: "hidden",
                            width: "100%"
                        }
                    }, (0, a.jsx)(a.Container, {
                        sx: {
                            mb: 120
                        }
                    }, (0, a.jsx)(a.Text, {
                        as: "h2",
                        sx: {
                            color: "white",
                            mb: 48,
                            mt: 140,
                            mx: "auto",
                            textAlign: "center"
                        },
                        variant: "h40"
                    }, n), (0, a.jsx)(l.default, {
                        additionalTransform: -16,
                        customButtonGroup: (0, a.jsx)(p, null),
                        isOverflowVisible: !0,
                        responsive: d
                    }, o.map((function(e, r) {
                        return (0, a.jsx)(s.default, f({
                            accentColor: b[r % 3],
                            isLink: t,
                            key: e.name
                        }, e))
                    }))))), (0, a.jsx)(a.Flex, {
                        "aria-hidden": "true",
                        sx: {
                            "> *": {
                                flexShrink: 0
                            },
                            justifyContent: "flex-end",
                            left: 0,
                            mr: 374,
                            position: "absolute",
                            pr: "50%",
                            right: 0,
                            top: -81
                        }
                    }, (0, a.jsx)(i.default, {
                        "aria-hidden": "true"
                    })), (0, a.jsx)(a.Flex, {
                        "aria-hidden": "true",
                        sx: {
                            "> *": {
                                flexShrink: 0
                            },
                            bottom: -81,
                            justifyContent: "flex-end",
                            left: 0,
                            pl: "50%",
                            position: "absolute",
                            right: 0,
                            zIndex: 10
                        }
                    }, (0, a.jsx)(i.default, {
                        "aria-hidden": "true",
                        sx: {
                            ".broome_svg__c1": {
                                fill: "purple.100"
                            },
                            ".broome_svg__c2": {
                                fill: "blue.200"
                            },
                            display: ["none", null, null, "inline-block"]
                        }
                    })))
                };
            t.default = v
        },
        75520: function(e, t, r) {
            var o = r(20862),
                n = r(95318);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(r(45697)),
                i = o(r(11720)),
                l = r(70917),
                s = i.forwardRef((function(e, t) {
                    var r = e["aria-hidden"],
                        o = void 0 !== r && r,
                        n = e.className,
                        a = e.color,
                        i = void 0 === a ? "currentColor" : a,
                        s = e.size,
                        u = void 0 === s ? 18 : s,
                        c = e.title,
                        f = e.titleId;
                    return (0, l.jsx)("svg", {
                        viewBox: "0 0 18 18",
                        "aria-hidden": o,
                        className: n,
                        height: u,
                        ref: t,
                        role: "img",
                        width: u,
                        "aria-labelledby": f
                    }, void 0 === c ? (0, l.jsx)("title", {
                        id: f
                    }, "Left Arrow") : c ? (0, l.jsx)("title", {
                        id: f
                    }, c) : null, (0, l.jsx)("path", {
                        fill: i,
                        d: "M4.42 8L16 7.998a1 1 0 010 2L4.41 10l3.285 3.296a.998.998 0 11-1.417 1.41l-4.93-4.948A.998.998 0 011.36 8.23l4.933-4.938a1 1 0 011.414 0c.39.391.39 1.025 0 1.416L4.42 7.999z",
                        fillRule: "evenodd"
                    }))
                }));
            s.propTypes = {
                "aria-hidden": a.default.bool,
                className: a.default.string,
                color: a.default.string,
                size: a.default.oneOf([12, 18, 24]),
                title: a.default.string,
                titleId: a.default.string
            };
            var u = s;
            t.default = u
        },
        65949: function(e, t, r) {
            var o = r(20862),
                n = r(95318);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(r(45697)),
                i = o(r(11720)),
                l = r(70917),
                s = i.forwardRef((function(e, t) {
                    var r = e["aria-hidden"],
                        o = void 0 !== r && r,
                        n = e.className,
                        a = e.color,
                        i = void 0 === a ? "currentColor" : a,
                        s = e.size,
                        u = void 0 === s ? 18 : s,
                        c = e.title,
                        f = e.titleId;
                    return (0, l.jsx)("svg", {
                        viewBox: "0 0 18 18",
                        "aria-hidden": o,
                        className: n,
                        height: u,
                        ref: t,
                        role: "img",
                        width: u,
                        "aria-labelledby": f
                    }, void 0 === c ? (0, l.jsx)("title", {
                        id: f
                    }, "Right Arrow") : c ? (0, l.jsx)("title", {
                        id: f
                    }, c) : null, (0, l.jsx)("path", {
                        fill: i,
                        d: "M13.58 10L2 10.002a1 1 0 010-2L13.59 8l-3.285-3.296a.998.998 0 111.417-1.41l4.93 4.948a.998.998 0 01-.012 1.527l-4.933 4.938a1 1 0 01-1.414 0 1.002 1.002 0 010-1.416l3.287-3.29z",
                        fillRule: "evenodd"
                    }))
                }));
            s.propTypes = {
                "aria-hidden": a.default.bool,
                className: a.default.string,
                color: a.default.string,
                size: a.default.oneOf([12, 18, 24]),
                title: a.default.string,
                titleId: a.default.string
            };
            var u = s;
            t.default = u
        }
    }
]);
//# sourceMappingURL=13035-ba1b2157144243db.js.map