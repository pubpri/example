"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [21098], {
        21098: function(e, i, r) {
            r.d(i, {
                Z: function() {
                    return v
                }
            });
            var n = r(87462),
                a = r(45987),
                s = r(14612),
                o = r(11720),
                c = r(70917),
                t = (0, c.css)({
                    border: 0,
                    height: "100%",
                    left: 0,
                    margin: 0,
                    opacity: .001,
                    padding: 0,
                    position: "absolute",
                    top: 0,
                    width: "100%",
                    zIndex: -1
                }, "", ""),
                d = (0, o.forwardRef)((function(e, i) {
                    return (0, c.jsx)("input", (0, n.Z)({
                        css: t,
                        ref: i
                    }, e))
                })),
                l = JSON.parse('{"O9":{"iN":"#06bdfc","qn":"#009bd8","v":"#05192d","ix":"#ffffff","eC":"#d9d9e2"},"I8":{"G":"\'Studio-Feixen-Sans\'"},"Ue":{"oN":"400"}}'),
                p = (0, c.css)({
                    alignItems: "center",
                    boxSizing: "border-box",
                    color: l.O9.v,
                    cursor: "pointer",
                    display: "inline-flex",
                    fontFamily: l.I8.G,
                    fontSize: 16,
                    fontWeight: parseInt(l.Ue.oN, 10),
                    opacity: 1,
                    position: "relative",
                    userSelect: "none"
                }, "", "");
            var f = function(e) {
                    var i = e.appearance,
                        r = e.children,
                        n = e.className,
                        a = e.disabled;
                    return (0, c.jsx)("label", {
                        className: n,
                        css: (0, c.css)(p, {
                            color: "inverted" === i ? l.O9.ix : l.O9.v
                        }, a && {
                            cursor: "default",
                            opacity: .5
                        }, "", "")
                    }, r)
                },
                u = r(38217),
                b = (0, c.css)({
                    backgroundClip: "content-box",
                    backgroundColor: l.O9.iN,
                    borderRadius: 12,
                    boxSizing: "border-box",
                    height: 24,
                    marginRight: 8,
                    minWidth: 34,
                    padding: 3,
                    position: "relative",
                    width: 34
                }, "", ""),
                h = (0, c.css)({
                    alignItems: "center",
                    backgroundColor: l.O9.ix,
                    borderRadius: 6,
                    boxSizing: "border-box",
                    display: "flex",
                    height: 12,
                    justifyContent: "center",
                    left: 6,
                    position: "absolute",
                    top: 6,
                    transition: "transform 75ms linear",
                    width: 12,
                    zIndex: 1
                }, "", "");
            var x = function(e) {
                var i = e.appearance,
                    r = e.checked,
                    n = e.hasLabel,
                    a = e.isFocusVisible;
                return (0, c.jsx)("div", {
                    css: (0, c.css)(b, {
                        backgroundColor: r ? l.O9.iN : "inverted" === i ? l.O9.ix : l.O9.eC,
                        marginRight: n ? 8 : 0
                    }, a && {
                        boxShadow: "0 0 0 2px ".concat(l.O9.qn)
                    }, "", "")
                }, (0, c.jsx)("div", {
                    css: (0, c.css)(h, {
                        backgroundColor: r || "inverted" !== i ? l.O9.ix : l.O9.eC,
                        transform: "translateX(".concat(r ? 10 : 0, "px)")
                    }, "", "")
                }, r && (0, c.jsx)(u.Z, {
                    "aria-hidden": !0,
                    color: l.O9.iN,
                    size: 12
                })))
            };

            function g(e) {
                var i = e.appearance,
                    r = void 0 === i ? "default" : i,
                    o = e.checked,
                    t = e.children,
                    l = e.className,
                    p = e.disabled,
                    u = e.innerRef,
                    b = (0, a.Z)(e, ["appearance", "checked", "children", "className", "disabled", "innerRef"]),
                    h = (0, s.Fx)(),
                    g = h.focusProps,
                    v = h.isFocusVisible;
                return (0, c.jsx)(f, {
                    appearance: r,
                    children: t,
                    className: l,
                    disabled: p
                }, (0, c.jsx)(d, (0, n.Z)({
                    "aria-checked": o,
                    disabled: p,
                    ref: u,
                    role: "switch",
                    type: "checkbox"
                }, b, g)), (0, c.jsx)(x, {
                    appearance: r,
                    checked: o,
                    hasLabel: !!t,
                    isFocusVisible: v
                }), t)
            }
            g.propTypes = {};
            var v = (0, o.forwardRef)((function(e, i) {
                return (0, c.jsx)(g, (0, n.Z)({}, e, {
                    innerRef: i
                }))
            }))
        }
    }
]);
//# sourceMappingURL=21098-e702d5f2e9d7b762.js.map