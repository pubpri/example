! function(t) {
    var a, n, e, o = document.querySelector("[nonce]"),
        c = (o && (a = o.nonce || o.getAttribute("nonce")), {
            async: 1,
            pagePath: "/banner.js"
        }),
        i = "dc_consent",
        s = ["functional", "performance", "advertisement"];

    function r() {
        return window.location.hostname.split(".").slice(-2).join(".")
    }

    function d() {
        var n = r();
        return "datacamp-staging.com" === n || "datacamp.test" === n || "localhost" === n ? n : "datacamp.com"
    }

    function u(n) {
        return "https://" + n.subdomain + "." + n.domain + n.path
    }

    function p(n) {
        var e = document.createElement("script");
        e.src = u({
            subdomain: "compliance",
            domain: d(),
            path: n.pagePath
        }), a && "null" !== a && e.setAttribute("nonce", a), e.async = n.async, document.head.appendChild(e)
    }

    function m(n) {
        for (var e = 0; e < t.length; e++) - 1 < n.indexOf(t[e].category) && p(t[e])
    }

    function l() {
        try {
            if (navigator.userAgent.includes("x-dc-client=webview")) return s.slice(0)
        } catch {}
        var n, e = JSON.parse((n = i, (n = document.cookie.match("(^|;) ?" + n + "=([^;]*)(;|$)")) ? decodeURIComponent(n[2]) : null));
        return e ? Object.keys(e).filter(function(n) {
            return "version" !== n && "essential" !== n && e[n]
        }) : []
    }

    function f() {
        0 < l().length && m(l())
    }
    m(["essential"]), 0 < l().length ? f() : (n = function(n) {
        !0 === n || "true" === n ? (p(c), window.addEventListener("dc:consent:updated", f, !1)) : (document.cookie = i + '={"version":"1.0.0","essential":1,"functional":1,"performance":1,"advertisement":1};path=/;domain=' + r() + ";", window.dispatchEvent(new CustomEvent("dc:consent:updated")), f())
    }, (e = new XMLHttpRequest).onreadystatechange = function() {
        4 == e.readyState && n(e.response)
    }, e.open("GET", u({
        subdomain: "compliancy",
        domain: d(),
        path: "/geolocation"
    })), e.responseType = "json", e.send())
}([{
    async: !0,
    category: "essential",
    pagePath: "/scripts/gtm.js"
}]);