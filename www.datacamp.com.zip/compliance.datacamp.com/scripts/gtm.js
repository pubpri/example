! function(e, t, n, o) {
    e[o] = e[o] || [], e[o].push({
        event: "gtm.js",
        "gtm.start": (new Date).getTime()
    });
    const c = t.getElementsByTagName(n)[0],
        a = t.createElement(n);
    a.async = !0, a.src = "https://www.googletagmanager.com/gtm.js?id=GTM-TGGWB2P";
    const r = t.querySelector("[nonce]");
    r && a.setAttribute("nonce", r.nonce || r.getAttribute("nonce")), c.parentNode.insertBefore(a, c)
}(window, document, "script", "dataLayer");